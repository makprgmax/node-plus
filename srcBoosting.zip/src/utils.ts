import { db } from './init';
import * as admin from 'firebase-admin';
import QuerySnapshot = admin.firestore.QuerySnapshot;
import DocumentData = admin.firestore.DocumentData;
import QueryDocumentSnapshot = admin.firestore.QueryDocumentSnapshot;
import FieldPath = admin.firestore.FieldPath;
import Query = admin.firestore.Query;
import Timestamp = admin.firestore.Timestamp;
import { APIResult, EmailTemplate, SendEmail } from './interfaces';
import DocumentReference = admin.firestore.DocumentReference;
// import * as firebase from 'firebase/functions';
import firebase from 'firebase';
import WhereFilterOp = firebase.firestore.WhereFilterOp;
import OrderByDirection = firebase.firestore.OrderByDirection;
import { environment } from './environments/environment';

export function getCollection(
  collection: string
): Promise<QuerySnapshot<DocumentData>> {
  return db.collection(collection).get();
}

export interface InitialPaginatedCollection<T> {
  run: () => Promise<PaginatedCollection<T>>;
}
export interface PaginatedCollection<T> {
  querySnapshot: QuerySnapshot<T>;
  next: () => Promise<PaginatedCollection<T>>;
  hasNext: boolean;
}

export interface QueryWhereParams {
  fieldPath: string | FieldPath;
  opStr: WhereFilterOp;
  value: any;
}

interface RequiredPaginatedCollectionParams {
  collection: string;
}
export interface OptionalPaginatedCollectionParams {
  orderByField: string;
  orderByDirection: OrderByDirection;
  limit: number;
  lastDocFieldValue: any;
  where: QueryWhereParams;
}
export type PaginatedCollectionParams = RequiredPaginatedCollectionParams &
  Partial<OptionalPaginatedCollectionParams>;
type AllPaginatedCollectionParams = RequiredPaginatedCollectionParams &
  OptionalPaginatedCollectionParams;

/*
 * example of usage
const paginatedCollection = getPaginatedCollection<AttachClientToCardProcess>({
  collection: 'attachClientToCardProcesses',
  where: {
    fieldPath: 'state',
    opStr: '==',
    value: 'client__boosting',
  },
});
let process: Record<string, any> = {};
let collection: PaginatedCollection<AttachClientToCardProcess> = await paginatedCollection.run();
do {
  for (const doc of collection.querySnapshot.docs) {
    process = doc.data();
    // do something with process
  }
  if (collection.hasNext) {
    collection = await collection.next();
  } else {
    break;
  }
} while (true);
*/

export function getPaginatedCollection<T1 extends Record<string, any>>(
  params: PaginatedCollectionParams
): InitialPaginatedCollection<T1> {
  const DEFAULT_ORDER_BY_FIELD = 'id';
  const DEFAULT_ORDER_BY_DIRECTION = 'asc';
  const DEFAULT_LIMIT = 20;
  const DEFAULT_WHERE = {} as QueryWhereParams;
  const paramsWithDefault = {
    orderByField: DEFAULT_ORDER_BY_FIELD,
    limit: DEFAULT_LIMIT,
    where: DEFAULT_WHERE,
    orderByDirection: DEFAULT_ORDER_BY_DIRECTION,
    ...params,
  } as AllPaginatedCollectionParams;

  const getNextPaginatedCollection = async <T2 extends T1>(
    p: AllPaginatedCollectionParams
  ): Promise<PaginatedCollection<T2>> => {
    let querySnapshot: QuerySnapshot<T2>;
    const {
      collection,
      orderByField,
      orderByDirection,
      limit,
      lastDocFieldValue,
      where,
    } = p;
    const ref = db.collection(collection);
    let query: Query<T2>;

    query =
      !!where && where.fieldPath && where.opStr && where.value
        ? ref
            .where(where.fieldPath, where.opStr, where.value)
            .orderBy(orderByField, orderByDirection)
        : ref.orderBy(orderByField, orderByDirection);

    query = !!lastDocFieldValue
      ? query.startAfter(lastDocFieldValue).limit(limit)
      : query.limit(limit);

    querySnapshot = await query.get();

    const hasNext = querySnapshot.size === limit;
    let newLastDocFieldValue: any;
    if (hasNext) {
      const lastDoc: QueryDocumentSnapshot<T2> =
        querySnapshot.docs[querySnapshot.size - 1];
      const lastDocData: T2 = lastDoc.data();
      newLastDocFieldValue = lastDocData[orderByField];
    } else {
      newLastDocFieldValue = null;
    }

    const response: PaginatedCollection<T2> = {
      hasNext,
      querySnapshot,
      next: () =>
        getNextPaginatedCollection<T2>({
          collection,
          orderByField,
          orderByDirection,
          limit,
          lastDocFieldValue: newLastDocFieldValue,
          where,
        }),
    };
    return Promise.resolve(response);
  };
  return {
    run: () => getNextPaginatedCollection<T1>(paramsWithDefault),
  };
}

export function sortAZ(a: string, b: string) {
  const x = a.toLowerCase();
  const y = b.toLowerCase();
  return x < y ? -1 : x > y ? 1 : 0;
}

export function sortZA(a: string, b: string) {
  const x = a.toLowerCase();
  const y = b.toLowerCase();
  return x > y ? -1 : x < y ? 1 : 0;
}

export function getTimestampFromDateString(
  dateString: string | undefined
): Timestamp | undefined {
  try {
    return dateString ? Timestamp.fromDate(new Date(dateString)) : undefined;
  } catch (e) {
    return undefined;
  }
}

export interface SendEmailTemplateProps {
  to: string[];
  emailTemplate: EmailTemplate;
}

export function sendEmailTemplate({
  to,
  emailTemplate,
}: SendEmailTemplateProps): Promise<DocumentReference<SendEmail>> {
  const [firstEmail, ...restEmails] = to;
  return db.collection(`sendEmails`).add({
    to: firstEmail,
    bcc: restEmails.length ? restEmails : null,
    template: emailTemplate,
  } as SendEmail);
}

export interface SendLogToEmailProps {
  subject: string;
  log: APIResult;
  to: string[];
}

export function sendLogToEmail(
  props: SendLogToEmailProps
): Promise<DocumentReference<SendEmail>> {
  const { log, subject, to } = props;
  const logAsString = JSON.stringify(log, null, 2);
  const [firstEmail, ...restEmails] = to;

  return db.collection(`sendEmails`).add({
    to: firstEmail,
    cc: restEmails.length ? restEmails : null,
    message: {
      subject,
      html: `<pre>${logAsString}</pre>`,
      text: logAsString,
    },
  } as SendEmail);
}

export const sendEmail = async (subject: string, log: any) => {
  const emailProps: SendLogToEmailProps = {
    to: environment.sendEmails.developers,
    subject,
    log,
  };
  await sendLogToEmail(emailProps);
};

export interface IterateThroughPaginatedCollectionProps<T, R> {
  collection: PaginatedCollection<T>;
  identity: (item: T) => R;
}
export async function iterateThroughPaginatedCollection<T, R>(
  props: IterateThroughPaginatedCollectionProps<T, R>
): Promise<R[]> {
  let { collection } = props;
  const { identity } = props;
  const returnAry: R[] = [];
  let item: T;
  do {
    for (const doc of collection.querySnapshot.docs) {
      item = doc.data();
      returnAry.push(identity(item));
    }
    if (collection.hasNext) {
      collection = await collection.next();
    } else {
      break;
    }
  } while (true);
  return Promise.resolve(returnAry);
}

export function dateToUSFormatString(
  date: Date,
  leadingZero: boolean = true
): string {
  const maxLength = leadingZero ? 2 : 1;
  const year = String(date.getFullYear());
  const month = String(date.getMonth() + 1);
  const day = String(date.getDate());
  return `${month.padStart(maxLength, '0')}/${day.padStart(
    maxLength,
    '0'
  )}/${year}`;
}
