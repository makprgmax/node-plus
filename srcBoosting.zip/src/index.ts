import * as functions from 'firebase-functions';
// import { db } from './init';
// import * as admin from 'firebase-admin';
// import QuerySnapshot = admin.firestore.QuerySnapshot;
// import DocumentData = admin.firestore.DocumentData;
// import { resizeImage } from './image-upload';
// import { updateDisplayNameInUsers } from './update-displayname-in-users';
// import { generateCreatedAt } from './update-created-at-in-users';
import { dailyUpdateMentorProcessPeriodIncome } from './mentor-income/daily-update-mentor-process-period-income';
import { dailyUpdateMentorPeriodIncome } from './mentor-income/daily-update-mentor-period-income';
import { dailyUpdateMentorBalance } from './mentor-income/daily-update-mentor-balance';
import { monthlyCopyMentorBalanceFromPreviousMonth } from './mentor-income/monthly-copy-mentor-balance-from-previous-month';
import { updateMentorProcessPeriodIncome } from './mentor-income/update-mentor-process-period-income';
import { updateMentorPeriodIncome } from './mentor-income/update-mentor-period-income';
import { updateMentorBalance } from './mentor-income/update-mentor-balance';
import { Request, Response } from 'express';
import { paypalWebhook } from './paypal/webhook';
import { paypalWebhookLogParser } from './paypal/paypal-webhook-log-parser';
import { updatePaypalClientSubscription } from './paypal/paypal-webhook-log-on-create';
import { updateUserClientRegistrationState } from './paypal/paypal-client-subscription-on-write';
import { RuntimeOptions } from 'firebase-functions/lib/function-configuration';
import { createUser } from './auth/create-user';
import triggers from './triggers';
const cors = require('cors');

const express = require('express');
// Start writing Firebase Functions
// https://firebase.google.com/docs/functions/typescript

const app = express();
app.use(cors({ origin: true }));

app.get('/ping', async (request: any, response: any) => {
  response.status(200).json({ pong: true });
});

// production webhook, do not use it for other environments
app.post('/webhook9C592112K61P36334prod', paypalWebhook);

// dev webhook, do not use it for production environment
app.post('/webhook112K61P369C592334dev', paypalWebhook);

app.get(
  '/paypal-webhook-parser',
  async (request: Request, response: Response) => {
    const result = await paypalWebhookLogParser();
    response.status(200).json(result);
  }
);

app.get(
  '/update-mentor-process-period-income-619vP36z5da',
  async (request: any, response: any) => {
    try {
      const result = await updateMentorProcessPeriodIncome();
      response.status(200).json({ result });
    } catch (e) {
      response.status(200).json({ error: e.message });
    }
  }
);

app.get(
  '/update-mentor-period-income-619vP36z5da',
  async (request: any, response: any) => {
    try {
      const result = await updateMentorPeriodIncome();
      response.status(200).json({ result });
    } catch (e) {
      response.status(200).json({ error: e.message });
    }
  }
);

app.get(
  '/update-mentor-balance-619vP36z5da',
  async (request: any, response: any) => {
    try {
      const result = await updateMentorBalance();
      response.status(200).json({ result });
    } catch (e) {
      response.status(200).json({ error: e.message });
    }
  }
);

app.post('/clients', createUser);

const runOptions: RuntimeOptions = {
  timeoutSeconds: 300,
  memory: '1GB',
};

const api = functions.runWith(runOptions).https.onRequest(app);

// SCHEDULED FUNCTIONS

const scheduledMonthlyCopyMentorBalanceFromPreviousMonth = functions.pubsub
  .schedule('55 11 1 * *')
  .timeZone('Europe/Kiev')
  .onRun((context) => {
    return monthlyCopyMentorBalanceFromPreviousMonth(context);
  });

const scheduledDailyUpdateMentorProcessPeriodIncome = functions.pubsub
  .schedule('00 12 * * *')
  .timeZone('Europe/Kiev')
  .onRun((context) => {
    return dailyUpdateMentorProcessPeriodIncome(context);
  });

const scheduledDailyUpdateMentorPeriodIncome = functions.pubsub
  .schedule('05 12 * * *')
  .timeZone('Europe/Kiev')
  .onRun((context) => {
    return dailyUpdateMentorPeriodIncome(context);
  });

const scheduledDailyUpdateMentorBalance = functions.pubsub
  .schedule('10 12 * * *')
  .timeZone('Europe/Kiev')
  .onRun((context) => {
    return dailyUpdateMentorBalance(context);
  });

export {
  /* resizeImage, */
  api,
  scheduledMonthlyCopyMentorBalanceFromPreviousMonth,
  scheduledDailyUpdateMentorProcessPeriodIncome,
  scheduledDailyUpdateMentorPeriodIncome,
  scheduledDailyUpdateMentorBalance,
  // paypal
  updatePaypalClientSubscription,
  updateUserClientRegistrationState,
  // onCreate, onUpdate triggers
  triggers,
};
