import * as admin from 'firebase-admin';
import WriteResult = admin.firestore.WriteResult;
import { db } from '../../init';
import {
  PaypalClientSubscriptionView,
  PaypalClSubsViewCollectionsDictionary,
} from '../../interfaces';
import { createSearchIndexMap } from '../search-index-utils';
import {
  getUserByUidAsync,
  getUserProfileByUidAsync,
} from '../../triggers/utils';

/**
 * when client is created
 * read displayName, email from related user
 * read phoneNumber from related userProfile
 * build searchIndex for those fields
 * save displayName, email, phoneNumber, searchIndex in client
 */
export const updateSearchIndexInPaypalClSubsView = async (
  paypalClSubsView: PaypalClientSubscriptionView
): Promise<WriteResult | null> => {
  // read related user
  const user = await getUserByUidAsync(paypalClSubsView.uid);

  // read related user profile
  const userProfile = await getUserProfileByUidAsync(paypalClSubsView.uid);
  if (!user || !userProfile) {
    return null;
  }

  const displayName = user.displayName || '';
  const email = user.email || '';
  const phoneNumber = userProfile.phoneNumber || '';
  const indexStrings = [displayName, email, phoneNumber];
  const searchIndex = createSearchIndexMap(indexStrings);

  // update client
  const collectionName =
    PaypalClSubsViewCollectionsDictionary[paypalClSubsView.state];
  return db.doc(`${collectionName}/${paypalClSubsView.id}`).update({
    displayName,
    email,
    phoneNumber,
    searchIndex,
  });
};
