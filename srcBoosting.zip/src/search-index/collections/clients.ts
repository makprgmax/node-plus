import * as admin from 'firebase-admin';
import WriteResult = admin.firestore.WriteResult;
import { db } from '../../init';
import { Client } from '../../interfaces';
import {
  convertStringArrayToSearchIndexMap,
  createSearchIndexMap,
  generateDateRange,
  getLastFourDigitsFromPhoneNumber,
} from '../search-index-utils';
import {
  getUserByUidAsync,
  getUserProfileByUidAsync,
} from '../../triggers/utils';

/**
 * when client is created
 * read displayName, email from related user
 * read phoneNumber from related userProfile
 * build searchIndex for those fields
 * save displayName, email, phoneNumber, searchIndex in client
 */
export const updateSearchIndexInClient = async (
  client: Client
): Promise<WriteResult | null> => {
  // read related user

  const user = await getUserByUidAsync(client.uid);

  // read related user profile
  const userProfile = await getUserProfileByUidAsync(client.uid);
  if (!user || !userProfile) {
    return null;
  }

  const { firstName, lastName } = userProfile;
  const displayName = `${firstName || ''} ${lastName || ''}`.trim();
  const email = user.email || '';
  const phoneNumber = userProfile.phoneNumber || '';
  const indexStrings = [displayName, email, phoneNumber];
  const searchIndex = {
    ...createSearchIndexMap(indexStrings),
    ...convertStringArrayToSearchIndexMap([
      getLastFourDigitsFromPhoneNumber(phoneNumber),
      ...generateDateRange(user.createdAt, 1),
    ]),
  };

  // update client
  return db.doc(`clients/${client.id}`).update({
    displayName,
    email,
    phoneNumber,
    searchIndex,
  });
};
