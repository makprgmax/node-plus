import * as admin from 'firebase-admin';
import Timestamp = admin.firestore.Timestamp;
import {
  convertStringArrayToSearchIndexMap,
  createSearchIndexMap,
  generateDateRange,
  getLastFourDigitsFromPhoneNumber,
  lastXChars,
  prepareString,
  SearchIndexMap,
  splitIntoChars,
  splitIntoWords,
  trimSlash,
} from './search-index-utils';

describe('search-index', () => {
  type TableStrAndAry = [string, string[]][];
  type TableStrAndStr = [string, string][];
  describe('splitIntoWords', () => {
    it.each([
      ['ab', ['ab']],
      ['ab cd', ['ab', 'cd']],
      ['ab  cd', ['ab', 'cd']],
    ] as TableStrAndAry)('"%s" -> %o', (param, expected) => {
      expect(splitIntoWords(param)).toEqual(expected);
    });
  });
  describe('splitIntoChars', () => {
    it.each([
      ['ab', ['a', 'b']],
      ['ab cd', ['a', 'b', ' ', 'c', 'd']],
      ['ab  cd', ['a', 'b', ' ', ' ', 'c', 'd']],
    ] as TableStrAndAry)('"%s" -> %o', (param, expected) => {
      expect(splitIntoChars(param)).toEqual(expected);
    });
  });
  describe('prepareString', () => {
    describe('converts to lower case, removes special chars and removes double+ spaces between words', () => {
      it.each([
        ['A', 'a'],
        ['SAM', 'sam'],
        ['A  B', 'a b'],
        ['Eric   Mars     Jr.', 'eric mars jr'],
        ['re.move . dot.', 'remove dot'],
        ['rem-ove - dash-', 'remove dash'],
        ['+remove + plus', 'remove plus'],
        ['remove ( left( (parenthesis', 'remove left parenthesis'],
        ['remove ) right) )parenthesis', 'remove right parenthesis'],
        ['remove ) right) )parenthesis', 'remove right parenthesis'],
        ['remove ~ tilde~', 'remove tilde'],
        ['remove / sla/sh/', 'remove slash'],
        ['remove [ left brac[ket', 'remove left bracket'],
        ['remove ] right brac]ket', 'remove right bracket'],
        ['remove * asteri*sk*', 'remove asterisk'],
        ['remove */[]().-+all  together', 'remove all together'],
        ['', ''],
      ] as TableStrAndStr)('"%s" -> "%s"', (param, expected) => {
        expect(prepareString(param)).toEqual(expected);
      });
    });
  });
  describe('createSearchIndexMap', () => {
    describe('when string has one word: sam', () => {
      it('should return 1 index', () => {
        const actual = createSearchIndexMap('SAM');
        const expected = {
          sam: true,
        };
        expect(actual).toEqual(expected);
      });
    });
    describe('when string has one word: pi', () => {
      it('should return 1 index', () => {
        const actual = createSearchIndexMap('Pi');
        const expected = {};
        expect(actual).toEqual(expected);
      });
    });
    describe('when string has one word: eric', () => {
      it('should return 2 indexes', () => {
        const actual = createSearchIndexMap('EriC');
        const expected = {
          eri: true,
          eric: true,
        };
        expect(actual).toEqual(expected);
      });
    });
    describe('when string has two words: eric mars', () => {
      it('should return 6+2 indexes (all words indexes + second word indexes)', () => {
        const actual = createSearchIndexMap('eric MARS');
        const expected = {
          eri: true,
          eric: true,
          ericm: true,
          ericma: true,
          ericmar: true,
          ericmars: true,
          mar: true,
          mars: true,
        };
        expect(actual).toEqual(expected);
      });
    });
    describe('when string has two words with two spaces between: eric__mars', () => {
      it('should return 6+2 indexes (all words indexes + second word indexes)', () => {
        const actual = createSearchIndexMap('Eric  Mars');
        const expected = {
          eri: true,
          eric: true,
          ericm: true,
          ericma: true,
          ericmar: true,
          ericmars: true,
          mar: true,
          mars: true,
        };
        expect(actual).toEqual(expected);
      });
    });
    describe('when string has tree words: eric mars sr', () => {
      it('should return an object with 8 + 4 + 0 indexes', () => {
        const actual = createSearchIndexMap('Eric Mars sr');
        const expected = {
          eri: true,
          eric: true,
          ericm: true,
          ericma: true,
          ericmar: true,
          ericmars: true,
          ericmarss: true,
          ericmarssr: true,
          mar: true,
          mars: true,
          marss: true,
          marssr: true,
        };
        expect(actual).toEqual(expected);
      });
    });
    describe('when string has tree words: eric pi junior', () => {
      it('should return an object with 10 + 6 + 4 indexes', () => {
        const actual = createSearchIndexMap('Eric Pi Junior');
        const expected = {
          eri: true,
          eric: true,
          ericp: true,
          ericpi: true,
          ericpij: true,
          ericpiju: true,
          ericpijun: true,
          ericpijuni: true,
          ericpijunio: true,
          ericpijunior: true,
          pij: true,
          piju: true,
          pijun: true,
          pijuni: true,
          pijunio: true,
          pijunior: true,
          jun: true,
          juni: true,
          junio: true,
          junior: true,
        };
        expect(actual).toEqual(expected);
      });
    });
    describe('support array of strings', () => {
      it('should return combined indexes of each string', () => {
        const actual = createSearchIndexMap(['Eric  Mars', '+38(095)12-34-5']);
        const expected = {
          eri: true,
          eric: true,
          ericm: true,
          ericma: true,
          ericmar: true,
          ericmars: true,
          mar: true,
          mars: true,
          '380': true,
          '3809': true,
          '38095': true,
          '380951': true,
          '3809512': true,
          '38095123': true,
          '380951234': true,
          '3809512345': true,
        };
        expect(actual).toEqual(expected);
      });
      it('should return return empty map if array is empty', () => {
        const actual = createSearchIndexMap([]);
        const expected = {};
        expect(actual).toEqual(expected);
      });
      it('should return return some map if array has first empty value', () => {
        const actual = createSearchIndexMap(['', 'abc']);
        const expected = {
          abc: true,
        };
        expect(actual).toEqual(expected);
      });
    });
  });
  type DateRange = number;
  type DateRangeArray = string[];
  type GenerateDateRangeTestType = [
    string,
    Timestamp,
    DateRange,
    DateRangeArray
  ];
  describe('generateDateRange', () => {
    it.each<GenerateDateRangeTestType>([
      [
        'when range is 0 returns two dates with and without leading zeroes',
        Timestamp.fromDate(new Date('2021-04-01')),
        0,
        ['04/01/2021', '4/1/2021'].map(trimSlash),
      ],
      [
        'when range is 0 returns single date (when leading zero cannot be applied)',
        Timestamp.fromDate(new Date('2021-11-15')),
        0,
        ['11/15/2021'].map(trimSlash),
      ],
      [
        'when range is 1 returns 2 + 2 + 2 dates (with and without leading zeroes)',
        Timestamp.fromDate(new Date('2021-04-01')),
        1,
        [
          '03/31/2021',
          '3/31/2021',
          '04/01/2021',
          '4/1/2021',
          '04/02/2021',
          '4/2/2021',
        ].map(trimSlash),
      ],
      [
        'when range is 1 returns 1 + 2 + 2 dates (with and without leading zeroes)',
        Timestamp.fromDate(new Date('2021-11-01')),
        1,
        [
          '10/31/2021',
          '11/01/2021',
          '11/1/2021',
          '11/02/2021',
          '11/2/2021',
        ].map(trimSlash),
      ],
      [
        'when range is 2 returns 2 + 2 + 2 + 2 + 2 dates (with and without leading zeroes)',
        Timestamp.fromDate(new Date('2021-04-01')),
        2,
        [
          '03/30/2021',
          '3/30/2021',
          '03/31/2021',
          '3/31/2021',
          '04/01/2021',
          '4/1/2021',
          '04/02/2021',
          '4/2/2021',
          '04/03/2021',
          '4/3/2021',
        ].map(trimSlash),
      ],
    ])('%s', (title, timestamp, dateRange, expectedDateRangeArray) => {
      const actual = generateDateRange(timestamp, dateRange);
      expect(actual).toEqual(expectedDateRangeArray);
    });
  });
  describe('convertStringArrayToSearchIndexMap', () => {
    type ConvertStringArrayToSearchIndexMapType = [
      string,
      string[],
      SearchIndexMap
    ];
    it.each<ConvertStringArrayToSearchIndexMapType>([
      ['case 1', ['a', 'b', 'c'], { a: true, b: true, c: true }],
      [
        'case 2',
        ['10/31/2021', '11/01/2021', '11/1/2021', '11/02/2021', '11/2/2021'],
        {
          '10312021': true,
          '11012021': true,
          '1112021': true,
          '11022021': true,
          '1122021': true,
        },
      ],
      ['case 3', [''], {}],
      [
        'case 4 each string should be prepared',
        ['ABC', 'abc', 'V+[D]'],
        {
          abc: true,
          vd: true,
        },
      ],
    ])('%s', (title, ary, map) => {
      expect(convertStringArrayToSearchIndexMap(ary)).toEqual(map);
    });
  });
  describe('lastXChars', () => {
    type LastXCharsType = [string, number, string];
    it.each<LastXCharsType>([
      ['abcdefg', 2, 'fg'],
      ['abcdefg', 4, 'defg'],
      ['+1234567890', 4, '7890'],
      ['+12345678 90 ', 4, ' 90 '],
      ['+12345678 90 ', 1, ' '],
    ])('(%s, %s) -> %s', (input, lastX, expected) => {
      expect(lastXChars(input, lastX)).toEqual(expected);
    });
  });
  describe('getLastFourDigitsFromPhoneNumber', () => {
    type GetLastFourDigitsFromPhoneNumberType = [string, string];
    it.each<GetLastFourDigitsFromPhoneNumberType>([
      ['+16051234433', '4433'],
      ['+1(605)123-44-33', '4433'],
      ['+1(605)123-4+/. 4-( 3 * 3 )', '4433'],
      ['', ''],
    ])('%s -> %s', (input, output) => {
      expect(getLastFourDigitsFromPhoneNumber(input)).toEqual(output);
    });
  });
});
