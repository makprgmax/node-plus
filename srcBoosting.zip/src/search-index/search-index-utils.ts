import * as admin from 'firebase-admin';
import Timestamp = admin.firestore.Timestamp;
import { dateToUSFormatString } from '../utils';

export type SearchIndexMap = Record<string, boolean>;
const MIN_SEARCH_INDEX_LENGTH = 3;
const WORD_SEPARATOR = ' ';
const CHAR_SEPARATOR = '';
export const splitIntoWords = (str: string): string[] =>
  str.split(WORD_SEPARATOR).filter((word) => word.length > 0);
export const splitIntoChars = (str: string): string[] =>
  str.split(CHAR_SEPARATOR);
export const joinWords = (words: string[]) => words.join(WORD_SEPARATOR);

export function removeSpaces(str: string): string {
  return str.split(' ').join('');
}

const searchIndexReducer = (indexMap: SearchIndexMap) => (
  acc: string,
  next: string
) => {
  const key = acc + next;
  const keyTrimmed = removeSpaces(key);
  if (keyTrimmed.length >= MIN_SEARCH_INDEX_LENGTH) {
    indexMap[keyTrimmed] = true;
  }
  return key;
};

export function createSearchIndexMap(
  str: string | string[],
  searchIndex: SearchIndexMap = {}
): SearchIndexMap {
  const strings: string[] = Array.isArray(str) ? str : [str];

  const reducer = (acc: SearchIndexMap, next: string): SearchIndexMap =>
    iterateOverString(prepareString(next), acc);

  return strings.reduce(reducer, searchIndex);
}

// converts to lower case, removes special chars removes double spaces between words in the string
const SPECIAL_CHARS_REGEXP = /[*\]\[/~)(+.-]/g;
export const prepareString = (str: string): string =>
  joinWords(
    splitIntoWords(str.replace(SPECIAL_CHARS_REGEXP, '').toLowerCase())
  );

function iterateOverString(
  lowerStr: string,
  searchIndex: SearchIndexMap = {}
): SearchIndexMap {
  const [, ...restWords] = splitIntoWords(lowerStr);
  const ary = splitIntoChars(lowerStr);

  if (ary.length > 0) {
    ary.reduce(searchIndexReducer(searchIndex));
  }

  return restWords.length > 0
    ? iterateOverString(restWords.join(' '), searchIndex)
    : searchIndex;
}

const putDateToSet = (aSet: Set<string>, aDate: Date): void => {
  aSet.add(dateToUSFormatString(aDate, true));
  aSet.add(dateToUSFormatString(aDate, false));
};

export const trimSlash = (str: string): string => str.split('/').join('');

/**
 *
 * @param timestamp
 * @param dateRange number, +/- day(s) to timestamp,
 * e.g. timestamp 04/01/2021, returns 03/31/2021, 04/01/2021, 04/02/2021
 * including variants without leading zeros (4/1/2021, 4/2/2021/, 3/31/2021)
 * Attention! slashes are removed from the strings,
 * cause they are not supported by search in Firestore
 */
export function generateDateRange(
  timestamp: Timestamp | undefined,
  dateRange: number = 0
): string[] {
  if (!timestamp) {
    return [];
  }
  const date = timestamp.toDate();
  date.setDate(date.getDate() - dateRange);
  const dateSet = new Set<string>();
  for (let i = 0, total = dateRange * 2 + 1; i < total; i++) {
    putDateToSet(dateSet, date);
    date.setDate(date.getDate() + 1);
  }
  return Array.from(dateSet).map(trimSlash);
}

export function convertStringArrayToSearchIndexMap(
  ary: string[]
): SearchIndexMap {
  return ary.reduce((acc: SearchIndexMap, next: string) => {
    const prepared = prepareString(next);
    if (!!prepared) {
      acc[prepared] = true;
    }
    return acc;
  }, {});
}

export function lastXChars(str: string, amount: number): string {
  return str.slice(-amount);
}

export function getLastFourDigitsFromPhoneNumber(str: string): string {
  return lastXChars(removeSpaces(prepareString(str)), 4);
}
