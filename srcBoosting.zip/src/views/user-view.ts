import * as admin from 'firebase-admin';
import {
  ACTCProcessStateByRoleEnum,
  ACTCProcessStatesByRole,
  AttachClientToCardProcess,
  Mentor,
  User,
  UserProfile,
  UserView,
  UserViewCollectionsDictionary,
} from '../interfaces';
import WriteBatch = admin.firestore.WriteBatch;
import WriteResult = admin.firestore.WriteResult;
import QuerySnapshot = admin.firestore.QuerySnapshot;
import QueryDocumentSnapshot = admin.firestore.QueryDocumentSnapshot;
import { db } from '../init';
import { sendEmail } from '../utils';
import { getDocumentAsync, getUserProfileByUidAsync } from '../triggers/utils';
import {
  convertStringArrayToSearchIndexMap,
  createSearchIndexMap,
  generateDateRange,
  getLastFourDigitsFromPhoneNumber,
} from '../search-index/search-index-utils';

export interface UpdateUserClientsViewParams {
  user?: User;
  userProfile?: UserProfile;
}
export const createUserView = async (
  user: User
): Promise<WriteResult[] | null> => {
  try {
    const collectionName = UserViewCollectionsDictionary[user.role];
    // early exit if role is not CLIENT or MENTOR
    if (!collectionName) {
      return null;
    }
    // get data
    const {
      createdAt,
      role,
      uid,
      email,
      displayName,
      clientRegistrationState,
      userProfileStatus,
      phoneNumber,
    } = user;

    // build searchIndex dictionary
    const indexStrings = [displayName || '', email || '', phoneNumber || ''];
    const searchIndex = {
      ...createSearchIndexMap(indexStrings),
      ...convertStringArrayToSearchIndexMap([
        getLastFourDigitsFromPhoneNumber(phoneNumber || ''),
        ...generateDateRange(createdAt, 1),
        uid,
        userProfileStatus,
        clientRegistrationState || '',
      ]),
    };
    // create new view item
    const userViewData: UserView = {
      id: uid,
      createdAt,
      updatedAt: createdAt,
      clientRegistrationState,
      role,
      email,
      displayName,
      userProfileStatus,
      phoneNumber,
      searchIndex,
    };

    const userViewRef = db.doc(`${collectionName}/${uid}`);
    const batch: WriteBatch = db.batch();
    batch.set(userViewRef, userViewData);

    return batch.commit();
  } catch (e) {
    await sendEmail(`createUserView - ${e?.message}`, e);
    return null;
  }
};

export const updateUserView = async (
  user: User
): Promise<WriteResult[] | null> => {
  try {
    const collectionName = UserViewCollectionsDictionary[user.role];
    // early exit if role is not CLIENT or MENTOR
    if (!collectionName) {
      return null;
    }
    // get data
    const {
      createdAt,
      role,
      uid,
      email,
      clientRegistrationState,
      userProfileStatus,
    } = user;

    // get user data from user and userProfile by uid
    const userProfile = await getUserProfileByUidAsync(uid);
    const { phoneNumber, firstName, lastName, updatedAt } = userProfile || {
      phoneNumber: '',
    };
    const displayName = `${firstName || ''} ${lastName || ''}`.trim();

    // build searchIndex dictionary
    const indexStrings = [displayName || '', email || '', phoneNumber || ''];
    const searchIndex = {
      ...createSearchIndexMap(indexStrings),
      ...convertStringArrayToSearchIndexMap([
        getLastFourDigitsFromPhoneNumber(phoneNumber || ''),
        ...generateDateRange(createdAt, 1),
        uid,
        userProfileStatus,
        clientRegistrationState || '',
      ]),
    };

    // create new view item
    const userViewData: UserView = {
      id: uid,
      createdAt,
      updatedAt: updatedAt || createdAt,
      clientRegistrationState,
      role,
      email,
      displayName,
      userProfileStatus,
      phoneNumber,
      searchIndex,
    };

    const userViewRef = db.doc(`${collectionName}/${uid}`);
    const batch: WriteBatch = db.batch();
    batch.set(userViewRef, userViewData);

    return batch.commit();
  } catch (e) {
    await sendEmail(`updateUserView - ${e?.message}`, e);
    return null;
  }
};

export const deleteUserView = async (
  user: User
): Promise<WriteResult[] | null> => {
  try {
    const { role, uid } = user;
    const collectionName = UserViewCollectionsDictionary[role];
    if (!collectionName) {
      return null;
    }
    const userViewRef = db.doc(`${collectionName}/${uid}`);
    const batch: WriteBatch = db.batch();

    // TODO replace bach.update with batch.delete
    batch.update(userViewRef, {
      _deleted: admin.firestore.FieldValue.serverTimestamp(),
    });

    return batch.commit();
  } catch (e) {
    await sendEmail(`deleteUserView - ${e?.message}`, e);
    return null;
  }
};

export const getRoleFromState: (state: string) => ACTCProcessStateByRoleEnum = (
  str
) => (str.split('__').shift() || 'undefined') as ACTCProcessStateByRoleEnum;
/**
 * converts array into object { manager: number, mentor: number, end: number }
 * number reflects an amount of processes with current state starts with respective key
 * e.g. an array with a single process with status 'end__client_detached' -> { end: 1, manager: 0, mentor: 0 }
 */
const actcProcessStatesByRoleReducer = (
  acc: ACTCProcessStatesByRole,
  next: QueryDocumentSnapshot<AttachClientToCardProcess>
): ACTCProcessStatesByRole => {
  const role = getRoleFromState(next.data().state);
  acc[role] = (acc[role] || 0) + 1;
  return acc;
};

// updates UserViewMentor.actcProcessStates by mentor
export const updateActcProcessStatesInUserViewMentor = async (
  mentor: Mentor
): Promise<WriteResult[] | null> => {
  // get userViewMentor by mentor.uid
  const userViewMentorRef = db.doc(`userViewMentors/${mentor.uid}`);
  const userViewMentorSnapshot = await userViewMentorRef.get();
  // CHECK UserViewMentor exists
  if (!userViewMentorSnapshot.exists) {
    return null;
  }

  // get all actcProcesses by mentor.id
  const actcProcesses: QuerySnapshot<AttachClientToCardProcess> = await db
    .collection(`attachClientToCardProcesses`)
    .where(`mentorId`, '==', mentor.id)
    .get();

  // calculate actcProcessStates

  const defaultStatesByRole: ACTCProcessStatesByRole = {
    [ACTCProcessStateByRoleEnum.manager]: 0,
    [ACTCProcessStateByRoleEnum.mentor]: 0,
    [ACTCProcessStateByRoleEnum.client]: 0,
    [ACTCProcessStateByRoleEnum.end]: 0,
    [ACTCProcessStateByRoleEnum.undefined]: 0,
  };

  // ! actcProcesses.docs
  const actcProcessStates: ACTCProcessStatesByRole =
    actcProcesses.docs.length > 0
      ? actcProcesses.docs.reduce(
          actcProcessStatesByRoleReducer,
          defaultStatesByRole
        )
      : defaultStatesByRole;

  // update userView
  const batch: WriteBatch = db.batch();

  batch.update(userViewMentorRef, {
    actcProcessStates,
  });

  return batch.commit();
};

// updates prop actcProcessStates for UserViewMentor
export const updateUserViewFromActcProcess = async (
  actcProcess: AttachClientToCardProcess
): Promise<WriteResult[] | null> => {
  try {
    // get mentor
    const mentor = await getDocumentAsync<Mentor>(
      'mentors',
      actcProcess.mentorId
    );
    if (!mentor || !mentor.uid) {
      return null;
    }
    return updateActcProcessStatesInUserViewMentor(mentor);
  } catch (e) {
    await sendEmail(
      `updateUserViewFromActcProcess :: actcProcess.id = ${actcProcess.id} :: ${e?.message}`,
      e
    );
    return null;
  }
};
