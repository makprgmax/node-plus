# Views

View stands for table view, a database table which aggregates data from several other tables to simplify query.

So every aggregated collection (view) should be defined in this folder.

