import { getRoleFromState } from './user-view';
import { ACTCProcessStateByRoleEnum } from '../interfaces';

describe('user-view', () => {
  describe('getRoleFromState', () => {
    type ItTestType = [string, ACTCProcessStateByRoleEnum];
    it.each<ItTestType>([
      ['mentor__client_assigned_in_bank', ACTCProcessStateByRoleEnum.mentor],
      ['manager__mentor_attached_receipt', ACTCProcessStateByRoleEnum.manager],
      ['mentor__receipt_update_requested', ACTCProcessStateByRoleEnum.mentor],
      ['end__boosting', ACTCProcessStateByRoleEnum.end],
      ['end__boosting_mentor_detached_client', ACTCProcessStateByRoleEnum.end],
      ['client__boosting', ACTCProcessStateByRoleEnum.client],
    ])('should return client and number', (str, stateByRole) => {
      expect(getRoleFromState(str)).toEqual(stateByRole);
    });
  });
});
