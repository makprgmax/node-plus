import * as admin from 'firebase-admin';
import Timestamp = admin.firestore.Timestamp;

import {
  PaypalClientSubscription,
  PaypalClSubsViewCollectionsDictionary,
  PaypalPlan,
  PaypalPlanShort,
  PaypalProductType,
  PaypalProductTypeShort,
  PaypalSubscriptionState,
} from '../../interfaces';
import { db } from '../../init';
import {
  getUserByUidAsync,
  getUserProfileByUidAsync,
} from '../../triggers/utils';
import WriteResult = admin.firestore.WriteResult;
import WriteBatch = admin.firestore.WriteBatch;
import {
  convertStringArrayToSearchIndexMap,
  createSearchIndexMap,
  generateDateRange,
  getLastFourDigitsFromPhoneNumber,
} from '../../search-index/search-index-utils';
import { sendEmail } from '../../utils';

// TODO move id creation to model file
const getPaypalClSubsViewId = (
  uid: string,
  paypalProductType: PaypalProductType,
  paypalPlanType: PaypalPlan
): string => {
  const productTypeShort = paypalProductType
    ? PaypalProductTypeShort[paypalProductType]
    : '_';
  if (paypalProductType === PaypalProductType.otherServices) {
    const planTypeShort = paypalPlanType
      ? PaypalPlanShort[paypalPlanType]
      : '_';
    return `${uid}-${productTypeShort}-${planTypeShort}`;
  } else {
    return `${uid}-${productTypeShort}`;
  }
};

interface UserData {
  displayName: string;
  email: string;
  phoneNumber: string;
  createdAt: Timestamp | undefined;
  updatedAt: Timestamp | undefined;
}

export const getUserDataByUidAsync = async (uid: string): Promise<UserData> => {
  const user = await getUserByUidAsync(uid);
  const { email, createdAt } = user || { email: '' };

  // and phone number from userProfiles by uid
  const userProfile = await getUserProfileByUidAsync(uid);
  const { phoneNumber, firstName, lastName, updatedAt } = userProfile || {
    phoneNumber: '',
  };
  const displayName = `${firstName || ''} ${lastName || ''}`.trim();
  return {
    displayName,
    email,
    phoneNumber,
    createdAt,
    updatedAt,
  };
};

export const createPaypalClSubsViewPending = async (
  paypalClientSubscription: PaypalClientSubscription
): Promise<WriteResult[] | null> => {
  try {
    if (
      paypalClientSubscription === null ||
      !paypalClientSubscription.uid ||
      paypalClientSubscription.state !== PaypalSubscriptionState.init_pending
    ) {
      return Promise.resolve(null);
    }
    const {
      uid,
      paypalProductType,
      paypalPlanType,
      state,
      createdAt,
      updatedAt,
      id: paypalClientSubscriptionId,
    } = paypalClientSubscription;
    // get user data from user and userProfile by uid
    const {
      displayName,
      email,
      phoneNumber,
      createdAt: userCreatedAt,
    } = await getUserDataByUidAsync(uid);

    // and create new item
    const pendingViewId = getPaypalClSubsViewId(
      uid,
      paypalProductType,
      paypalPlanType
    );
    const collectionName =
      PaypalClSubsViewCollectionsDictionary[
        PaypalSubscriptionState.init_pending
      ];
    const paypalClSubsViewPendingRef = db.doc(
      `${collectionName}/${pendingViewId}`
    );

    const pendingViewData = {
      id: pendingViewId,
      uid,
      paypalProductType,
      paypalPlanType,
      email,
      displayName,
      phoneNumber,
      paypalClientSubscriptionId,
      userCreatedAt,
      createdAt,
      updatedAt,
      state,

      // make sure we clear this field, in case it was set previously
      _deleted: null,
    };
    const batch: WriteBatch = db.batch();
    batch.set(paypalClSubsViewPendingRef, pendingViewData);

    return batch.commit();
  } catch (e) {
    await sendEmail(`createPaypalClSubsViewPending - ${e?.message}`, e);
    return null;
  }
};

export const updatePaypalClSubsView = async (
  paypalClientSubscription: PaypalClientSubscription
): Promise<WriteResult[] | null> => {
  try {
    const {
      uid,
      paypalProductType,
      paypalPlanType,
      state,
      createdAt,
      updatedAt,
      id: paypalClientSubscriptionId,
    } = paypalClientSubscription;

    // get user data from user and userProfile by uid
    const {
      displayName,
      email,
      phoneNumber,
      createdAt: userCreatedAt,
    } = await getUserDataByUidAsync(uid);
    // get searchIndex
    const indexStrings = [displayName || '', email || '', phoneNumber || ''];
    const searchIndex = {
      ...createSearchIndexMap(indexStrings),
      ...convertStringArrayToSearchIndexMap([
        getLastFourDigitsFromPhoneNumber(phoneNumber || ''),
        ...generateDateRange(userCreatedAt, 1),
      ]),
    };

    // generate subjectId
    const paypalClSubsViewId = getPaypalClSubsViewId(
      uid,
      paypalProductType,
      paypalPlanType
    );

    // get collection name based on paypal state
    const collectionName = PaypalClSubsViewCollectionsDictionary[state];

    // if collectionName is not defined, then send alert log to email and stop the function
    if (!collectionName) {
      await sendEmail(
        `updatePaypalClSubsView - collectionName is not defined (state = ${state})`,
        paypalClientSubscription
      );
      return null;
    }

    // get a subject ref
    const paypalClSubsViewRef = db.doc(
      `${collectionName}/${paypalClSubsViewId}`
    );

    const paypalClSubsViewData = {
      id: paypalClSubsViewId,
      uid,
      paypalProductType,
      paypalPlanType,
      email,
      displayName,
      phoneNumber,
      paypalClientSubscriptionId,
      userCreatedAt,
      createdAt,
      updatedAt,
      state,
      searchIndex,

      // make sure we clear this field, in case it was set previously
      _deleted: null,
    };

    const batch: WriteBatch = db.batch();
    batch.set(paypalClSubsViewRef, paypalClSubsViewData);
    return batch.commit();
  } catch (e) {
    await sendEmail(`updatePaypalClSubsView - ${e?.message}`, e);
    return null;
  }
};

export const deletePaypalClSubsView = async (
  paypalClientSubscriptionOutdated: PaypalClientSubscription,
  paypalClientSubscriptionNew: PaypalClientSubscription
): Promise<WriteResult[] | null> => {
  try {
    const {
      uid,
      paypalProductType,
      paypalPlanType,
      state,
    } = paypalClientSubscriptionOutdated;

    // generate subjectId
    const paypalClSubsViewId = getPaypalClSubsViewId(
      uid,
      paypalProductType,
      paypalPlanType
    );

    // get collection name based on paypal state
    const collectionName = PaypalClSubsViewCollectionsDictionary[state];

    // if collectionName is not defined, then send alert log to email and stop the function
    if (!collectionName) {
      await sendEmail(
        `deletePaypalClSubsView - collectionName is not defined (state = ${state})`,
        paypalClientSubscriptionOutdated
      );
      return null;
    }

    // get a subject ref
    const paypalClSubsViewRef = db.doc(
      `${collectionName}/${paypalClSubsViewId}`
    );

    // _deleted date is equal to the date when the new subscription was updated
    // (replaced the outdated one)
    const paypalClSubsViewData = {
      _deleted: paypalClientSubscriptionNew.updatedAt,
    };

    const batch: WriteBatch = db.batch();
    batch.update(paypalClSubsViewRef, paypalClSubsViewData);
    return batch.commit();
  } catch (e) {
    await sendEmail(`deletePaypalClSubsView - ${e?.message}`, e);
    return null;
  }
};
