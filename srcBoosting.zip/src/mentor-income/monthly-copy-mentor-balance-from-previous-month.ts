import * as admin from 'firebase-admin';
import Timestamp = admin.firestore.Timestamp;
import { APIResult, MentorBalance } from '../interfaces';
import { getIdWithPeriod, getPeriodFromDate } from './income';
import { sendLogToEmail, SendLogToEmailProps } from '../utils';
import { environment } from '../environments/environment';
import { db } from '../init';
import {
  getAllMentorBalanceByPeriod,
  sortMentorBalanceAryByMentorId,
} from './daily-update-mentor-balance';
import { EventContext } from 'firebase-functions';
import { BatchPlus, batchPlus } from '../batch-plus';

export interface CopyMentorBalanceFromPreviousMonthProps {
  previousPeriodMentorBalanceAry: MentorBalance[];
  currentPeriodMentorBalanceAry: MentorBalance[];
  currentTimestamp: Timestamp;
}
export const copyMentorBalanceFromPreviousMonth = (
  props: CopyMentorBalanceFromPreviousMonthProps
): MentorBalance[] => {
  const {
    currentPeriodMentorBalanceAry,
    currentTimestamp,
    previousPeriodMentorBalanceAry,
  } = props;
  const currentPeriod = getPeriodFromDate(currentTimestamp.toDate());
  const currentPeriodMentorBalanceMap = sortMentorBalanceAryByMentorId(
    currentPeriodMentorBalanceAry
  );
  const resultAry: MentorBalance[] = [];
  previousPeriodMentorBalanceAry.forEach((previousMentorBalance) => {
    // if balance for the current period does not exist yet
    if (!currentPeriodMentorBalanceMap[previousMentorBalance.mentorId]) {
      // then copy it for the current period
      const {
        mentorId,
        totalBalance,
        totalWithdrawal,
        totalIncome,
      } = previousMentorBalance;
      const item = {
        id: getIdWithPeriod(mentorId, currentPeriod),
        mentorId,
        periodIncome: 0,
        periodBalance: 0,
        periodWithdrawal: 0,
        totalIncome,
        totalBalance,
        totalWithdrawal,
        createdAt: currentTimestamp,
        period: currentPeriod,
      } as MentorBalance;

      resultAry.push(item);
    }
  });
  return resultAry;
};

export async function monthlyCopyMentorBalanceFromPreviousMonth(
  context?: EventContext
): Promise<APIResult> {
  const result: APIResult = {};
  let counter = 1;
  const currentTimestamp = Timestamp.now();
  const currentDate = currentTimestamp.toDate();
  const currentPeriod = getPeriodFromDate(currentDate);
  const previousMonth = currentDate.getMonth() - 1;
  // use date == 2 to avoid shift to pre previous month due to time zone shift
  const previousDate = new Date(currentDate.getFullYear(), previousMonth, 2);
  const previousPeriod = getPeriodFromDate(previousDate);
  let currentPeriodMentorBalanceAry: MentorBalance[];
  let previousPeriodMentorBalanceAry: MentorBalance[];
  let mentorBalanceToInsertIntoDB: MentorBalance[];

  const sendEmail: SendLogToEmailProps = {
    to: environment.sendEmails.developers,
    subject: 'monthly-copy-mentor-balance-from-previous-month',
    log: {},
  };

  try {
    // get all mentorBalance records
    const balanceIdentity = (item: MentorBalance) => item;
    currentPeriodMentorBalanceAry = await getAllMentorBalanceByPeriod<MentorBalance>(
      currentPeriod,
      balanceIdentity
    );
    result[
      `${counter++}) currentPeriodMentorBalanceAry`
    ] = currentPeriodMentorBalanceAry;

    previousPeriodMentorBalanceAry = await getAllMentorBalanceByPeriod<MentorBalance>(
      previousPeriod,
      balanceIdentity
    );
    result[
      `${counter++}) previousPeriodMentorBalanceAry`
    ] = previousPeriodMentorBalanceAry;

    // create a copy of previous mentorBalance for current period
    mentorBalanceToInsertIntoDB = copyMentorBalanceFromPreviousMonth({
      currentTimestamp,
      currentPeriodMentorBalanceAry,
      previousPeriodMentorBalanceAry,
    });
    result[
      `${counter++}) mentorBalanceToUpdateInDB`
    ] = mentorBalanceToInsertIntoDB;
    // run db batch
    if (mentorBalanceToInsertIntoDB.length > 0) {
      const batch: BatchPlus<MentorBalance> = batchPlus(db);
      mentorBalanceToInsertIntoDB.forEach((balance) => {
        const ref = db.doc(`mentorBalance/${balance.id}`);
        batch.set(ref, balance);
      });
      await batch.commit();
    }
    result.emailLog = {
      'Inserted new items to mentorBalance': mentorBalanceToInsertIntoDB.length,
      context,
    };
    sendEmail.log = result.emailLog || {};
    await sendLogToEmail(sendEmail);
  } catch (e) {
    console.error(e);
    sendEmail.log = { error: e };
    await sendLogToEmail(sendEmail);
    throw e;
  }

  return Promise.resolve(result);
}
