import * as admin from 'firebase-admin';
import Timestamp = admin.firestore.Timestamp;
import { getCollection } from '../utils';
import {
  CardLevel,
  MonthlyIncomeRegistry,
  MonthlyRate,
  Period,
} from '../interfaces';

export const getIdWithPeriod = <T extends string>(
  id: string,
  period: Period
): T => `${id}-${period}` as T;
export const getPeriodFromDate = (d: Date): Period =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;

export const isEndOfPeriod = (fromDate: Date, toDate: Date): boolean => {
  const fromYear = fromDate.getFullYear();
  const toYear = toDate.getFullYear();
  const fromMonth = fromDate.getMonth();
  const toMonth = toDate.getMonth();
  if (fromYear * 12 + fromMonth >= toYear * 12 + toMonth) {
    return false;
  }
  const fromDay = fromDate.getDate();
  const toDay = toDate.getDate();
  return fromDay <= toDay || getLastDayOfMonth(toDate) === toDay;
};

export const getCardLevel = (ageInMonths: number): CardLevel => {
  if (ageInMonths < 0) {
    return 0;
  } else if (ageInMonths < 24) {
    return 1;
  } else if (ageInMonths < 60) {
    return 2;
  } else if (ageInMonths < 84) {
    return 3;
  } else if (ageInMonths < 120) {
    return 4;
  } else {
    return 5;
  }
};

export const getLastDayOfMonth = (d: Date): number => {
  const lastDayOfMonth = new Date(d.getFullYear(), d.getMonth() + 1, 0);
  return lastDayOfMonth.getDate();
};

export const getFullMonthsDiff = (
  older: Timestamp | undefined,
  later: Timestamp | undefined
): number => {
  if (older === undefined || later === undefined) {
    return -1;
  }
  const olderD = older.toDate();
  const laterD = later.toDate();
  const monthDiff =
    (laterD.getUTCFullYear() - olderD.getUTCFullYear()) * 12 +
    (laterD.getUTCMonth() - olderD.getUTCMonth());

  let incompleteMonth;
  if (laterD.getUTCDate() >= olderD.getUTCDate()) {
    incompleteMonth = 0;
  } else {
    // 0 = if laterD.day is the last day of month then it is a complete month
    // 1 = otherwise incomplete month
    incompleteMonth = laterD.getDate() >= getLastDayOfMonth(laterD) ? 0 : 1;
  }
  return monthDiff - incompleteMonth;
};

export const getMonthRange = (from?: Timestamp, to?: Timestamp): Period[] => {
  if (from === undefined || to === undefined) {
    return [];
  }
  const fromD = from.toDate();
  const toD = to.toDate();
  const range: Period[] = [];
  const currentD = from.toDate();
  currentD.setDate(1);
  currentD.setMonth(currentD.getMonth() + 1);
  while (currentD < toD) {
    range.push(getPeriodFromDate(currentD));
    currentD.setMonth(currentD.getMonth() + 1);
  }
  if (!isEndOfPeriod(fromD, toD)) {
    range.pop();
  }
  return range;
};

export interface MonthlyIncomeRegistryObject {
  getMonthlyIncomeRate: (cardLevel: number, period: string) => MonthlyRate;
}

export type CardLevelPeriodMonthlyRateMap = Record<
  CardLevel,
  Record<Period, MonthlyRate>
>;

export function getMonthlyIncomeRegistry(
  dbRegistry: CardLevelPeriodMonthlyRateMap = {}
): MonthlyIncomeRegistryObject {
  const defaultRegistry: Record<CardLevel, MonthlyRate> = {
    0: 25, // 0: 0,
    1: 25, // 1: 8,
    2: 25, // 2: 13,
    3: 25, // 3: 17,
    4: 25, // 4: 25,
    5: 25, // 5: 30,
  };
  const getMonthlyIncomeRate = (
    cardLevel: CardLevel,
    period: Period
  ): MonthlyRate => {
    return (
      (dbRegistry[cardLevel] && dbRegistry[cardLevel][period]) ||
      defaultRegistry[cardLevel]
    );
  };
  return {
    getMonthlyIncomeRate,
  };
}

// TODO this function should be tested
export async function convertMonthlyIncomeRegistryCollectionToMap(): Promise<CardLevelPeriodMonthlyRateMap> {
  // TODO replace with paginated collection to read all data
  const monthlyIncomeRegistry = await getCollection('monthlyIncomeRegistry');
  const registryMap: CardLevelPeriodMonthlyRateMap = {};
  monthlyIncomeRegistry.forEach((value) => {
    const data = value.data() as MonthlyIncomeRegistry;
    if (!registryMap[data.cardLevel]) {
      registryMap[data.cardLevel] = {};
    }
    registryMap[data.cardLevel][data.period] = data.monthlyRate;
  });
  console.log('monthlyIncomeRegistry = ');
  console.log(JSON.stringify(registryMap, null, 2));
  return Promise.resolve(registryMap);
}
