import * as admin from 'firebase-admin';
import Timestamp = admin.firestore.Timestamp;
import {
  CardLevelPeriodMonthlyRateMap,
  getCardLevel,
  getFullMonthsDiff,
  getIdWithPeriod,
  getLastDayOfMonth,
  getMonthlyIncomeRegistry,
  getMonthRange,
  getPeriodFromDate,
  isEndOfPeriod,
  MonthlyIncomeRegistryObject,
} from './income';
import { getTimestampFromDateString } from '../utils';
import { CardLevel, Period } from '../interfaces';

describe('getCardLevel', () => {
  type Case = [number, number];
  const cases: Case[] = [
    [-1, 0],
    [0, 1],
    [1, 1],
    [23, 1],
    [24, 2],
    [25, 2],
    [59, 2],
    [60, 3],
    [61, 3],
    [83, 3],
    [84, 4],
    [85, 4],
    [119, 4],
    [120, 5],
    [121, 5],
  ];
  const generateCase = ([months, expectedLevel]: Case) => {
    it(`when card is ${months} months old, then Level is ${expectedLevel}`, () => {
      const actual = getCardLevel(months);
      expect(actual).toEqual(expectedLevel);
    });
  };
  cases.forEach(generateCase);
});

describe('getLastDayOfMonth', () => {
  type Case = [string, number];
  const cases: Case[] = [
    ['2020-02-01', 29],
    ['2019-02-05', 28],
    ['2020-01-10', 31],
    ['2020-03-20', 31],
    ['2020-04-20', 30],
  ];
  const generateCase = ([dateString, expected]: Case) => {
    const aDate = new Date(dateString);
    it(`for date '${dateString}' result should be ${expected}`, () => {
      const actual = getLastDayOfMonth(aDate);
      expect(actual).toEqual(expected);
    });
  };
  cases.forEach(generateCase);
});

describe('getFullMonthsDiff', () => {
  interface Case {
    params: [string | undefined, string | undefined];
    expected: number;
  }
  const cases: Case[] = [
    {
      params: ['2019-01-02', '2020-01-01'],
      expected: 11,
    },
    {
      params: ['2019-01-02', '2020-01-02'],
      expected: 12,
    },
    {
      params: ['2019-01-02', '2020-01-03'],
      expected: 12,
    },
    {
      params: ['2019-01-31', '2020-02-28'], // it's NOT the last day of month
      expected: 12,
    },
    {
      params: ['2019-01-31', '2020-02-29'], // it's the last day of month
      expected: 13,
    },
    {
      params: ['2019-01-31', '2019-02-27'], // it's NOT the last day of month
      expected: 0,
    },
    {
      params: ['2019-01-31', '2019-02-28'], // it's the last day of month
      expected: 1,
    },
    {
      params: ['2019-01-31', undefined], // it's the last day of month
      expected: -1,
    },
    {
      params: [undefined, '2019-01-31'], // it's the last day of month
      expected: -1,
    },
    {
      params: [undefined, undefined], // it's the last day of month
      expected: -1,
    },
  ];
  const generateCase = (item: Case) => {
    const params = item.params.map((d) => getTimestampFromDateString(d));
    it(`for params [${item.params.join(', ')} should return ${
      item.expected
    }`, () => {
      const actual = getFullMonthsDiff.apply(
        null,
        params as [Timestamp | undefined, Timestamp | undefined]
      );
      expect(actual).toEqual(item.expected);
    });
  };
  cases.forEach(generateCase);
});

describe('getMonthRange', () => {
  interface Case {
    params: [string?, string?]; // from, to
    expected: string[];
  }
  const cases: Case[] = [
    {
      params: ['2019-01-15', undefined],
      expected: [],
    },
    {
      params: [undefined, '2019-01-15'],
      expected: [],
    },
    {
      params: [undefined, undefined],
      expected: [],
    },
    {
      params: [],
      expected: [],
    },
    {
      params: ['2019-01-15', '2019-01-17'],
      expected: [],
    },
    {
      params: ['2019-01-15', '2020-01-14'],
      expected: [
        '2019-02',
        '2019-03',
        '2019-04',
        '2019-05',
        '2019-06',
        '2019-07',
        '2019-08',
        '2019-09',
        '2019-10',
        '2019-11',
        '2019-12',
      ],
    },
    {
      params: ['2019-01-15', '2020-01-15'],
      expected: [
        '2019-02',
        '2019-03',
        '2019-04',
        '2019-05',
        '2019-06',
        '2019-07',
        '2019-08',
        '2019-09',
        '2019-10',
        '2019-11',
        '2019-12',
        '2020-01',
      ],
    },
    {
      params: ['2019-01-15', '2019-02-14'],
      expected: [],
    },
    {
      params: ['2019-01-15', '2019-02-15'],
      expected: ['2019-02'],
    },
    {
      params: ['2019-01-31', '2019-02-27'],
      expected: [],
    },
    {
      params: ['2019-01-31', '2019-02-28'],
      expected: ['2019-02'],
    },
    {
      params: ['2019-01-31', '2019-04-30'],
      expected: ['2019-02', '2019-03', '2019-04'],
    },
    {
      params: ['2019-01-31', '2019-05-30'],
      expected: ['2019-02', '2019-03', '2019-04'],
    },
    {
      params: ['2019-01-31', '2019-05-31'],
      expected: ['2019-02', '2019-03', '2019-04', '2019-05'],
    },
  ];
  const generateCase = (item: Case) => {
    it(`from '${item.params[0]}' to '${item.params[1]}' should generate ${item.expected.length} item(s)`, () => {
      const actual = getMonthRange.apply(
        null,
        item.params.map((d) => getTimestampFromDateString(d)) as [
          Timestamp,
          Timestamp
        ]
      );
      expect(actual).toEqual(item.expected);
    });
  };

  cases.forEach(generateCase);
});

describe('getMonthlyIncomeRegistry', () => {
  interface Case {
    params: [CardLevel, Period];
    expected: number;
  }
  const cases: Case[] = [
    {
      params: [0, '2020-09'],
      expected: 25,
    },
    {
      params: [1, '2020-09'],
      expected: 25,
    },
    {
      params: [2, '2020-09'],
      expected: 25,
    },
    {
      params: [3, '2020-09'],
      expected: 25,
    },
    {
      params: [4, '2020-09'],
      expected: 25,
    },
    {
      params: [5, '2020-09'],
      expected: 25,
    },
    {
      params: [5, '2020-12'],
      expected: 45,
    },
    // TODO support next case
    // {
    //   params: [5, '2021-02'],
    //   expected: 45,
    // },
  ];
  const generateCase = (monthlyIncomeRegistry: MonthlyIncomeRegistryObject) => (
    item: Case
  ) => {
    const {
      params: [cardLevel, period],
      expected,
    } = item;
    it(`for cardLevel = ${cardLevel} and period = '${period}' income is ${expected}`, () => {
      const actual = monthlyIncomeRegistry.getMonthlyIncomeRate(
        cardLevel,
        period
      );
      expect(actual).toEqual(expected);
    });
  };

  const dbRegistry: CardLevelPeriodMonthlyRateMap = {
    5: {
      '2020-12': 45,
    },
  };
  cases.forEach(generateCase(getMonthlyIncomeRegistry(dbRegistry)));
});

describe('getPeriodFromDate', () => {
  type Case = [string, string];
  const cases: Case[] = [
    ['2020-01-01', '2020-01'],
    ['2020-02-29', '2020-02'],
    ['2020-02-30', '2020-03'],
    ['2019-02-28', '2019-02'],
  ];
  const generateCase = (item: Case) => {
    const d = new Date(item[0]);
    const expected = item[1];
    it(`for date '${item[0]}', period is '${expected}'`, () => {
      expect(getPeriodFromDate(d)).toEqual(expected);
    });
  };
  cases.forEach(generateCase);
});

describe('getIdWithPeriod', () => {
  it('should return a string with dash between id and period', () => {
    const id = 'abc';
    const period = '2020-09';
    expect(getIdWithPeriod(id, period)).toEqual(`${id}-${period}`);
  });
});

describe('isEndOfPeriod', () => {
  type BoostingStartedDateString = string;
  type CurrentDateString = string;
  type Expected = boolean;
  type Case = [BoostingStartedDateString, CurrentDateString, Expected];
  const cases: Case[] = [
    ['2019-01-15', '2019-02-15', true],
    ['2019-01-15', '2019-02-14', false],
    ['2019-01-27', '2019-02-27', true],
    ['2019-01-28', '2019-02-27', false],
    ['2019-01-28', '2019-02-28', true],
    ['2019-01-29', '2019-02-27', false],
    ['2019-01-29', '2019-02-28', true],
    ['2019-01-30', '2019-02-27', false],
    ['2019-01-30', '2019-02-28', true],
    ['2019-01-31', '2019-02-27', false],
    ['2019-01-31', '2019-02-28', true],
    ['2019-01-31', '2019-02-29', false], // 2019-02-29 is actually 2019-03-01
    ['2019-01-15', '2019-01-16', false],
    ['2019-01-15', '2019-01-20', false],
    ['2019-01-01', '2019-01-31', false],
    ['2019-01-01', '2018-01-31', false],
    ['2019-01-01', '2018-02-01', false],
    ['2019-01-01', '2020-01-01', true],
    ['2019-01-01', '2019-02-01', true],
  ];
  const generateCase = (item: Case) => {
    const [boosting, current, expected] = item;
    const boostingD = new Date(boosting);
    const currentD = new Date(current);
    it(`${boosting} -> ${current} :: ${String(expected)}`, () => {
      expect(isEndOfPeriod(boostingD, currentD)).toEqual(expected);
    });
  };
  cases.forEach(generateCase);
});
