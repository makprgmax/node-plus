import * as admin from 'firebase-admin';
import Timestamp = admin.firestore.Timestamp;
import { getPaginatedCollection, PaginatedCollection } from '../utils';
import {
  MentorProcessPeriodIncome,
  MentorPeriodIncome,
  MentorPeriodIncomeId,
} from '../interfaces';
import { db } from '../init';
import { getIdWithPeriod } from './income';
import { batchPlus, BatchPlus } from '../batch-plus';

export async function updateMentorPeriodIncome(): Promise<Record<string, any>> {
  const result: Record<string, any> = {};
  const now: Timestamp = Timestamp.now();
  const paginatedCollection = getPaginatedCollection<MentorProcessPeriodIncome>(
    {
      collection: 'mentorProcessPeriodIncome',
    }
  );

  console.log('FIRST PAGE');
  let counter = 1;
  let mentorIncome: MentorProcessPeriodIncome;
  let collection: PaginatedCollection<MentorProcessPeriodIncome> = await paginatedCollection.run();

  const periodIncomes: Record<MentorPeriodIncomeId, MentorPeriodIncome> = {};

  do {
    for (const doc of collection.querySnapshot.docs) {
      mentorIncome = doc.data();
      const { mentorId, period, periodIncome } = mentorIncome;
      console.log(`item ${counter}`);
      const id = getIdWithPeriod<MentorPeriodIncomeId>(mentorId, period);
      if (!periodIncomes[id]) {
        periodIncomes[id] = {
          id,
          createdAt: now,
          mentorId,
          period,
          periodIncome: 0,
        } as MentorPeriodIncome;
      }
      periodIncomes[id].periodIncome += periodIncome;
      // log
      result[`${counter}) ${mentorId} ${period} income`] = periodIncome;
      counter++;
    }
    if (collection.hasNext) {
      collection = await collection.next();
      console.log(`NEXT PAGE`);
    } else {
      break;
    }
  } while (true);
  result['------'] = '======';
  const batch: BatchPlus<MentorPeriodIncome> = batchPlus(db);

  for (const key in periodIncomes) {
    if (periodIncomes.hasOwnProperty(key)) {
      result[key] = periodIncomes[key];
      const ref = db.doc(`mentorPeriodIncome/${periodIncomes[key].id}`);
      batch.set(ref, periodIncomes[key]);
    }
  }
  try {
    await batch.commit();
    return Promise.resolve(result);
  } catch (e) {
    return Promise.reject(e);
  }
}
