import {
  APIResult,
  MentorPeriodIncome,
  MentorPeriodIncomeId,
  MentorProcessPeriodIncome,
  Period,
} from '../interfaces';
import { getIdWithPeriod, getPeriodFromDate } from './income';
import * as admin from 'firebase-admin';
import Timestamp = admin.firestore.Timestamp;
import { getAllMentorProcessPeriodIncomesByPeriod } from './daily-update-mentor-process-period-income';
import {
  getPaginatedCollection,
  iterateThroughPaginatedCollection,
  sendLogToEmail,
  SendLogToEmailProps,
} from '../utils';
import WriteBatch = admin.firestore.WriteBatch;
import { db } from '../init';
import { environment } from '../environments/environment';
import { EventContext } from 'firebase-functions';
import { SEND_EMAIL_ON_SUCCESS } from './constants';

export interface NewMentorPeriodIncomeItemProps {
  currentTimestamp: Timestamp;
  mentorProcessPeriodIncome: MentorProcessPeriodIncome;
}
export function newMentorPeriodIncomeItem(
  props: NewMentorPeriodIncomeItemProps
): MentorPeriodIncome {
  const { currentTimestamp, mentorProcessPeriodIncome } = props;
  const { mentorId, period } = mentorProcessPeriodIncome;
  const id = getIdWithPeriod<MentorPeriodIncomeId>(mentorId, period);
  return {
    id,
    createdAt: currentTimestamp,
    period,
    mentorId,
    periodIncome: 0,
  };
}

export const sumUp = (items?: number[]): number => {
  return Array.isArray(items) ? items.reduce((acc, next) => acc + next, 0) : 0;
};
export const sumUpPeriodIncome = (
  mppIncomes?: MentorProcessPeriodIncome[]
): number => {
  return sumUp(
    Array.isArray(mppIncomes)
      ? mppIncomes.map((item) => item?.periodIncome || 0)
      : undefined
  );
};
export const getAllMentorPeriodIncomesByPeriod = async <R>(
  period: Period,
  identity: (item: MentorPeriodIncome) => R
): Promise<R[]> => {
  /**/
  const paginatedCollection = getPaginatedCollection<MentorPeriodIncome>({
    collection: 'mentorPeriodIncome',
    where: {
      fieldPath: 'period',
      opStr: '==',
      value: period,
    },
    orderByDirection: 'desc',
  });
  const collection = await paginatedCollection.run();
  return iterateThroughPaginatedCollection<MentorPeriodIncome, R>({
    collection,
    identity,
  });
};

export interface RecalculateMentorPeriodIncomeProps {
  currentTimestamp: Timestamp;
  mppIncomes: MentorProcessPeriodIncome[];
  currentMPIncome?: MentorPeriodIncome;
}
export const recalculateMentorPeriodIncome = (
  props: RecalculateMentorPeriodIncomeProps
): MentorPeriodIncome | undefined => {
  const { currentMPIncome, currentTimestamp, mppIncomes } = props;
  const newMentorPeriodIncome: MentorPeriodIncome = newMentorPeriodIncomeItem({
    currentTimestamp,
    mentorProcessPeriodIncome: mppIncomes[0],
  });
  newMentorPeriodIncome.periodIncome = sumUpPeriodIncome(mppIncomes);
  if (!currentMPIncome) {
    return newMentorPeriodIncome;
  } else {
    if (currentMPIncome.periodIncome === newMentorPeriodIncome.periodIncome) {
      return undefined;
    }
    return {
      ...newMentorPeriodIncome,
      createdAt: currentMPIncome.createdAt,
      updatedAt: newMentorPeriodIncome.createdAt,
    };
  }
};

export type MPPIncomesByMPIncomeId = Record<
  MentorPeriodIncomeId,
  MentorProcessPeriodIncome[]
>;
export const sortMPPIncomesByMPIncomeId = (
  mppIncomes: MentorProcessPeriodIncome[]
): MPPIncomesByMPIncomeId => {
  const mapping: MPPIncomesByMPIncomeId = {};
  mppIncomes.forEach((item) => {
    const { period, mentorId } = item;
    const id = getIdWithPeriod<MentorPeriodIncomeId>(mentorId, period);
    if (!mapping[id]) {
      mapping[id] = [];
    }
    mapping[id].push(item);
  });
  return mapping;
};

export type MPIncomesById = Record<MentorPeriodIncomeId, MentorPeriodIncome>;
export const sortMPIncomesById = (
  mpIncomes: MentorPeriodIncome[]
): MPIncomesById => {
  const mapping: MPIncomesById = {};
  mpIncomes.forEach((item) => {
    mapping[item.id] = item;
  });
  return mapping;
};

export async function dailyUpdateMentorPeriodIncome(
  context?: EventContext
): Promise<APIResult> {
  const result: APIResult = {};
  let counter = 1;
  const currentTimestamp = Timestamp.now();
  const currentPeriod = getPeriodFromDate(currentTimestamp.toDate());
  let mppIncomeAry: MentorProcessPeriodIncome[];
  let periodIncomeAry: MentorPeriodIncome[];
  const mpIncomesToUpdateInDB: MentorPeriodIncome[] = [];

  const sendEmail: SendLogToEmailProps = {
    to: environment.sendEmails.developers,
    subject: 'daily-update-mentor-period-income',
    log: {},
  };

  try {
    // get all mentorPeriodIncome records
    const mpIncomeIdentity = (item: MentorPeriodIncome) => item;
    periodIncomeAry = await getAllMentorPeriodIncomesByPeriod<MentorPeriodIncome>(
      currentPeriod,
      mpIncomeIdentity
    );
    result[`${counter++}) periodIncomeAry`] = periodIncomeAry;

    // get all mentorProcessPeriodIncome records
    const mppIncomeIdentity = (item: MentorProcessPeriodIncome) => item;
    mppIncomeAry = await getAllMentorProcessPeriodIncomesByPeriod<MentorProcessPeriodIncome>(
      currentPeriod,
      mppIncomeIdentity
    );
    result[`${counter++}) mppIncomeAry`] = mppIncomeAry;

    // recalculate periodIncome
    const periodIncomeMap = sortMPIncomesById(periodIncomeAry);
    result[`${counter++}) periodIncomeMap`] = periodIncomeMap;

    const mppIncomesByMPIncomeId = sortMPPIncomesByMPIncomeId(mppIncomeAry);
    result[`${counter++}) mppIncomesByMPIncomeId`] = mppIncomesByMPIncomeId;

    Object.keys(mppIncomesByMPIncomeId).forEach((mpiId) => {
      const item = recalculateMentorPeriodIncome({
        currentMPIncome: periodIncomeMap[mpiId],
        mppIncomes: mppIncomesByMPIncomeId[mpiId],
        currentTimestamp,
      });
      if (item) {
        mpIncomesToUpdateInDB.push(item);
      }
    });
    result[`${counter++}) mpIncomesToUpdateInDB`] = mpIncomesToUpdateInDB;

    // run db batch
    let updatedCounter = 0;
    let insertedCounter = 0;
    if (mpIncomesToUpdateInDB.length > 0) {
      const batch: WriteBatch = db.batch();
      mpIncomesToUpdateInDB.forEach((income) => {
        const ref = db.doc(`mentorPeriodIncome/${income.id}`);
        if (income.updatedAt) {
          batch.update(ref, income);
          updatedCounter++;
        } else {
          batch.set(ref, income);
          insertedCounter++;
        }
      });
      await batch.commit();
    }
    result.emailLog = {
      'Inserted new items to mentorPeriodIncome': insertedCounter,
      'Updated items in mentorPeriodIncome': updatedCounter,
      context,
    };
    sendEmail.log = result.emailLog || {};
    if (SEND_EMAIL_ON_SUCCESS) {
      await sendLogToEmail(sendEmail);
    } else {
      console.log({ sendEmail });
    }
  } catch (e) {
    console.error(e);
    sendEmail.log = { error: e };
    await sendLogToEmail(sendEmail);
    throw e;
  }
  return Promise.resolve(result);
}
