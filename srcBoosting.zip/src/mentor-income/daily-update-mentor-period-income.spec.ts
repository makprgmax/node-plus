import {
  newMentorPeriodIncomeItem,
  NewMentorPeriodIncomeItemProps,
  recalculateMentorPeriodIncome,
  RecalculateMentorPeriodIncomeProps,
  sortMPIncomesById,
  sortMPPIncomesByMPIncomeId,
  sumUp,
  sumUpPeriodIncome,
} from './daily-update-mentor-period-income';
import * as admin from 'firebase-admin';
import Timestamp = admin.firestore.Timestamp;
import {
  MentorPeriodIncome,
  MentorPeriodIncomeId,
  MentorProcessPeriodIncome,
  Period,
} from '../interfaces';
import { getIdWithPeriod } from './income';

describe('daily-update-mentor-period-income', () => {
  describe('newMentorPeriodIncomeItem', () => {
    let subject: MentorPeriodIncome;
    const currentTimestamp = Timestamp.now();
    const period: Period = '2020-09';
    const mentorId = 'mentorId';
    beforeAll(() => {
      const mentorProcessPeriodIncome: MentorProcessPeriodIncome = {
        id: 'bla',
        period,
        mentorId,
        periodIncome: 8,
        cardLevel: 1,
        createdAt: currentTimestamp,
        actcProcessId: 'actcProcessId',
        mentorCardId: 'mentorCardId',
      };
      const props: NewMentorPeriodIncomeItemProps = {
        currentTimestamp,
        mentorProcessPeriodIncome,
      };
      subject = newMentorPeriodIncomeItem(props);
    });
    it('should have valid id = mentorId + period', () => {
      expect(subject.id).toEqual(`${mentorId}-${period}`);
    });
    it('should have valid createdAt', () => {
      expect(subject.createdAt).toEqual(currentTimestamp);
    });
    it('should have periodIncome === 0', () => {
      expect(subject.periodIncome).toEqual(0);
    });
    it('should have period', () => {
      expect(subject.period).toEqual(period);
    });
    it('should have mentorId', () => {
      expect(subject.mentorId).toEqual(mentorId);
    });
  });

  describe('sumUp', () => {
    it('should return sum of elements', () => {
      expect(sumUp([1, 2, 3])).toEqual(6);
    });
  });

  describe('sumUpPeriodIncome', () => {
    it('should set correct periodIncome value', () => {
      const period: Period = '2020-09';
      const mentorId = 'mentorId';
      const mppIncomes: MentorProcessPeriodIncome[] = [
        {
          periodIncome: 1,
          period,
          mentorId,
        } as MentorProcessPeriodIncome,
        {
          periodIncome: 2,
          period,
          mentorId,
        } as MentorProcessPeriodIncome,
        {
          periodIncome: 3,
          period,
          mentorId,
        } as MentorProcessPeriodIncome,
      ];
      const actual = sumUpPeriodIncome(mppIncomes);
      expect(actual).toEqual(6);
    });
  });

  describe('recalculateMentorPeriodIncome', () => {
    const period: Period = '2020-09';
    const mentorId = 'mentorId';
    const mpiId = getIdWithPeriod<MentorPeriodIncomeId>(mentorId, period);
    const mppIncomes: MentorProcessPeriodIncome[] = [
      {
        periodIncome: 1,
        period,
        mentorId,
      } as MentorProcessPeriodIncome,
      {
        periodIncome: 2,
        period,
        mentorId,
      } as MentorProcessPeriodIncome,
      {
        periodIncome: 3,
        period,
        mentorId,
      } as MentorProcessPeriodIncome,
    ];
    const currentTimestamp = Timestamp.now();
    describe('when mentorPeriodIncome does not exist', () => {
      it('should return a new item', () => {
        const recalculateProps: RecalculateMentorPeriodIncomeProps = {
          currentTimestamp,
          mppIncomes,
          currentMPIncome: undefined,
        };
        const actual = recalculateMentorPeriodIncome(recalculateProps);
        const props: NewMentorPeriodIncomeItemProps = {
          mentorProcessPeriodIncome: mppIncomes[0],
          currentTimestamp,
        };
        const expected: MentorPeriodIncome = {
          ...newMentorPeriodIncomeItem(props),
          periodIncome: 6,
        };
        expect(actual).toEqual(expected);
      });
    });
    describe('when mentorPeriodIncome exists and has different periodIncome value', () => {
      it('should return an item with updated periodIncome, updatedAt, and old createdAt', () => {
        const originalCreatedAt = Timestamp.fromDate(new Date('2020-01-01'));
        const currentMPIncome = {
          mentorId,
          periodIncome: 1,
          period,
          id: mpiId,
          createdAt: originalCreatedAt,
        } as MentorPeriodIncome;
        const recalculateProps: RecalculateMentorPeriodIncomeProps = {
          currentTimestamp,
          mppIncomes,
          currentMPIncome,
        };
        const actual = recalculateMentorPeriodIncome(recalculateProps);
        const props: NewMentorPeriodIncomeItemProps = {
          mentorProcessPeriodIncome: mppIncomes[0],
          currentTimestamp,
        };
        const newItem = newMentorPeriodIncomeItem(props);
        const expected: MentorPeriodIncome = {
          ...newItem,
          periodIncome: 6,
          createdAt: originalCreatedAt,
          updatedAt: newItem.createdAt,
        };
        expect(actual).toEqual(expected);
      });
    });
    describe('when mentorPeriodIncome exists and has the same periodIncome value', () => {
      it('should return undefined', () => {
        const currentMPIncome = {
          mentorId,
          periodIncome: 6,
          period,
          id: mpiId,
        } as MentorPeriodIncome;
        const recalculateProps: RecalculateMentorPeriodIncomeProps = {
          currentTimestamp,
          mppIncomes,
          currentMPIncome,
        };
        const actual = recalculateMentorPeriodIncome(recalculateProps);
        expect(actual).toEqual(undefined);
      });
    });
  });
  describe('sortMppIncomesByMPIncomeId', () => {
    it('should return a record where key is MentorPeriodIncomeId, and value is array of MentorProcessPeriodIncome', () => {
      const period: Period = '2020-09';
      const mentorIdOne = 'mentorIdOne';
      const mentorIdTwo = 'mentorIdTwo';
      const mpiIdOne = getIdWithPeriod<MentorPeriodIncomeId>(
        mentorIdOne,
        period
      );
      const mpiIdTwo = getIdWithPeriod<MentorPeriodIncomeId>(
        mentorIdTwo,
        period
      );
      const mppIncomes: MentorProcessPeriodIncome[] = [
        {
          periodIncome: 1,
          period,
          mentorId: mentorIdOne,
        } as MentorProcessPeriodIncome,
        {
          periodIncome: 2,
          period,
          mentorId: mentorIdTwo,
        } as MentorProcessPeriodIncome,
        {
          periodIncome: 3,
          period,
          mentorId: mentorIdOne,
        } as MentorProcessPeriodIncome,
        {
          periodIncome: 4,
          period,
          mentorId: mentorIdTwo,
        } as MentorProcessPeriodIncome,
        {
          periodIncome: 5,
          period,
          mentorId: mentorIdOne,
        } as MentorProcessPeriodIncome,
      ];
      const actual = sortMPPIncomesByMPIncomeId(mppIncomes);
      expect(Object.keys(actual)).toEqual([mpiIdOne, mpiIdTwo]);
      expect(actual[mpiIdOne].length).toEqual(3);
      expect(actual[mpiIdTwo].length).toEqual(2);
      expect(actual[mpiIdOne][0].periodIncome).toEqual(1);
      expect(actual[mpiIdTwo][0].periodIncome).toEqual(2);
    });
  });
  describe('sortMpIncomesById', () => {
    it('should return a record where key is MentorPeriodIncomeId, and value is item itself', () => {
      const period: Period = '2020-09';
      const mentorIdOne = 'mentorIdOne';
      const mentorIdTwo = 'mentorIdTwo';
      const mpiIdOne = getIdWithPeriod<MentorPeriodIncomeId>(
        mentorIdOne,
        period
      );
      const mpiIdTwo = getIdWithPeriod<MentorPeriodIncomeId>(
        mentorIdTwo,
        period
      );
      const mpIncomes: MentorPeriodIncome[] = [
        {
          id: mpiIdOne,
          periodIncome: 10,
          period,
          mentorId: mentorIdOne,
        } as MentorPeriodIncome,
        {
          id: mpiIdTwo,
          periodIncome: 20,
          period,
          mentorId: mentorIdTwo,
        } as MentorPeriodIncome,
      ];
      const actual = sortMPIncomesById(mpIncomes);
      expect(Object.keys(actual)).toEqual([mpiIdOne, mpiIdTwo]);
      expect(actual[mpiIdOne]).toEqual(mpIncomes[0]);
      expect(actual[mpiIdTwo]).toEqual(mpIncomes[1]);
      expect(actual[mpiIdOne].periodIncome).toEqual(10);
      expect(actual[mpiIdTwo].periodIncome).toEqual(20);
    });
  });
});
