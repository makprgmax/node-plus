import {
  MentorBalance,
  MentorBalanceId,
  MentorPeriodIncome,
  MentorPeriodIncomeId,
  MentorWithdrawal,
  Period,
} from '../interfaces';
import { getIdWithPeriod, getPeriodFromDate } from './income';
import {
  newMentorBalanceItem,
  NewMentorBalanceItemProps,
  recalculateMentorBalance,
  RecalculateMentorBalanceProps,
  sortMentorBalanceAryByMentorId,
  sortMentorWithdrawalAryByMentorId,
  sortMPIncomesByMentorId,
} from './daily-update-mentor-balance';
import * as admin from 'firebase-admin';
import Timestamp = admin.firestore.Timestamp;

describe('daily-update-mentor-balance', () => {
  describe('sortMPIncomesByMentorId', () => {
    it('should return an record where key is mentorId and value is income', () => {
      const period: Period = '2020-09';
      const mentorIdOne = 'mentorIdOne';
      const mentorIdTwo = 'mentorIdTwo';
      const mpiIdOne = getIdWithPeriod<MentorPeriodIncomeId>(
        mentorIdOne,
        period
      );
      const mpiIdTwo = getIdWithPeriod<MentorPeriodIncomeId>(
        mentorIdTwo,
        period
      );
      const mpIncomes: MentorPeriodIncome[] = [
        {
          id: mpiIdOne,
          periodIncome: 10,
          period,
          mentorId: mentorIdOne,
        } as MentorPeriodIncome,
        {
          id: mpiIdTwo,
          periodIncome: 20,
          period,
          mentorId: mentorIdTwo,
        } as MentorPeriodIncome,
      ];
      const actual = sortMPIncomesByMentorId(mpIncomes);
      expect(Object.keys(actual)).toEqual([mentorIdOne, mentorIdTwo]);
      expect(actual[mentorIdOne]).toEqual(mpIncomes[0]);
      expect(actual[mentorIdTwo]).toEqual(mpIncomes[1]);
      expect(actual[mentorIdOne].periodIncome).toEqual(10);
      expect(actual[mentorIdTwo].periodIncome).toEqual(20);
    });
  });
  describe('sortMentorBalanceAryByMentorId', () => {
    it('should return an record where key is mentorId and value is mentorBalance', () => {
      const period: Period = '2020-09';
      const mentorIdOne = 'mentorIdOne';
      const mentorIdTwo = 'mentorIdTwo';
      const mbIdOne = getIdWithPeriod<MentorBalanceId>(mentorIdOne, period);
      const mbIdTwo = getIdWithPeriod<MentorBalanceId>(mentorIdTwo, period);
      const mentorBalanceAry: MentorBalance[] = [
        {
          id: mbIdOne,
          period,
          periodBalance: 60,
          periodIncome: 210,
          periodWithdrawal: 150,
          totalBalance: 60,
          totalIncome: 210,
          totalWithdrawal: 150,
          mentorId: mentorIdOne,
        } as MentorBalance,
        {
          id: mbIdTwo,
          periodBalance: 43,
          periodIncome: 43,
          periodWithdrawal: 0,
          totalBalance: 179,
          totalIncome: 189,
          totalWithdrawal: 10,
          period,
          mentorId: mentorIdTwo,
        } as MentorBalance,
      ];
      const actual = sortMentorBalanceAryByMentorId(mentorBalanceAry);
      expect(Object.keys(actual)).toEqual([mentorIdOne, mentorIdTwo]);
      expect(actual[mentorIdOne]).toEqual(mentorBalanceAry[0]);
      expect(actual[mentorIdTwo]).toEqual(mentorBalanceAry[1]);
      expect(actual[mentorIdOne].totalBalance).toEqual(60);
      expect(actual[mentorIdTwo].totalBalance).toEqual(179);
    });
  });
  describe('sortMentorWithdrawalAryByMentorId', () => {
    it('should return an record where key is mentorId and value is array of withdrawals', () => {
      const period: Period = '2020-09';
      const mentorIdOne = 'mentorIdOne';
      const mentorIdTwo = 'mentorIdTwo';
      const mentorWithdrawalAry: MentorWithdrawal[] = [
        {
          id: 'a1',
          amount: 10,
          period,
          mentorId: mentorIdOne,
        } as MentorWithdrawal,
        {
          id: 'b1',
          amount: 20,
          period,
          mentorId: mentorIdTwo,
        } as MentorWithdrawal,
        {
          id: 'b2',
          amount: 30,
          period,
          mentorId: mentorIdTwo,
        } as MentorWithdrawal,
      ];
      const actual = sortMentorWithdrawalAryByMentorId(mentorWithdrawalAry);
      expect(Object.keys(actual)).toEqual([mentorIdOne, mentorIdTwo]);
      expect(actual[mentorIdOne]).toEqual([mentorWithdrawalAry[0]]);
      expect(actual[mentorIdTwo]).toEqual([
        mentorWithdrawalAry[1],
        mentorWithdrawalAry[2],
      ]);
    });
  });
  describe('recalculateMentorBalance', () => {
    describe('case 1: when mentorBalance exists, mentorPeriod updated, mentorWithdrawal not updated', () => {
      it('should update existed mentorBalance', () => {
        const someCreatedAt = Timestamp.fromDate(new Date('2020-10-01'));
        const currentTimestamp = Timestamp.fromDate(new Date('2020-10-12'));
        const period = getPeriodFromDate(currentTimestamp.toDate());
        const mentorId = 'vaRQbvIzl6WTJdHIy71r';
        const mentorPeriodId = 'vaRQbvIzl6WTJdHIy71r-2020-10';
        const mentorBalanceId = 'vaRQbvIzl6WTJdHIy71r-2020-10';
        const prevPeriodIncome = 100;
        const nextPeriodIncome = 150;

        const prevPeriodWithdrawal = 60;
        const nextPeriodWithdrawal = 60;

        const prevTotalIncome = 200;
        const nextTotalIncome =
          prevTotalIncome - prevPeriodIncome + nextPeriodIncome;

        const prevTotalWithdrawal = 90;
        const nextTotalWithdrawal =
          prevTotalWithdrawal - prevPeriodWithdrawal + nextPeriodWithdrawal;

        const mentorPeriodIncome: MentorPeriodIncome = {
          mentorId,
          period,
          createdAt: someCreatedAt,
          id: mentorPeriodId,
          periodIncome: nextPeriodIncome,
        };
        const mentorWithdrawalAry: MentorWithdrawal[] = [
          {
            id: 'someId1',
            mentorId,
            period,
            amount: nextPeriodWithdrawal,
            createdAt: someCreatedAt,
          } as MentorWithdrawal,
        ];

        const mentorBalance: MentorBalance = {
          period: '2020-10',
          id: mentorBalanceId,
          periodBalance: prevPeriodIncome - prevPeriodWithdrawal,
          periodIncome: prevPeriodIncome,
          periodWithdrawal: prevPeriodWithdrawal,
          totalBalance: prevTotalIncome - prevTotalWithdrawal,
          totalIncome: prevTotalIncome,
          totalWithdrawal: prevTotalWithdrawal,
          createdAt: someCreatedAt,
          mentorId,
        };
        const props: RecalculateMentorBalanceProps = {
          currentTimestamp,
          mentorPeriodIncome,
          mentorWithdrawalAry,
          currentMentorBalance: mentorBalance,
        };
        const actual = recalculateMentorBalance(props);
        const expected: MentorBalance = {
          ...mentorBalance,
          periodBalance: nextPeriodIncome - nextPeriodWithdrawal,
          periodIncome: nextPeriodIncome,
          periodWithdrawal: nextPeriodWithdrawal,
          totalBalance: nextTotalIncome - nextTotalWithdrawal,
          totalIncome: nextTotalIncome,
          totalWithdrawal: nextTotalWithdrawal,
          createdAt: mentorBalance.createdAt,
          updatedAt: currentTimestamp,
        };
        expect(actual).toEqual(expected);
      });
    });
    describe('case 2: when mentorBalance exists, mentorPeriod not updated, mentorWithdrawal updated', () => {
      it('should update existed mentorBalance', () => {
        const someCreatedAt = Timestamp.fromDate(new Date('2020-10-01'));
        const currentTimestamp = Timestamp.fromDate(new Date('2020-10-12'));
        const period = getPeriodFromDate(currentTimestamp.toDate());
        const mentorId = 'vaRQbvIzl6WTJdHIy71r';
        const mentorPeriodId = 'vaRQbvIzl6WTJdHIy71r-2020-10';
        const mentorBalanceId = 'vaRQbvIzl6WTJdHIy71r-2020-10';
        const prevPeriodIncome = 100;
        const nextPeriodIncome = 100;

        const prevPeriodWithdrawal = 60;
        const nextPeriodWithdrawal = 60;
        const nextPeriodWithdrawal2 = 30; // new withdrawal

        const prevTotalIncome = 300;
        const nextTotalIncome =
          prevTotalIncome - prevPeriodIncome + nextPeriodIncome;

        const prevTotalWithdrawal = 100;
        const nextTotalWithdrawal =
          prevTotalWithdrawal -
          prevPeriodWithdrawal +
          nextPeriodWithdrawal +
          nextPeriodWithdrawal2;

        const mentorPeriodIncome: MentorPeriodIncome = {
          mentorId,
          period,
          createdAt: someCreatedAt,
          id: mentorPeriodId,
          periodIncome: nextPeriodIncome,
        };
        const mentorWithdrawalAry: MentorWithdrawal[] = [
          {
            id: 'someId1',
            mentorId,
            period,
            amount: nextPeriodWithdrawal,
            createdAt: someCreatedAt,
          } as MentorWithdrawal,
          {
            id: 'someId2',
            mentorId,
            period,
            amount: nextPeriodWithdrawal2,
            createdAt: someCreatedAt,
          } as MentorWithdrawal,
        ];

        const mentorBalance: MentorBalance = {
          period: '2020-10',
          id: mentorBalanceId,
          periodBalance: prevPeriodIncome - prevPeriodWithdrawal,
          periodIncome: prevPeriodIncome,
          periodWithdrawal: prevPeriodWithdrawal,
          totalBalance: prevTotalIncome - prevTotalWithdrawal,
          totalIncome: prevTotalIncome,
          totalWithdrawal: prevTotalWithdrawal,
          createdAt: someCreatedAt,
          mentorId,
        };
        const props: RecalculateMentorBalanceProps = {
          currentTimestamp,
          mentorPeriodIncome,
          mentorWithdrawalAry,
          currentMentorBalance: mentorBalance,
        };
        const actual = recalculateMentorBalance(props);
        const expected: MentorBalance = {
          ...mentorBalance,
          periodBalance:
            nextPeriodIncome - nextPeriodWithdrawal - nextPeriodWithdrawal2,
          periodIncome: nextPeriodIncome,
          periodWithdrawal: nextPeriodWithdrawal + nextPeriodWithdrawal2,
          totalBalance: nextTotalIncome - nextTotalWithdrawal,
          totalIncome: nextTotalIncome,
          totalWithdrawal: nextTotalWithdrawal,
          createdAt: mentorBalance.createdAt,
          updatedAt: currentTimestamp,
        };
        expect(actual).toEqual(expected);
      });
    });
    describe('case 3: when mentorBalance exists, mentorPeriod updated updated, mentorWithdrawal updated', () => {
      it('should update existed mentorBalance', () => {
        const someCreatedAt = Timestamp.fromDate(new Date('2020-10-01'));
        const currentTimestamp = Timestamp.fromDate(new Date('2020-10-12'));
        const period = getPeriodFromDate(currentTimestamp.toDate());
        const mentorId = 'vaRQbvIzl6WTJdHIy71r';
        const mentorPeriodId = 'vaRQbvIzl6WTJdHIy71r-2020-10';
        const mentorBalanceId = 'vaRQbvIzl6WTJdHIy71r-2020-10';
        const prevPeriodIncome = 100;
        const nextPeriodIncome = 170;

        const prevPeriodWithdrawal = 50;
        const nextPeriodWithdrawal = 60;
        const nextPeriodWithdrawal2 = 30; // new withdrawal

        const prevTotalIncome = 300;
        const nextTotalIncome =
          prevTotalIncome - prevPeriodIncome + nextPeriodIncome;

        const prevTotalWithdrawal = 100;
        const nextTotalWithdrawal =
          prevTotalWithdrawal -
          prevPeriodWithdrawal +
          nextPeriodWithdrawal +
          nextPeriodWithdrawal2;

        const mentorPeriodIncome: MentorPeriodIncome = {
          mentorId,
          period,
          createdAt: someCreatedAt,
          id: mentorPeriodId,
          periodIncome: nextPeriodIncome,
        };
        const mentorWithdrawalAry: MentorWithdrawal[] = [
          {
            id: 'someId1',
            mentorId,
            period,
            amount: nextPeriodWithdrawal,
            createdAt: someCreatedAt,
          } as MentorWithdrawal,
          {
            id: 'someId2',
            mentorId,
            period,
            amount: nextPeriodWithdrawal2,
            createdAt: someCreatedAt,
          } as MentorWithdrawal,
        ];

        const mentorBalance: MentorBalance = {
          period: '2020-10',
          id: mentorBalanceId,
          periodBalance: prevPeriodIncome - prevPeriodWithdrawal,
          periodIncome: prevPeriodIncome,
          periodWithdrawal: prevPeriodWithdrawal,
          totalBalance: prevTotalIncome - prevTotalWithdrawal,
          totalIncome: prevTotalIncome,
          totalWithdrawal: prevTotalWithdrawal,
          createdAt: someCreatedAt,
          mentorId,
        };
        const props: RecalculateMentorBalanceProps = {
          currentTimestamp,
          mentorPeriodIncome,
          mentorWithdrawalAry,
          currentMentorBalance: mentorBalance,
        };
        const actual = recalculateMentorBalance(props);
        const expected: MentorBalance = {
          ...mentorBalance,
          periodBalance:
            nextPeriodIncome - nextPeriodWithdrawal - nextPeriodWithdrawal2,
          periodIncome: nextPeriodIncome,
          periodWithdrawal: nextPeriodWithdrawal + nextPeriodWithdrawal2,
          totalBalance: nextTotalIncome - nextTotalWithdrawal,
          totalIncome: nextTotalIncome,
          totalWithdrawal: nextTotalWithdrawal,
          createdAt: mentorBalance.createdAt,
          updatedAt: currentTimestamp,
        };
        expect(actual).toEqual(expected);
      });
    });
    describe('case 4: when mentorBalance exists, mentorPeriod not updated, mentorWithdrawal not updated', () => {
      it('should return undefined', () => {
        const someCreatedAt = Timestamp.fromDate(new Date('2020-10-01'));
        const currentTimestamp = Timestamp.fromDate(new Date('2020-10-12'));
        const period = getPeriodFromDate(currentTimestamp.toDate());
        const mentorId = 'vaRQbvIzl6WTJdHIy71r';
        const mentorPeriodId = 'vaRQbvIzl6WTJdHIy71r-2020-10';
        const mentorBalanceId = 'vaRQbvIzl6WTJdHIy71r-2020-10';
        const prevPeriodIncome = 100;
        const nextPeriodIncome = 100;

        const prevPeriodWithdrawal = 60;
        const nextPeriodWithdrawal = 40;
        const nextPeriodWithdrawal2 = 20;

        const prevTotalIncome = 100;
        const prevTotalWithdrawal = 100;

        const mentorPeriodIncome: MentorPeriodIncome = {
          mentorId,
          period,
          createdAt: someCreatedAt,
          id: mentorPeriodId,
          periodIncome: nextPeriodIncome,
        };
        const mentorWithdrawalAry: MentorWithdrawal[] = [
          {
            id: 'someId1',
            mentorId,
            period,
            amount: nextPeriodWithdrawal,
            createdAt: someCreatedAt,
          } as MentorWithdrawal,
          {
            id: 'someId2',
            mentorId,
            period,
            amount: nextPeriodWithdrawal2,
            createdAt: someCreatedAt,
          } as MentorWithdrawal,
        ];

        const mentorBalance: MentorBalance = {
          period: '2020-10',
          id: mentorBalanceId,
          periodBalance: prevPeriodIncome - prevPeriodWithdrawal,
          periodIncome: prevPeriodIncome,
          periodWithdrawal: prevPeriodWithdrawal,
          totalBalance: prevTotalIncome - prevTotalWithdrawal,
          totalIncome: prevTotalIncome,
          totalWithdrawal: prevTotalWithdrawal,
          createdAt: someCreatedAt,
          mentorId,
        };
        const props: RecalculateMentorBalanceProps = {
          currentTimestamp,
          mentorPeriodIncome,
          mentorWithdrawalAry,
          currentMentorBalance: mentorBalance,
        };
        const actual = recalculateMentorBalance(props);
        expect(actual).toEqual(undefined);
      });
    });
    describe('case 5: when mentorBalance does not exist', () => {
      it('should create a new mentorBalance', () => {
        const someCreatedAt = Timestamp.fromDate(new Date('2020-10-01'));
        const currentTimestamp = Timestamp.fromDate(new Date('2020-10-12'));
        const period = getPeriodFromDate(currentTimestamp.toDate());
        const mentorId = 'vaRQbvIzl6WTJdHIy71r';
        const mentorPeriodId = 'vaRQbvIzl6WTJdHIy71r-2020-10';
        const mentorBalanceId = 'vaRQbvIzl6WTJdHIy71r-2020-10';
        const prevPeriodIncome = 0;
        const nextPeriodIncome = 170;

        const prevPeriodWithdrawal = 0;
        const nextPeriodWithdrawal = 60;
        const nextPeriodWithdrawal2 = 30; // new withdrawal

        const prevTotalIncome = 0;
        const nextTotalIncome =
          prevTotalIncome - prevPeriodIncome + nextPeriodIncome;

        const prevTotalWithdrawal = 0;
        const nextTotalWithdrawal =
          prevTotalWithdrawal -
          prevPeriodWithdrawal +
          nextPeriodWithdrawal +
          nextPeriodWithdrawal2;

        const mentorPeriodIncome: MentorPeriodIncome = {
          mentorId,
          period,
          createdAt: someCreatedAt,
          id: mentorPeriodId,
          periodIncome: nextPeriodIncome,
        };
        const mentorWithdrawalAry: MentorWithdrawal[] = [
          {
            id: 'someId1',
            mentorId,
            period,
            amount: nextPeriodWithdrawal,
            createdAt: someCreatedAt,
          } as MentorWithdrawal,
          {
            id: 'someId2',
            mentorId,
            period,
            amount: nextPeriodWithdrawal2,
            createdAt: someCreatedAt,
          } as MentorWithdrawal,
        ];

        const props: RecalculateMentorBalanceProps = {
          currentTimestamp,
          mentorPeriodIncome,
          mentorWithdrawalAry,
        };
        const actual = recalculateMentorBalance(props);
        const expected: MentorBalance = {
          period: '2020-10',
          id: mentorBalanceId,
          mentorId,
          createdAt: currentTimestamp,
          periodBalance:
            nextPeriodIncome - nextPeriodWithdrawal - nextPeriodWithdrawal2,
          periodIncome: nextPeriodIncome,
          periodWithdrawal: nextPeriodWithdrawal + nextPeriodWithdrawal2,
          totalBalance: nextTotalIncome - nextTotalWithdrawal,
          totalIncome: nextTotalIncome,
          totalWithdrawal: nextTotalWithdrawal,
        };
        expect(actual).toEqual(expected);
      });
    });
  });
  describe('newMentorBalanceItem', () => {
    let subject: MentorBalance;
    const currentTimestamp = Timestamp.now();
    const period: Period = '2020-09';
    const mentorId = 'mentorId';
    beforeAll(() => {
      const mentorPeriodIncome: MentorPeriodIncome = {
        id: 'bla',
        period,
        mentorId,
        periodIncome: 8,
        createdAt: currentTimestamp,
      };
      const props: NewMentorBalanceItemProps = {
        currentTimestamp,
        mentorPeriodIncome,
      };
      subject = newMentorBalanceItem(props);
    });
    it('should have valid id = mentorId + period', () => {
      expect(subject.id).toEqual(`${mentorId}-${period}`);
    });
    it('should have valid createdAt', () => {
      expect(subject.createdAt).toEqual(currentTimestamp);
    });
    it('should have periodIncome === 0', () => {
      expect(subject.periodIncome).toEqual(0);
    });
    it('should have periodWithdrawal === 0', () => {
      expect(subject.periodWithdrawal).toEqual(0);
    });
    it('should have periodBalance === 0', () => {
      expect(subject.periodBalance).toEqual(0);
    });
    it('should have totalIncome === 0', () => {
      expect(subject.totalIncome).toEqual(0);
    });
    it('should have totalWithdrawal === 0', () => {
      expect(subject.totalWithdrawal).toEqual(0);
    });
    it('should have totalBalance === 0', () => {
      expect(subject.totalBalance).toEqual(0);
    });
    it('should have period', () => {
      expect(subject.period).toEqual(period);
    });
    it('should have mentorId', () => {
      expect(subject.mentorId).toEqual(mentorId);
    });
  });
});
