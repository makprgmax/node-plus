import { getPaginatedCollection, PaginatedCollection, sortAZ } from '../utils';
import {
  MentorBalance,
  MentorPeriodIncome,
  MentorWithdrawal,
  Period,
} from '../interfaces';
import * as admin from 'firebase-admin';
import Timestamp = admin.firestore.Timestamp;
import { db } from '../init';
import { getIdWithPeriod } from './income';
import { batchPlus, BatchPlus } from '../batch-plus';

export async function updateMentorBalance(): Promise<Record<string, any>> {
  const result: Record<string, any> = {};
  const now: Timestamp = Timestamp.now();
  const paginatedCollection = getPaginatedCollection<MentorPeriodIncome>({
    collection: 'mentorPeriodIncome',
  });
  let counter = 101;
  let mentorPeriodIncome: MentorPeriodIncome;
  let collection: PaginatedCollection<MentorPeriodIncome> = await paginatedCollection.run();

  const mentorBalances: Record<string, MentorBalance> = {};
  result.mentorPeriodIncome = '------';
  console.log('FIRST PAGE');
  do {
    for (const doc of collection.querySnapshot.docs) {
      mentorPeriodIncome = doc.data();
      const { mentorId, period, periodIncome } = mentorPeriodIncome;
      console.log(`item ${counter}`);
      const id = getIdWithPeriod(mentorId, period);
      if (!mentorBalances[id]) {
        mentorBalances[id] = {
          id,
          createdAt: now,
          mentorId: mentorPeriodIncome.mentorId,
          period: mentorPeriodIncome.period,
          periodBalance: 0,
          periodIncome: 0,
          periodWithdrawal: 0,
          totalBalance: 0,
          totalIncome: 0,
          totalWithdrawal: 0,
        } as MentorBalance;
      }
      mentorBalances[id].periodIncome += periodIncome;
      // log
      result[`${counter}) ${mentorId} ${period}`] = periodIncome;
      counter++;
    }
    if (collection.hasNext) {
      collection = await collection.next();
      console.log(`NEXT PAGE`);
    } else {
      break;
    }
  } while (true);

  result.mentorWithdrawal = '----------';
  console.log('FIRST PAGE');
  // read mentorWithdrawal
  const mentorWithdrawalPaginatedCollection = getPaginatedCollection<MentorWithdrawal>(
    {
      collection: 'mentorWithdrawals',
    }
  );
  counter = 201;
  let mentorWithdrawal: MentorWithdrawal;
  let mentorWithdrawalCollection: PaginatedCollection<MentorWithdrawal> = await mentorWithdrawalPaginatedCollection.run();
  do {
    for (const doc of mentorWithdrawalCollection.querySnapshot.docs) {
      mentorWithdrawal = doc.data();
      const { mentorId, period, amount } = mentorWithdrawal;
      console.log(`item ${counter}`);
      const id = getIdWithPeriod(mentorId, period);
      if (!mentorBalances[id]) {
        mentorBalances[id] = {
          id,
          createdAt: now,
          mentorId,
          period,
          periodBalance: 0,
          periodIncome: 0,
          periodWithdrawal: 0,
          totalBalance: 0,
          totalIncome: 0,
          totalWithdrawal: 0,
        } as MentorBalance;
      }
      mentorBalances[id].periodWithdrawal += amount;
      // log
      result[`${counter}) ${mentorId} ${period}`] = amount;
      counter++;
    }

    if (mentorWithdrawalCollection.hasNext) {
      mentorWithdrawalCollection = await mentorWithdrawalCollection.next();
      console.log(`NEXT PAGE`);
    } else {
      break;
    }
  } while (true);

  result['------'] = '======';

  // calculate totalIncome, totalWithdrawal, periodBalance and totalBalance
  // 1 - group ids by mentorId, get all periods of particular mentorId
  const periodsByMentorId: Record<string, Period[]> = {};
  for (const key in mentorBalances) {
    if (mentorBalances.hasOwnProperty(key)) {
      const { mentorId, period } = mentorBalances[key];
      if (!periodsByMentorId[mentorId]) {
        periodsByMentorId[mentorId] = [];
      }
      periodsByMentorId[mentorId].push(period);
    }
  }
  // 2 - sort periods alphabetically
  for (const mentorId in periodsByMentorId) {
    if (periodsByMentorId.hasOwnProperty(mentorId)) {
      periodsByMentorId[mentorId].sort(sortAZ);
      // 3 - calculate totalIncome, totalWithdrawal, periodBalance and totalBalance
      let totalIncome = 0;
      let totalWithdrawal = 0;
      periodsByMentorId[mentorId].forEach((period: Period) => {
        const id = getIdWithPeriod(mentorId, period);
        const { periodIncome, periodWithdrawal } = mentorBalances[id];
        totalIncome += periodIncome;
        totalWithdrawal += periodWithdrawal;
        mentorBalances[id].periodBalance = periodIncome - periodWithdrawal;
        mentorBalances[id].totalIncome = totalIncome;
        mentorBalances[id].totalWithdrawal = totalWithdrawal;
        mentorBalances[id].totalBalance = totalIncome - totalWithdrawal;
      });
    }
  }

  result.periodsByMentorId = periodsByMentorId;

  const batch: BatchPlus<MentorBalance> = batchPlus(db);

  for (const key in mentorBalances) {
    if (mentorBalances.hasOwnProperty(key)) {
      result[key] = mentorBalances[key];
      const ref = db.doc(`mentorBalance/${mentorBalances[key].id}`);
      batch.set(ref, mentorBalances[key]);
    }
  }
  try {
    await batch.commit();
    return Promise.resolve(result);
  } catch (e) {
    return Promise.reject(e);
  }
}
