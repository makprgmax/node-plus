export const SEND_EMAIL_ON_SUCCESS = false;
