import * as admin from 'firebase-admin';
import Timestamp = admin.firestore.Timestamp;
import { MentorBalance } from '../interfaces';
import {
  copyMentorBalanceFromPreviousMonth,
  CopyMentorBalanceFromPreviousMonthProps,
} from './monthly-copy-mentor-balance-from-previous-month';

describe('monthly-copy-mentor-balance-from-previous-month', () => {
  describe('copyMentorBalanceFromPreviousMonth', () => {
    const previousTimestamp = Timestamp.fromDate(new Date('2020-10-01'));
    const currentTimestamp = Timestamp.fromDate(new Date('2020-11-01'));
    const previousPeriodMentorBalanceAry: MentorBalance[] = [
      {
        id: 'mentor1-2020-10',
        mentorId: 'mentor1',
        period: '2020-10',
        createdAt: previousTimestamp,
        periodBalance: 100,
        periodIncome: 100,
        periodWithdrawal: 0,
        totalBalance: 100,
        totalIncome: 100,
        totalWithdrawal: 0,
      },
      {
        id: 'mentor2-2020-10',
        mentorId: 'mentor2',
        period: '2020-10',
        createdAt: previousTimestamp,
        periodBalance: 100,
        periodIncome: 100,
        periodWithdrawal: 0,
        totalBalance: 300,
        totalIncome: 400,
        totalWithdrawal: 100,
      },
      {
        id: 'mentor3-2020-10',
        mentorId: 'mentor3',
        period: '2020-10',
        createdAt: previousTimestamp,
        periodBalance: 100,
        periodIncome: 200,
        periodWithdrawal: 100,
        totalBalance: 200,
        totalIncome: 400,
        totalWithdrawal: 200,
      },
    ];

    describe('when current period balance array is empty', () => {
      it('should return an equal array of the current period balances with reset to zero for periodBalance, periodIncome and period Withdrawal', () => {
        const currentPeriodMentorBalanceAry: MentorBalance[] = [];
        const props: CopyMentorBalanceFromPreviousMonthProps = {
          previousPeriodMentorBalanceAry,
          currentPeriodMentorBalanceAry,
          currentTimestamp,
        };
        const actual = copyMentorBalanceFromPreviousMonth(props);
        const expected: MentorBalance[] = [
          {
            id: 'mentor1-2020-11',
            mentorId: 'mentor1',
            period: '2020-11',
            createdAt: currentTimestamp,
            periodBalance: 0,
            periodIncome: 0,
            periodWithdrawal: 0,
            totalBalance: 100,
            totalIncome: 100,
            totalWithdrawal: 0,
          },
          {
            id: 'mentor2-2020-11',
            mentorId: 'mentor2',
            period: '2020-11',
            createdAt: currentTimestamp,
            periodBalance: 0,
            periodIncome: 0,
            periodWithdrawal: 0,
            totalBalance: 300,
            totalIncome: 400,
            totalWithdrawal: 100,
          },
          {
            id: 'mentor3-2020-11',
            mentorId: 'mentor3',
            period: '2020-11',
            createdAt: currentTimestamp,
            periodBalance: 0,
            periodIncome: 0,
            periodWithdrawal: 0,
            totalBalance: 200,
            totalIncome: 400,
            totalWithdrawal: 200,
          },
        ];
        expect(actual).toEqual(expected);
      });
    });
    describe('when current period balance array has one element', () => {
      it('should return an array except the one which already exist for the current period', () => {
        const someOtherTimestamp = Timestamp.fromDate(new Date('2020-11-01'));
        const currentPeriodMentorBalanceAry: MentorBalance[] = [
          {
            id: 'mentor2-2020-11',
            mentorId: 'mentor2',
            period: '2020-11',
            createdAt: someOtherTimestamp,
            periodBalance: 200,
            periodIncome: 200,
            periodWithdrawal: 0,
            totalBalance: 400,
            totalIncome: 500,
            totalWithdrawal: 100,
          },
        ];
        const props: CopyMentorBalanceFromPreviousMonthProps = {
          previousPeriodMentorBalanceAry,
          currentPeriodMentorBalanceAry,
          currentTimestamp,
        };
        const actual = copyMentorBalanceFromPreviousMonth(props);
        const expected: MentorBalance[] = [
          {
            id: 'mentor1-2020-11',
            mentorId: 'mentor1',
            period: '2020-11',
            createdAt: currentTimestamp,
            periodBalance: 0,
            periodIncome: 0,
            periodWithdrawal: 0,
            totalBalance: 100,
            totalIncome: 100,
            totalWithdrawal: 0,
          },
          {
            id: 'mentor3-2020-11',
            mentorId: 'mentor3',
            period: '2020-11',
            createdAt: currentTimestamp,
            periodBalance: 0,
            periodIncome: 0,
            periodWithdrawal: 0,
            totalBalance: 200,
            totalIncome: 400,
            totalWithdrawal: 200,
          },
        ];
        expect(actual).toEqual(expected);
      });
    });
    describe('when current period balance array has the same amount of elements than the previous array', () => {
      it('should return an empty array', () => {
        const someOtherTimestamp = Timestamp.fromDate(new Date('2020-11-01'));
        const currentPeriodMentorBalanceAry: MentorBalance[] = [
          {
            id: 'mentor1-2020-11',
            mentorId: 'mentor1',
            period: '2020-11',
            createdAt: someOtherTimestamp,
            periodBalance: 100,
            periodIncome: 100,
            periodWithdrawal: 0,
            totalBalance: 100,
            totalIncome: 100,
            totalWithdrawal: 0,
          },
          {
            id: 'mentor2-2020-11',
            mentorId: 'mentor2',
            period: '2020-11',
            createdAt: someOtherTimestamp,
            periodBalance: 200,
            periodIncome: 200,
            periodWithdrawal: 0,
            totalBalance: 400,
            totalIncome: 500,
            totalWithdrawal: 100,
          },
          {
            id: 'mentor3-2020-11',
            mentorId: 'mentor3',
            period: '2020-11',
            createdAt: someOtherTimestamp,
            periodBalance: 100,
            periodIncome: 200,
            periodWithdrawal: 100,
            totalBalance: 200,
            totalIncome: 400,
            totalWithdrawal: 200,
          },
        ];
        const props: CopyMentorBalanceFromPreviousMonthProps = {
          previousPeriodMentorBalanceAry,
          currentPeriodMentorBalanceAry,
          currentTimestamp,
        };
        const actual = copyMentorBalanceFromPreviousMonth(props);
        expect(actual).toEqual([]);
      });
    });
  });
});
