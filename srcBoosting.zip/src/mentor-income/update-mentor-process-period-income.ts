import { db } from '../init';
// @ts-ignore
import {
  getCardLevel,
  getFullMonthsDiff,
  getIdWithPeriod,
  getMonthlyIncomeRegistry,
  getMonthRange,
} from './income';
import * as admin from 'firebase-admin';
import Timestamp = admin.firestore.Timestamp;
import { getPaginatedCollection, PaginatedCollection } from '../utils';
import {
  AttachClientToCardProcess,
  MentorProcessPeriodIncome,
  MState,
  Period,
} from '../interfaces';
import { batchPlus, BatchPlus } from '../batch-plus';

export async function updateMentorProcessPeriodIncome(): Promise<
  Record<string, any>
> {
  // let actcProcesses: QuerySnapshot<AttachClientToCardProcess>;
  const result: Record<string, any> = {};
  const now: Timestamp = Timestamp.now();
  const nowString = now.toDate().toISOString().split('T')[0];
  const paginatedCollection = getPaginatedCollection<AttachClientToCardProcess>(
    {
      collection: 'attachClientToCardProcesses',
      where: {
        fieldPath: 'state',
        opStr: '==',
        value: 'client__boosting',
      },
    }
  );

  const registry = getMonthlyIncomeRegistry();

  console.log(`FIRST PAGE`);
  let counter = 1;
  let process: AttachClientToCardProcess;
  let incomes: Record<Period, MentorProcessPeriodIncome>;
  let collection: PaginatedCollection<AttachClientToCardProcess> = await paginatedCollection.run();
  const batch: BatchPlus<MentorProcessPeriodIncome> = batchPlus(db);
  do {
    for (const doc of collection.querySnapshot.docs) {
      incomes = {};
      process = doc.data();
      if (process && process.id) {
        console.log(`item ${counter}`);
        const mentorCard = (
          await db.doc(`mentorCards/${process.mentorCardId}`).get()
        ).data();
        const monthDiff = getFullMonthsDiff(
          mentorCard?.cardOpenedAt,
          Timestamp.now()
        );
        const cardLevel = getCardLevel(monthDiff);
        const boostingAt =
          process.stateTimestamps &&
          process.stateTimestamps[MState.client__boosting];
        if (!boostingAt) {
          continue;
        }
        const boostingDate = boostingAt.toDate();
        const boostingStartedAt = boostingDate?.toISOString().split('T')[0];
        // calculate incomes
        const range: Period[] = getMonthRange(boostingAt, now);
        range.forEach((month) => {
          incomes[month] = {
            id: getIdWithPeriod(process.id, month),
            actcProcessId: process.id,
            cardLevel,
            periodIncome: registry.getMonthlyIncomeRate(cardLevel, month),
            mentorCardId: process.mentorCardId,
            mentorId: process.mentorId,
            period: month,
            createdAt: now,
          } as MentorProcessPeriodIncome;
          if (incomes[month].periodIncome) {
            const ref = db.doc(
              `mentorProcessPeriodIncome/${incomes[month].id}`
            );
            batch.set(ref, incomes[month]);
          }
        });

        // log
        result[`${counter}) actcProcess`] = process.id; // process
        result[`${counter}) mentorCard`] = mentorCard?.id; // mentorCard
        result[
          `${counter}) cardOpenedAt`
        ] = mentorCard?.cardOpenedAt?.toDate().toISOString().split('T')[0];
        result[`${counter}) now`] = nowString;
        result[`${counter}) month difference`] = monthDiff;
        result[`${counter}) level`] = cardLevel;
        result[`${counter}) boostingStartedAt`] = boostingStartedAt;
        result[`${counter}) incomes`] = incomes;
        counter++;
      }
    }
    console.log(`NEXT PAGE`);
    if (collection.hasNext) {
      collection = await collection.next();
    } else {
      break;
    }
  } while (true);

  try {
    await batch.commit();
    return Promise.resolve(result);
  } catch (e) {
    return Promise.reject(e);
  }
}
