import {
  APIResult,
  MentorBalance,
  MentorBalanceId,
  MentorId,
  MentorPeriodIncome,
  MentorWithdrawal,
  Period,
} from '../interfaces';
import { getIdWithPeriod, getPeriodFromDate } from './income';
import {
  getAllMentorPeriodIncomesByPeriod,
  sumUp,
} from './daily-update-mentor-period-income';
import * as admin from 'firebase-admin';
import Timestamp = admin.firestore.Timestamp;
import WriteBatch = admin.firestore.WriteBatch;
import {
  getPaginatedCollection,
  iterateThroughPaginatedCollection,
  sendLogToEmail,
  SendLogToEmailProps,
} from '../utils';
import { db } from '../init';
import { environment } from '../environments/environment';
import { EventContext } from 'firebase-functions';
import { SEND_EMAIL_ON_SUCCESS } from './constants';

export type MPIncomesByMentorId = Record<MentorId, MentorPeriodIncome>;
export const sortMPIncomesByMentorId = (
  mpIncomes: MentorPeriodIncome[]
): MPIncomesByMentorId => {
  const mapping: MPIncomesByMentorId = {};
  mpIncomes.forEach((item) => {
    mapping[item.mentorId] = item;
  });
  return mapping;
};

export type MentorBalanceAryByMentorId = Record<MentorId, MentorBalance>;
export const sortMentorBalanceAryByMentorId = (
  mentorBalanceAry: MentorBalance[]
): MentorBalanceAryByMentorId => {
  const mapping: MentorBalanceAryByMentorId = {};
  mentorBalanceAry.forEach((item) => {
    mapping[item.mentorId] = item;
  });
  return mapping;
};

export type MentorWithdrawalAryByMentorId = Record<
  MentorId,
  MentorWithdrawal[]
>;
export const sortMentorWithdrawalAryByMentorId = (
  mentorWithdrawalAry: MentorWithdrawal[]
): MentorWithdrawalAryByMentorId => {
  const mapping: MentorWithdrawalAryByMentorId = {};
  mentorWithdrawalAry.forEach((item) => {
    if (!mapping[item.mentorId]) {
      mapping[item.mentorId] = [];
    }
    mapping[item.mentorId].push(item);
  });
  return mapping;
};

export const getAllMentorWithdrawByPeriod = async <R>(
  period: Period,
  identity: (item: MentorWithdrawal) => R
): Promise<R[]> => {
  const paginatedCollection = getPaginatedCollection<MentorWithdrawal>({
    collection: 'mentorWithdrawals',
    where: {
      fieldPath: 'period',
      opStr: '==',
      value: period,
    },
    orderByDirection: 'desc',
  });
  const collection = await paginatedCollection.run();
  return iterateThroughPaginatedCollection<MentorWithdrawal, R>({
    collection,
    identity,
  });
};

export const getAllMentorBalanceByPeriod = async <R>(
  period: Period,
  identity: (item: MentorBalance) => R
): Promise<R[]> => {
  const paginatedCollection = getPaginatedCollection<MentorBalance>({
    collection: 'mentorBalance',
    where: {
      fieldPath: 'period',
      opStr: '==',
      value: period,
    },
    orderByDirection: 'desc',
  });
  const collection = await paginatedCollection.run();
  return iterateThroughPaginatedCollection<MentorBalance, R>({
    collection,
    identity,
  });
};

export interface NewMentorBalanceItemProps {
  currentTimestamp: Timestamp;
  mentorPeriodIncome: MentorPeriodIncome;
}
export function newMentorBalanceItem(
  props: NewMentorBalanceItemProps
): MentorBalance {
  const { currentTimestamp, mentorPeriodIncome } = props;
  const { mentorId, period } = mentorPeriodIncome;
  const id = getIdWithPeriod<MentorBalanceId>(mentorId, period);
  return {
    id,
    createdAt: currentTimestamp,
    period,
    mentorId,
    periodIncome: 0,
    periodWithdrawal: 0,
    periodBalance: 0,
    totalIncome: 0,
    totalWithdrawal: 0,
    totalBalance: 0,
  };
}

export interface RecalculateMentorBalanceProps {
  currentTimestamp: Timestamp;
  mentorPeriodIncome: MentorPeriodIncome; // related to particular mentor only
  mentorWithdrawalAry?: MentorWithdrawal[]; // related to particular mentor only
  currentMentorBalance?: MentorBalance;
}
export const recalculateMentorBalance = (
  props: RecalculateMentorBalanceProps
): MentorBalance | undefined => {
  const {
    currentMentorBalance,
    currentTimestamp,
    mentorPeriodIncome,
    mentorWithdrawalAry,
  } = props;

  let balanceItem: MentorBalance;

  if (currentMentorBalance) {
    balanceItem = {
      ...currentMentorBalance,
      updatedAt: currentTimestamp,
    };
  } else {
    balanceItem = newMentorBalanceItem({
      currentTimestamp,
      mentorPeriodIncome,
    });
  }

  const {
    periodIncome,
    periodWithdrawal,
    totalIncome,
    totalWithdrawal,
  } = balanceItem;
  const prevPeriodIncome = periodIncome;
  const nextPeriodIncome = mentorPeriodIncome.periodIncome;

  const prevPeriodWithdrawal = periodWithdrawal;
  const nextPeriodWithdrawal = sumUp(
    Array.isArray(mentorWithdrawalAry)
      ? mentorWithdrawalAry.map((withdrawal) => withdrawal?.amount || 0)
      : undefined
  );

  const nextTotalIncome = totalIncome - prevPeriodIncome + nextPeriodIncome;

  const nextTotalWithdrawal =
    totalWithdrawal - prevPeriodWithdrawal + nextPeriodWithdrawal;

  const updatedBalance: MentorBalance = {
    ...balanceItem,
    periodIncome: nextPeriodIncome,
    periodWithdrawal: nextPeriodWithdrawal,
    periodBalance: nextPeriodIncome - nextPeriodWithdrawal,
    totalIncome: nextTotalIncome,
    totalWithdrawal: nextTotalWithdrawal,
    totalBalance: nextTotalIncome - nextTotalWithdrawal,
  };

  if (currentMentorBalance) {
    const prevBalanceCompareString = JSON.stringify([
      currentMentorBalance.periodIncome,
      currentMentorBalance.periodWithdrawal,
      currentMentorBalance.totalIncome,
      currentMentorBalance.totalWithdrawal,
    ]);
    const nextBalanceCompareString = JSON.stringify([
      updatedBalance.periodIncome,
      updatedBalance.periodWithdrawal,
      updatedBalance.totalIncome,
      updatedBalance.totalWithdrawal,
    ]);
    if (prevBalanceCompareString === nextBalanceCompareString) {
      return undefined;
    }
  }
  return updatedBalance;
};

export async function dailyUpdateMentorBalance(
  context?: EventContext
): Promise<APIResult> {
  const result: APIResult = {};
  let counter = 1;
  const currentTimestamp = Timestamp.now();
  const currentPeriod = getPeriodFromDate(currentTimestamp.toDate());
  let mentorBalanceAry: MentorBalance[];
  let mentorWithdrawalAry: MentorWithdrawal[];
  let periodIncomeAry: MentorPeriodIncome[];
  const mentorBalanceToUpdateInDB: MentorBalance[] = [];

  const sendEmail: SendLogToEmailProps = {
    to: environment.sendEmails.developers,
    subject: 'daily-update-mentor-balance',
    log: {},
  };

  try {
    // get all mentorWithdrawal records
    const withdrawIdentity = (item: MentorWithdrawal) => item;
    mentorWithdrawalAry = await getAllMentorWithdrawByPeriod<MentorWithdrawal>(
      currentPeriod,
      withdrawIdentity
    );
    result[`${counter++}) mentorWithdrawalAry`] = mentorWithdrawalAry;

    // get all mentorBalance records
    const balanceIdentity = (item: MentorBalance) => item;
    mentorBalanceAry = await getAllMentorBalanceByPeriod<MentorBalance>(
      currentPeriod,
      balanceIdentity
    );
    result[`${counter++}) mentorBalanceAry`] = mentorBalanceAry;

    // get all mentorPeriodIncome records
    const mpIncomeIdentity = (item: MentorPeriodIncome) => item;
    periodIncomeAry = await getAllMentorPeriodIncomesByPeriod<MentorPeriodIncome>(
      currentPeriod,
      mpIncomeIdentity
    );
    result[`${counter++}) periodIncomeAry`] = periodIncomeAry;

    // prepare maps to speed up array iteration
    const periodIncomeMap = sortMPIncomesByMentorId(periodIncomeAry);
    result[`${counter++}) periodIncomeMap`] = periodIncomeMap;

    const withdrawalMap = sortMentorWithdrawalAryByMentorId(
      mentorWithdrawalAry
    );
    result[`${counter++}) withdrawMap`] = withdrawalMap;

    const mentorBalanceMap = sortMentorBalanceAryByMentorId(mentorBalanceAry);
    result[`${counter++}) mentorBalanceMap`] = mentorBalanceMap;

    // recalculate mentorBalance for each periodIncome
    Object.keys(periodIncomeMap).forEach((mentorId) => {
      const item = recalculateMentorBalance({
        currentTimestamp,
        mentorPeriodIncome: periodIncomeMap[mentorId],
        currentMentorBalance: mentorBalanceMap[mentorId],
        mentorWithdrawalAry: withdrawalMap[mentorId],
      });
      if (item) {
        mentorBalanceToUpdateInDB.push(item);
      }
    });
    result[
      `${counter++}) mentorBalanceToUpdateInDB`
    ] = mentorBalanceToUpdateInDB;

    // run db batch
    let updatedCounter = 0;
    let insertedCounter = 0;
    if (mentorBalanceToUpdateInDB.length > 0) {
      const batch: WriteBatch = db.batch();
      mentorBalanceToUpdateInDB.forEach((balance) => {
        const ref = db.doc(`mentorBalance/${balance.id}`);
        if (balance.updatedAt) {
          batch.update(ref, balance);
          updatedCounter++;
        } else {
          batch.set(ref, balance);
          insertedCounter++;
        }
      });
      await batch.commit();
    }
    result.emailLog = {
      'Inserted new items to mentorBalance': insertedCounter,
      'Updated items in mentorBalance': updatedCounter,
      context,
    };
    sendEmail.log = result.emailLog || {};
    if (SEND_EMAIL_ON_SUCCESS) {
      await sendLogToEmail(sendEmail);
    } else {
      console.log({ sendEmail });
    }
  } catch (e) {
    console.error(e);
    sendEmail.log = { error: e };
    await sendLogToEmail(sendEmail);
    throw e;
  }

  return Promise.resolve(result);
}
