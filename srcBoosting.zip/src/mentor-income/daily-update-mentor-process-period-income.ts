import {
  APIResult,
  AttachClientToCardProcess,
  MentorCard,
  MentorProcessPeriodIncome,
  MentorProcessPeriodIncomeId,
  MState,
  PartialMentorProcessPeriodIncome,
  Period,
} from '../interfaces';
import * as admin from 'firebase-admin';
import Timestamp = admin.firestore.Timestamp;
import WriteBatch = admin.firestore.WriteBatch;
import {
  getCardLevel,
  getFullMonthsDiff,
  getIdWithPeriod,
  getMonthlyIncomeRegistry,
  getPeriodFromDate,
  isEndOfPeriod,
  MonthlyIncomeRegistryObject,
} from './income';
import {
  getPaginatedCollection,
  iterateThroughPaginatedCollection,
  PaginatedCollection,
  sendLogToEmail,
  SendLogToEmailProps,
} from '../utils';
import { db } from '../init';
import { environment } from '../environments/environment';
import { EventContext } from 'firebase-functions';
import { SEND_EMAIL_ON_SUCCESS } from './constants';

export interface GenerateMPPIncomeItemProps {
  currentTimestamp: Timestamp;
  activeACTCProcess: AttachClientToCardProcess;
  existedMPPIncomeIds: Set<MentorProcessPeriodIncomeId>;
}
export function generateMPPIncomeItem(
  props: GenerateMPPIncomeItemProps
): PartialMentorProcessPeriodIncome | undefined {
  const {
    currentTimestamp,
    activeACTCProcess: process,
    existedMPPIncomeIds,
  } = props;
  const currentDay = currentTimestamp?.toDate();

  const boostingAt =
    process.stateTimestamps && process.stateTimestamps[MState.client__boosting];
  const isAssigned = process.state === MState.client__boosting;
  const processStarted = boostingAt?.toDate();
  if (
    isAssigned &&
    processStarted &&
    isEndOfPeriod(processStarted, currentDay)
  ) {
    const period = getPeriodFromDate(currentTimestamp.toDate());
    const id = getIdWithPeriod(process.id, period);

    // ***********************************************
    // SKIP generating new income if it already exists
    if (existedMPPIncomeIds.has(id)) {
      return undefined;
    }
    // END SKIP
    // ***********************************************

    return {
      id,
      actcProcessId: process.id,
      period,
      mentorCardId: process.mentorCardId,
      mentorId: process.mentorId,
    } as PartialMentorProcessPeriodIncome;
  }
  return undefined;
}
export interface InsertCardLevelAndPeriodIncomeProps {
  partialIncome: PartialMentorProcessPeriodIncome;
  mentorCardOpenedAt: Timestamp | undefined;
  currentTimestamp: Timestamp;
  incomeRegistry: MonthlyIncomeRegistryObject;
}
export function insertCardLevelAndPeriodIncome(
  props: InsertCardLevelAndPeriodIncomeProps
): MentorProcessPeriodIncome {
  const {
    partialIncome,
    mentorCardOpenedAt,
    currentTimestamp,
    incomeRegistry,
  } = props;
  const monthDiff = getFullMonthsDiff(mentorCardOpenedAt, currentTimestamp);
  const cardLevel = getCardLevel(monthDiff);
  const periodIncome = incomeRegistry.getMonthlyIncomeRate(
    cardLevel,
    partialIncome.period
  );
  return {
    ...partialIncome,
    createdAt: currentTimestamp,
    cardLevel,
    periodIncome,
  };
}

export const getAllMentorProcessPeriodIncomesByPeriod = async <R>(
  period: Period,
  identity: (item: MentorProcessPeriodIncome) => R
): Promise<R[]> => {
  const paginatedCollection = getPaginatedCollection<MentorProcessPeriodIncome>(
    {
      collection: 'mentorProcessPeriodIncome',
      where: {
        fieldPath: 'period',
        opStr: '==',
        value: period,
      },
      orderByDirection: 'desc',
    }
  );
  const collection = await paginatedCollection.run();
  return iterateThroughPaginatedCollection<MentorProcessPeriodIncome, R>({
    collection,
    identity,
  });
};

type TimestampOrUndefined = Timestamp | undefined;
export interface MentorCardOpenedAtRegistry {
  getMentorCardOpenedAt: (
    mentorCardId: string,
    apiResult?: APIResult
  ) => Promise<TimestampOrUndefined>;
}
export type MentorCardId = string;
function getMentorCardOpenedAtRegistry(): MentorCardOpenedAtRegistry {
  const cache: Record<MentorCardId, Timestamp | false> = {};
  const getMentorCardOpenedAt = async (
    mentorCardId: MentorCardId,
    apiResult?: APIResult
  ): Promise<TimestampOrUndefined> => {
    if (cache[mentorCardId] === undefined) {
      const mentorCard = (
        await db.doc(`mentorCards/${mentorCardId}`).get()
      ).data() as MentorCard;
      if (apiResult) {
        apiResult[`mentorCard ${mentorCardId}`] = mentorCard;
      }
      cache[mentorCardId] = mentorCard?.cardOpenedAt || false;
    }
    const result: TimestampOrUndefined = (cache[mentorCardId] === false
      ? undefined
      : cache[mentorCardId]) as TimestampOrUndefined;
    return Promise.resolve(result);
  };
  return {
    getMentorCardOpenedAt,
  };
}

export async function dailyUpdateMentorProcessPeriodIncome(
  context?: EventContext
): Promise<APIResult> {
  const currentTimestamp = Timestamp.now();
  const currentPeriod = getPeriodFromDate(currentTimestamp.toDate());
  const result: APIResult = {};
  const incomeAry: MentorProcessPeriodIncome[] = [];
  let counter = 1;

  const sendEmail: SendLogToEmailProps = {
    to: environment.sendEmails.developers,
    subject: 'daily-update-mentor-process-period-income',
    log: {},
  };

  try {
    // get income registry
    const incomeRegistry = getMonthlyIncomeRegistry();

    const mentorCardOpenedAtRegistry = getMentorCardOpenedAtRegistry();

    // get ids of all existed MPPIncomes by current period
    const getIdFromMPPIncome = (item: MentorProcessPeriodIncome) => item.id;
    const existedMPPIncomeIds = new Set(
      await getAllMentorProcessPeriodIncomesByPeriod<MentorProcessPeriodIncomeId>(
        currentPeriod,
        getIdFromMPPIncome
      )
    );

    result[`${counter++}) existedMPPIncomeIds`] = Array.from(
      existedMPPIncomeIds
    );
    // ***************************************
    // get all active actcProcesses
    const paginatedACTCProcessCollection = getPaginatedCollection<AttachClientToCardProcess>(
      {
        collection: 'attachClientToCardProcesses',
        where: {
          fieldPath: 'state',
          opStr: '==',
          value: 'client__boosting',
        },
      }
    );
    let processCollection: PaginatedCollection<AttachClientToCardProcess> = await paginatedACTCProcessCollection.run();
    let process: AttachClientToCardProcess;
    do {
      for (const doc of processCollection.querySnapshot.docs) {
        process = doc.data();
        result[`${counter}) process ${process.id}`] = process.id;

        const partialIncome = generateMPPIncomeItem({
          existedMPPIncomeIds,
          currentTimestamp,
          activeACTCProcess: process,
        });
        if (partialIncome) {
          result[
            `${counter}) partial income ${partialIncome.id}`
          ] = partialIncome;
          const mentorCardOpenedAt = await mentorCardOpenedAtRegistry.getMentorCardOpenedAt(
            process.mentorCardId,
            result
          );
          result[
            `${counter}) mentorCardOpenedAt ${process.mentorCardId}`
          ] = String(mentorCardOpenedAt?.toDate().toISOString());

          const income: MentorProcessPeriodIncome = insertCardLevelAndPeriodIncome(
            {
              partialIncome,
              currentTimestamp,
              incomeRegistry,
              mentorCardOpenedAt,
            }
          );
          result[`${counter}) income ${income.id}`] = income;
          incomeAry.push(income);
        }
        counter++;
      }
      if (processCollection.hasNext) {
        processCollection = await processCollection.next();
      } else {
        break;
      }
    } while (true);
    // end actcProcesses
    // ***************************************

    // ***************************************
    // insert incomes to DB
    if (incomeAry.length > 0) {
      const batch: WriteBatch = db.batch();
      incomeAry.forEach((income) => {
        const ref = db.doc(`mentorProcessPeriodIncome/${income.id}`);
        batch.set(ref, income);
      });
      await batch.commit();
    }
    result.emailLog = {
      'Inserted new items to mentorProcessPeriodIncome': incomeAry.length,
      context,
    };
    // END insert incomes to DB
    // ***************************************
    sendEmail.log = result.emailLog || {};
    if (SEND_EMAIL_ON_SUCCESS) {
      await sendLogToEmail(sendEmail);
    } else {
      console.log({ sendEmail });
    }
  } catch (e) {
    console.error(e);
    sendEmail.log = { error: e };
    await sendLogToEmail(sendEmail);
    throw e;
  }
  return Promise.resolve(result);

  // get all related mentorCards
  // generate new incomes
  // save to DB
  // generate an email to admin with success/fail result
}
