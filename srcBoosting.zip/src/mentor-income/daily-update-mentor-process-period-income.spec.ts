import {
  AttachClientToCardProcess,
  MentorProcessPeriodIncome,
  MState,
  PartialMentorProcessPeriodIncome,
} from '../interfaces';
import { getTimestampFromDateString } from '../utils';
import * as admin from 'firebase-admin';
import Timestamp = admin.firestore.Timestamp;
import {
  generateMPPIncomeItem,
  GenerateMPPIncomeItemProps,
  insertCardLevelAndPeriodIncome,
  InsertCardLevelAndPeriodIncomeProps,
} from './daily-update-mentor-process-period-income';
import { getMonthlyIncomeRegistry } from './income';

describe('daily-update-mentor-process-period-income', () => {
  const someCreatedAt = getTimestampFromDateString('2020-09-01') as Timestamp;
  describe('generateMPPIncomeItems', () => {
    const activeACTCProcess: AttachClientToCardProcess = {
      id: 'actcProcessId',
      mentorCardId: 'mentorCardId',
      mentorId: 'mentorId',
      updatedAt: getTimestampFromDateString('2020-09-10'),
      state: MState.client__boosting,
      stateTimestamps: {
        [MState.client__boosting]: getTimestampFromDateString('2020-09-10'),
      },
      createdAt: someCreatedAt,
    };
    const existedMPPIncomeIds: Set<string> = new Set(
      'otherActcProcessId-2020-10'
    );
    describe('case 1: when the current period is not over (boostingDay > currentDay)', () => {
      it('boostingDay = 10, currentDay = 9; should return NO new incomes', () => {
        const props: GenerateMPPIncomeItemProps = {
          currentTimestamp: getTimestampFromDateString(
            '2020-10-09'
          ) as Timestamp,
          activeACTCProcess,
          existedMPPIncomeIds,
        };
        const actual = generateMPPIncomeItem(props);
        const expected = undefined;
        expect(actual).toEqual(expected);
      });
    });
    describe('case 2: when the current period is over (boostingDay == currentDay)', () => {
      it('if income does not exist in DB; should return a new income', () => {
        const props: GenerateMPPIncomeItemProps = {
          currentTimestamp: getTimestampFromDateString(
            '2020-10-10'
          ) as Timestamp,
          activeACTCProcess,
          existedMPPIncomeIds,
        };
        const actual = generateMPPIncomeItem(props);
        const expected: PartialMentorProcessPeriodIncome = {
          id: 'actcProcessId-2020-10',
          actcProcessId: 'actcProcessId',
          period: '2020-10',
          mentorCardId: 'mentorCardId',
          mentorId: 'mentorId',
        };

        expect(actual).toEqual(expected);
      });
      it('if income already exists in DB; should return NO new incomes', () => {
        const existedIncomeId = 'actcProcessId-2020-10';

        const props: GenerateMPPIncomeItemProps = {
          currentTimestamp: getTimestampFromDateString(
            '2020-10-10'
          ) as Timestamp,
          activeACTCProcess,
          existedMPPIncomeIds: new Set([existedIncomeId]),
        };
        const actual = generateMPPIncomeItem(props);
        const expected = undefined;
        expect(actual).toEqual(expected);
      });
    });
    describe('case 3: when the current period is over (boostingDay > currentDay, but currentDay is the last day in the month)', () => {
      it('boostingDay = 31, currentDay = 28; should return a new income', () => {
        const processStartedOn31OfJanuary = {
          ...activeACTCProcess,
          stateTimestamps: {
            [MState.client__boosting]: getTimestampFromDateString('2019-01-31'),
          },
        };
        const props: GenerateMPPIncomeItemProps = {
          currentTimestamp: getTimestampFromDateString(
            '2019-02-28'
          ) as Timestamp,
          activeACTCProcess: processStartedOn31OfJanuary,
          existedMPPIncomeIds,
        };
        const actual = generateMPPIncomeItem(props);
        const expected: PartialMentorProcessPeriodIncome = {
          id: 'actcProcessId-2019-02',
          actcProcessId: 'actcProcessId',
          period: '2019-02',
          mentorCardId: 'mentorCardId',
          mentorId: 'mentorId',
        };
        expect(actual).toEqual(expected);
      });
      it('boostingDay = UNDEFINED, currentDay = 28; should return NO incomes', () => {
        const processNeverStarted = {
          ...activeACTCProcess,
          stateTimestamps: {},
        };
        const props: GenerateMPPIncomeItemProps = {
          currentTimestamp: getTimestampFromDateString(
            '2019-02-28'
          ) as Timestamp,
          activeACTCProcess: processNeverStarted,
          existedMPPIncomeIds,
        };
        const actual = generateMPPIncomeItem(props);
        expect(actual).toEqual(undefined);
      });
    });
    describe('case 4: when first month is not over', () => {
      it('boostingDay = 01/15, currentDay = 01/16; should NOT return a new income', () => {
        const processStartedOn31OfJanuary = {
          ...activeACTCProcess,
          stateTimestamps: {
            [MState.client__boosting]: getTimestampFromDateString('2019-01-15'),
          },
        };
        const props: GenerateMPPIncomeItemProps = {
          currentTimestamp: getTimestampFromDateString(
            '2019-01-16'
          ) as Timestamp,
          activeACTCProcess: processStartedOn31OfJanuary,
          existedMPPIncomeIds,
        };
        const actual = generateMPPIncomeItem(props);
        expect(actual).toEqual(undefined);
      });
      it('boostingDay = 01/15, currentDay = 01/20; should NOT return a new income', () => {
        const processStartedOn15OfJanuary = {
          ...activeACTCProcess,
          stateTimestamps: {
            [MState.client__boosting]: getTimestampFromDateString('2019-01-15'),
          },
        };
        const props: GenerateMPPIncomeItemProps = {
          currentTimestamp: getTimestampFromDateString(
            '2019-01-20'
          ) as Timestamp,
          activeACTCProcess: processStartedOn15OfJanuary,
          existedMPPIncomeIds,
        };
        const actual = generateMPPIncomeItem(props);
        expect(actual).toEqual(undefined);
      });
    });
  });
  describe('insertCardLevelAndIncome', () => {
    const mentorCardOpenedAt = getTimestampFromDateString(
      '2019-09-01'
    ) as Timestamp;

    describe('when cardOpenedAt is set', () => {
      it('should return Income with cardLevel 1 and periodIncome 25', () => {
        const nowDate = new Date('2020-02-20');
        const nowTimestamp = Timestamp.fromDate(nowDate);
        const partialIncome: PartialMentorProcessPeriodIncome = {
          id: 'actcProcessId-2020-02',
          actcProcessId: 'actcProcessId',
          period: '2020-02',
          mentorCardId: 'mentorCardId',
          mentorId: 'mentorId',
        };
        const expected: MentorProcessPeriodIncome = {
          createdAt: nowTimestamp,
          periodIncome: 25,
          cardLevel: 1,
          id: 'actcProcessId-2020-02',
          actcProcessId: 'actcProcessId',
          period: '2020-02',
          mentorCardId: 'mentorCardId',
          mentorId: 'mentorId',
        };

        const incomeRegistry = getMonthlyIncomeRegistry();
        const props: InsertCardLevelAndPeriodIncomeProps = {
          partialIncome,
          mentorCardOpenedAt,
          currentTimestamp: nowTimestamp,
          incomeRegistry,
        };
        const actual = insertCardLevelAndPeriodIncome(props);
        expect(actual).toEqual(expected);
      });
      it('should return Income with cardLevel 2 and periodIncome 25', () => {
        const nowDate = new Date('2022-02-20');
        const nowTimestamp = Timestamp.fromDate(nowDate);
        const partialIncome: PartialMentorProcessPeriodIncome = {
          id: 'actcProcessId-2022-02',
          actcProcessId: 'actcProcessId',
          period: '2022-02',
          mentorCardId: 'mentorCardId',
          mentorId: 'mentorId',
        };
        const expected: MentorProcessPeriodIncome = {
          createdAt: nowTimestamp,
          periodIncome: 25,
          cardLevel: 2,
          id: 'actcProcessId-2022-02',
          actcProcessId: 'actcProcessId',
          period: '2022-02',
          mentorCardId: 'mentorCardId',
          mentorId: 'mentorId',
        };

        const incomeRegistry = getMonthlyIncomeRegistry();
        const props: InsertCardLevelAndPeriodIncomeProps = {
          partialIncome,
          mentorCardOpenedAt,
          currentTimestamp: nowTimestamp,
          incomeRegistry,
        };
        const actual = insertCardLevelAndPeriodIncome(props);
        expect(actual).toEqual(expected);
      });
    });
    describe('when cardOpenedAt is NOT set', () => {
      it('should return Income with cardLevel 0 and periodIncome 25', () => {
        const nowDate = new Date('2022-02-20');
        const nowTimestamp = Timestamp.fromDate(nowDate);
        const partialIncome: PartialMentorProcessPeriodIncome = {
          id: 'actcProcessId-2022-02',
          actcProcessId: 'actcProcessId',
          period: '2022-02',
          mentorCardId: 'mentorCardId',
          mentorId: 'mentorId',
        };
        const expected: MentorProcessPeriodIncome = {
          createdAt: nowTimestamp,
          periodIncome: 25,
          cardLevel: 0,
          id: 'actcProcessId-2022-02',
          actcProcessId: 'actcProcessId',
          period: '2022-02',
          mentorCardId: 'mentorCardId',
          mentorId: 'mentorId',
        };

        const incomeRegistry = getMonthlyIncomeRegistry();
        const props: InsertCardLevelAndPeriodIncomeProps = {
          partialIncome,
          mentorCardOpenedAt: undefined,
          currentTimestamp: nowTimestamp,
          incomeRegistry,
        };
        const actual = insertCardLevelAndPeriodIncome(props);
        expect(actual).toEqual(expected);
      });
    });
  });
});
