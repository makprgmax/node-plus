import { db } from './init';
import { getCollection } from './utils';

const generateDate = (() => {
  const date = new Date();
  return () => {
    date.setDate(date.getDate() - 1);
    return date;
  };
})();

export async function generateCreatedAt(): Promise<Record<string, any>> {
  const users = await getCollection('users');
  const result: Record<string, any> = [];
  const batch = db.batch();
  users.forEach((value) => {
    const user = value.data();
    const { createdAt } = user;
    if (!createdAt) {
      const changes = { createdAt: generateDate() };
      batch.update(value.ref, changes);
      result.push({
        uid: user.uid,
        ...changes
      })
    }
  });
  await batch.commit().catch((error: any) => {
    result.error = error;
  });
  return Promise.resolve(result);
}
