import * as functions from 'firebase-functions';
import { User } from '../interfaces';
import { getDocumentBySnapshot } from './utils';
import { deleteUserView } from '../views/user-view';

const collectionName = 'users';
export const usersOnDelete = functions.firestore
  .document(`${collectionName}/{docId}`)
  .onDelete(
    async (snapshot, context): Promise<void | null> => {
      const user = getDocumentBySnapshot<User>(
        snapshot,
        context.params.docId,
        'uid'
      );
      if (!user) {
        return null;
      }
      await deleteUserView(user);
    }
  );
