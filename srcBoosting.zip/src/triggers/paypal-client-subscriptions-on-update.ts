import * as functions from 'firebase-functions';
import { PaypalClientSubscription } from '../interfaces';
import { getDocumentBySnapshot } from './utils';
import {
  deletePaypalClSubsView,
  updatePaypalClSubsView,
} from '../views/paypal/paypal-cl-subs-view';

const collectionName = 'paypalClientSubscriptions';

export const paypalClientSubscriptionsOnUpdate = functions.firestore
  .document(`${collectionName}/{docId}`)
  .onUpdate(async (snapshot, context) => {
    const paypalClientSubscriptionBefore = getDocumentBySnapshot<PaypalClientSubscription>(
      snapshot.before,
      context.params.docId
    );
    const paypalClientSubscriptionAfter = getDocumentBySnapshot<PaypalClientSubscription>(
      snapshot.after,
      context.params.docId
    );

    // if the record was marked as archived, no need to update views
    if (paypalClientSubscriptionAfter?.archived) {
      return Promise.resolve();
    }

    if (!!paypalClientSubscriptionAfter) {
      await updatePaypalClSubsView(paypalClientSubscriptionAfter);

      // mark paypalClientSubscriptionBefore as _deleted
      // if before.state !== after.state
      // FYI, before.state === after.state when paypalClientSubscription was created in CSB with state 'init_pending'
      // and then was updated from PayPal Webhook with the same state
      if (
        !!paypalClientSubscriptionBefore &&
        paypalClientSubscriptionBefore.state !==
          paypalClientSubscriptionAfter.state
      ) {
        await deletePaypalClSubsView(
          paypalClientSubscriptionBefore,
          paypalClientSubscriptionAfter
        );
      }
    }
  });
