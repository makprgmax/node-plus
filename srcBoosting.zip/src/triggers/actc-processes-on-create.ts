import * as functions from 'firebase-functions';
import { AttachClientToCardProcess } from '../interfaces';
import { getDocumentBySnapshot } from './utils';
import { updateUserViewFromActcProcess } from '../views/user-view';

const collectionName = 'attachClientToCardProcesses';
export const actcProcessesOnCreate = functions.firestore
  .document(`${collectionName}/{docId}`)
  .onCreate(
    async (snapshot, context): Promise<void | null> => {
      const actcProcess = getDocumentBySnapshot<AttachClientToCardProcess>(
        snapshot,
        context.params.docId,
        'id'
      );
      if (!actcProcess) {
        return null;
      }
      await updateUserViewFromActcProcess(actcProcess);
    }
  );
