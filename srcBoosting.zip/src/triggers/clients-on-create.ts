import * as functions from 'firebase-functions';
import { Client } from '../interfaces';
import { getDocumentBySnapshot } from './utils';
import { updateSearchIndexInClient } from '../search-index/collections/clients';

const collectionName = 'clients';
export const clientsOnCreate = functions.firestore
  .document(`${collectionName}/{docId}`)
  .onCreate(
    async (snapshot, context): Promise<void | null> => {
      const client = getDocumentBySnapshot<Client>(
        snapshot,
        context.params.docId
      );
      if (!client) {
        return null;
      }
      await updateSearchIndexInClient(client);
    }
  );
