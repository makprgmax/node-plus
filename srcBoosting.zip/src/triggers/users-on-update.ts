import * as functions from 'firebase-functions';
import { User } from '../interfaces';
import { getDocumentBySnapshot } from './utils';
import { deleteUserView, updateUserView } from '../views/user-view';
import { sendGoodbyeEmail } from '../send-emails/goodbye-to-mentor';

const collectionName = 'users';
export const usersOnUpdate = functions.firestore
  .document(`${collectionName}/{docId}`)
  .onUpdate(
    async (snapshot, context): Promise<void | null> => {
      const user = getDocumentBySnapshot<User>(
        snapshot.after,
        context.params.docId,
        'uid'
      );
      if (!user) {
        return null;
      }
      // if authentication user was deleted, then user._deleted was set to current timestamp
      if (user._deleted) {
        await deleteUserView(user);
        await sendGoodbyeEmail(user);
      } else {
        await updateUserView(user);
      }
    }
  );
