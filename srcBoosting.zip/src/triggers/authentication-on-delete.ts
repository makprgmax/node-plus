import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
import { db } from '../init';
import { sendEmail } from '../utils';

async function markDocAsDeleted(
  firestoreDb: admin.firestore.Firestore,
  dbPath: string
): Promise<admin.firestore.WriteResult> {
  return db.doc(dbPath).update({
    _deleted: admin.firestore.FieldValue.serverTimestamp(),
  });
}

export const authenticationOnDelete = functions.auth.user().onDelete(
  async (user): Promise<void | null> => {
    if (!user || !user.uid) {
      return null;
    }
    try {
      await markDocAsDeleted(db, `users/${user.uid}`);
      await markDocAsDeleted(db, `userProfiles/${user.uid}`);
    } catch (e) {
      await sendEmail(`authenticationOnDelete - ${e?.message}`, e);
    }
  }
);
