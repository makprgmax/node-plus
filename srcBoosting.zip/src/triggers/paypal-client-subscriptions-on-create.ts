import * as functions from 'firebase-functions';
import { PaypalClientSubscription } from '../interfaces';
import { getDocumentBySnapshot } from './utils';
import { createPaypalClSubsViewPending } from '../views/paypal/paypal-cl-subs-view';
const collectionName = 'paypalClientSubscriptions';

export const paypalClientSubscriptionsOnCreate = functions.firestore
  .document(`${collectionName}/{docId}`)
  .onCreate(async (snapshot, context) => {
    const paypalClientSubscription = getDocumentBySnapshot<PaypalClientSubscription>(
      snapshot,
      context.params.docId
    );

    // add commands to be triggered by onCreate event
    await createPaypalClSubsViewPending(paypalClientSubscription!);
  });
