import { firestore } from 'firebase-admin/lib/firestore';
import QueryDocumentSnapshot = firestore.QueryDocumentSnapshot;
import { db } from '../init';
import { User, UserProfile } from '../interfaces';

export const getDocumentBySnapshot = <T extends unknown>(
  snapshot: QueryDocumentSnapshot,
  id: string,
  idFieldName = 'id'
): T | null => {
  if (!snapshot.exists) {
    return null;
  }
  return {
    ...snapshot.data(),
    [idFieldName]: id,
  } as T;
};

export const getDocumentAsync = async <T extends unknown>(
  collectionName: string,
  id: string,
  idFieldName = 'id'
): Promise<T | null> => {
  const ref = db.doc(`${collectionName}/${id}`);
  const snapshot = await ref.get();
  return getDocumentBySnapshot<T>(snapshot, id, idFieldName);
};

export const getUserByUidAsync = async (uid: string): Promise<User | null> =>
  getDocumentAsync<User>('users', uid, 'uid');

export const getUserProfileByUidAsync = async (
  uid: string
): Promise<UserProfile | null> =>
  getDocumentAsync<UserProfile>('userProfiles', uid, 'uid');
