import * as functions from 'firebase-functions';
import { User } from '../interfaces';
import { getDocumentBySnapshot } from './utils';
import { createUserView } from '../views/user-view';

const collectionName = 'users';
export const usersOnCreate = functions.firestore
  .document(`${collectionName}/{docId}`)
  .onCreate(
    async (snapshot, context): Promise<void | null> => {
      const user = getDocumentBySnapshot<User>(
        snapshot,
        context.params.docId,
        'uid'
      );
      if (!user) {
        return null;
      }
      await createUserView(user);
    }
  );
