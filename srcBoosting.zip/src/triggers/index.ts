import { authenticationOnDelete } from './authentication-on-delete';
import { clientsOnCreate } from './clients-on-create';
import { paypalClientSubscriptionsOnCreate } from './paypal-client-subscriptions-on-create';
import { paypalClientSubscriptionsOnUpdate } from './paypal-client-subscriptions-on-update';
import { usersOnCreate } from './users-on-create';
import { usersOnUpdate } from './users-on-update';
import { usersOnDelete } from './users-on-delete';
import { actcProcessesOnCreate } from './actc-processes-on-create';
import { actcProcessesOnUpdate } from './actc-processes-on-update';

const triggers = {
  authenticationOnDelete,
  clientsOnCreate,
  paypalClientSubscriptionsOnCreate,
  paypalClientSubscriptionsOnUpdate,
  usersOnCreate,
  usersOnUpdate,
  usersOnDelete,
  actcProcessesOnCreate,
  actcProcessesOnUpdate,
};

export default triggers;
