import { db } from './init';
import { getCollection } from './utils';

export async function updateDisplayNameInUsers(
  tableName: 'mentors' | 'clients' | 'users'
): Promise<Record<string, any>> {
  const profiles = await getCollection('userProfiles');
  const result: Record<string, any> = {};
  profiles.forEach((value) => {
    const profile = value.data();
    const { firstName, lastName, uid } = profile;
    const displayName =
      !!firstName || !!lastName ? `${firstName} ${lastName}` : '';
    result[uid] = {
      uid,
      displayName,
    };
  });
  const users = await getCollection(tableName);
  result.msg = `update ${tableName} v.3`;
  result.users = [];
  const batch = db.batch();
  users.forEach((user) => {
    const userData = user.data();
    if ((userData.displayName || '').trim() === '') {
      const newName =
        userData.uid &&
        ((result[userData.uid] && result[userData.uid].displayName) || null);
      if (newName) {
        batch.update(user.ref as any, {
          displayName: newName,
        });
      }

      result.users.push({
        newName,
        uid: userData.uid,
      });
    }
  });
  await batch.commit().catch((error: any) => {
    result.error = error;
  });
  return Promise.resolve(result);
}
