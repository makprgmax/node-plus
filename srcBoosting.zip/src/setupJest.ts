// @ts-ignore
import 'jest';
// import './jestGlobalMocks'; // browser mocks globally available for every test

Error.stackTraceLimit = 2;
