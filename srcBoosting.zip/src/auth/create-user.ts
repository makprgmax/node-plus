import * as admin from 'firebase-admin';
import { Request, Response } from 'express';
import { db } from '../init';
import {
  UserRoleEnum,
  UserProfileStatusEnum,
  ClientRegistrationState,
} from '../interfaces';
import WriteBatch = admin.firestore.WriteBatch;
import UserRecord = admin.auth.UserRecord;

export interface CreateUserProps {
  firstName: string;
  lastName: string;
  phoneNumber: string;
  email: string;
  password: string;
}
async function _createUser(props: CreateUserProps): Promise<boolean> {
  return new Promise(async (resolve, reject) => {
    const { email, firstName, lastName, password, phoneNumber } = props;
    const displayName = `${firstName} ${lastName}`;
    let userRecord: UserRecord;
    try {
      userRecord = await admin.auth().createUser({
        email,
        displayName,
        emailVerified: false,
        password,
        disabled: false,
      });
    } catch (error) {
      console.log(`Error creating new user: ${JSON.stringify(error)}`);
      reject(error);
      return;
    }
    console.log(`userRecord: ${JSON.stringify(userRecord)}`);
    const uid = userRecord.uid;
    const batch: WriteBatch = db.batch();
    console.log(`New user created`);

    // CREATE doc in collection users

    const newUserRef = db.doc(`users/${uid}`);
    const newUserData = {
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      email,
      displayName,
      emailVerified: false,
      permissions: {},
      role: UserRoleEnum.CLIENT,
      uid,
      userProfileStatus: UserProfileStatusEnum.INCOMPLETE,
      clientRegistrationState: ClientRegistrationState.initial,
    };
    // initial - means that verification email wasn't sent yet
    batch.set(newUserRef, newUserData);

    // CREATE doc in collection userProfiles
    const newUserProfileRef = db.doc(`userProfiles/${uid}`);
    const newUserProfileData = {
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      firstName,
      lastName,
      phoneNumber,
      uid,
    };
    batch.set(newUserProfileRef, newUserProfileData);

    try {
      await batch.commit();
      resolve(true);
    } catch (e) {
      reject(e);
    }
  });
}

export async function createUser(request: Request, response: Response) {
  const { email, password, firstName, lastName, phoneNumber } = request.body;
  const props: CreateUserProps = {
    email,
    password,
    firstName,
    lastName,
    phoneNumber,
  };
  const onError = (error: any) => {
    response.status(422).send(error || { code: 'server-error' });
  };
  try {
    _createUser(props)
      .then(() => {
        response.status(200).send({ code: 'success', message: '' });
      })
      .catch(onError);
  } catch (error) {
    onError(error);
  }
}
