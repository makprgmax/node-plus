import * as functions from 'firebase-functions';
import { db } from './init';
const path = require('path');
const os = require('os');
const mkdirp = require('mkdirp-promise');
const { Storage } = require('@google-cloud/storage');
const spawn = require('child-process-promise').spawn;
const rimraf = require('rimraf');

const gcs = new Storage();
const THUMB_PREFIX = 'thumb_';
export const resizeImage = functions.storage
  .object()
  .onFinalize(async (object, context) => {
    const fileFullPath = object.name || '';
    const contentType = object.contentType || '';
    const fileDir = path.dirname(fileFullPath);
    const fileName = path.basename(fileFullPath);
    const tempLocalDir = path.join(os.tmpdir(), fileDir);

    console.log('Image generation started: ', fileFullPath, fileDir, fileName);

    // prevent from infinite loop when uploaded thumbnail will trigger this function again
    if (
      !contentType.startsWith('image/') ||
      fileName.startsWith(THUMB_PREFIX)
    ) {
      console.log('Exiting earlier from image processing');
      return null;
    }

    await mkdirp(tempLocalDir);
    const bucket = gcs.bucket(object.bucket);
    const originalImageFile = bucket.file(fileFullPath);
    const tempLocalFile = path.join(os.tmpdir(), fileFullPath);
    console.log('Downloading image to: ', tempLocalFile);

    await originalImageFile.download({ destination: tempLocalFile });

    // Generate a resized image using ImageMagick
    const outputFilePath = path.join(fileDir, `${THUMB_PREFIX}${fileName}`);
    const outputFile = path.join(os.tmpdir(), outputFilePath);
    console.log('Generating a thumbnail to: ', outputFile);

    await spawn(
      'convert',
      [tempLocalFile, '-thumbnail', '300x300 >', outputFile],
      { capture: ['stdout', 'stderr'] }
    );

    // Upload the thumbnail back to storage

    // noinspection SpellCheckingInspection
    const metadata = {
      contentType: object.contentType,
      cacheControl: 'public,max-age=2592000, s-maxage=2592000',
    };

    console.log(
      'Uploading the thumbnail to storage: ',
      outputFile,
      outputFilePath
    );
    const uploadedFiles = await bucket.upload(outputFile, {
      destination: outputFilePath,
      metadata,
    });

    // clean up file system
    rimraf.sync(tempLocalDir);

    // in case we need to delete the original file
    // !await! originalImageFile.delete();

    // create link to uploaded file
    const thumbnail = uploadedFiles[0];

    const url = await thumbnail.getSignedUrl({
      action: 'read',
      expires: new Date(3000, 0, 1),
    });
    console.log('Generated signed url: ', url);

    const frags = fileFullPath.split('/');
    const userProfileId = frags[1];
    console.log('saving url to db userProfileId = ', userProfileId);

    // detect which kind of image is that: id or ssn?
    const imageField = fileName.startsWith('id')
      ? 'idThumbnailUrl'
      : fileName.startsWith('ssn')
      ? 'ssnThumbnailUrl'
      : 'unknownThumbnailUrl';

    return db
      .doc(`userProfiles/${userProfileId}`)
      .update({ [imageField]: url });
  });
