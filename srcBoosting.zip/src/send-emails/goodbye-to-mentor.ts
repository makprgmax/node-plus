import * as admin from 'firebase-admin';
import {
  EmailTemplate,
  EmailTemplateNameEnum,
  SendEmail,
  User,
  UserRoleEnum,
} from '../interfaces';
import { sendEmail, sendEmailTemplate } from '../utils';
import DocumentReference = admin.firestore.DocumentReference;
import { environment } from '../environments/environment';

export const sendGoodbyeEmail = async (
  user: User
): Promise<DocumentReference<SendEmail> | null> => {
  try {
    if (user.role === UserRoleEnum.MENTOR) {
      // send goodbye email to mentor
      const to = [user.email, ...environment.sendEmails.accountants];
      const emailTemplate: EmailTemplate = {
        name: EmailTemplateNameEnum.goodbyeToMentor,
        data: {
          mentorName: user.displayName,
        },
      };
      return sendEmailTemplate({
        to,
        emailTemplate,
      });
    }
    return null;
  } catch (e) {
    await sendEmail(`sendGoodbyeEmail - ${e?.message}`, e);
    return null;
  }
};
