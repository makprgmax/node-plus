import { dateToUSFormatString } from './utils';

type LeadingZero = boolean;
type DateToUSFormatStringType = [string, LeadingZero, string];
describe('utils', () => {
  describe('dateToUSFormatString', () => {
    it.each<DateToUSFormatStringType>([
      ['2021-04-01', true, '04/01/2021'],
      ['2021-04-01', false, '4/1/2021'],
      ['2021-10-15', true, '10/15/2021'],
      ['2021-10-15', false, '10/15/2021'],
    ])('%s, leadingZero=%s -> %s', (income, leadingZero, outcome) => {
      expect(dateToUSFormatString(new Date(income), leadingZero)).toEqual(
        outcome
      );
    });
  });
});
