import * as admin from 'firebase-admin';
import DocumentReference = admin.firestore.DocumentReference;
import WriteResult = admin.firestore.WriteResult;
import WriteBatch = admin.firestore.WriteBatch;

const MAX_ITEMS_IN_BATCH = 200; // 499;
export interface BatchPlus<T> {
  set(documentRef: DocumentReference<T>, data: T): BatchPlus<T>;
  update(documentRef: DocumentReference<T>, data: Partial<T>): BatchPlus<T>;
  delete(documentRef: DocumentReference<any>): BatchPlus<T>;
  commit(): Promise<WriteResult[]>;
}

/**
 * extends the limit of 500 operations per one batch
 * @param db admin.firestore.Firestore
 */
export function batchPlus<T>(db: admin.firestore.Firestore): BatchPlus<T> {
  const batchArray: WriteBatch[] = [];
  batchArray.push(db.batch());
  let operationCounter = 0;
  let batchIndex = 0;
  let that: BatchPlus<T> = {} as BatchPlus<T>;
  const checkCounter = () => {
    if (operationCounter >= MAX_ITEMS_IN_BATCH) {
      console.log('Next Batch in BatchPlus');
      batchArray.push(db.batch());
      batchIndex++;
      operationCounter = 0;
    }
  };

  const setFn = (documentRef: DocumentReference<T>, data: T): BatchPlus<T> => {
    batchArray[batchIndex].set(documentRef, data);
    operationCounter++;
    checkCounter();
    return that;
  };
  const updateFn = (
    documentRef: DocumentReference<T>,
    data: T
  ): BatchPlus<T> => {
    batchArray[batchIndex].update(documentRef, data);
    operationCounter++;
    checkCounter();
    return that;
  };
  const deleteFn = (documentRef: DocumentReference<any>): BatchPlus<T> => {
    batchArray[batchIndex].delete(documentRef);
    operationCounter++;
    checkCounter();
    return that;
  };

  const commitFn = async (): Promise<WriteResult[]> => {
    return Promise.all(
      batchArray.map((batch) => batch.commit())
    ).then((resultsAry) => Array.prototype.concat([], resultsAry));
  };

  that = {
    set: setFn,
    update: updateFn,
    delete: deleteFn,
    commit: commitFn,
  } as BatchPlus<T>;
  return that;
}
