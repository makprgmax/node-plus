// @ts-ignore
import * as admin from 'firebase-admin';
import Timestamp = admin.firestore.Timestamp;
import FieldValue = admin.firestore.FieldValue;
import { SearchIndexMap } from './search-index/search-index-utils';

export type APIResult = Record<string, any>;

export type CardLevel = number;

// TODO can be used with TS 4.1
// type MM = '01'|'02'|'03'|'04'|'05'|'06'|'07'|'08'|'09'|'10'|'11'|'12'
// type YYYY = '2020'|'2021'|'2022'|'2023'|'2024'|'2025'
// type Period = `${YYYY}-${MM}`
export type Period = string;
export type MonthlyRate = number;

export enum UserRoleEnum {
  CLIENT = 'client',
  MENTOR = 'mentor',
  MANAGER = 'manager',
}

export enum UserProfileStatusEnum {
  INCOMPLETE = 'INCOMPLETE', // user has not completed the profile
  COMPLETE = 'COMPLETE', // user has completed the profile
  VERIFIED = 'VERIFIED', // when manager has verified user profile

  // when manager has started verification process, e.g. he sent some direct messages to user
  VERIFYING = 'VERIFYING',

  // when manager has found issues in profile and requested an update
  // (e.g. a specific direct message was send by manager)
  REQUESTED_UPDATE = 'REQUESTED_UPDATE',
}

export enum PermissionEnum {
  admin = 'admin',
  accountant = 'accountant',
  registration_manager = 'registration_manager',
  boosting_manager = 'boosting_manager',
}
export type Permissions = Partial<Record<PermissionEnum, boolean>>;

export interface FirebaseDocument {
  createdAt: Timestamp;
  updatedAt?: Timestamp;
}

export enum ClientRegistrationState {
  initial = 'initial',
  email_pending = 'email_pending',
  waiting_for_payment = 'waiting_for_payment',
  payment_initialized = 'payment_initialized',
  payment_active = 'payment_active',
  registration_completed = 'registration_completed',
}

export interface User {
  createdAt: Timestamp;
  updatedAt?: Timestamp | FieldValue;
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  role: UserRoleEnum;
  permissions: Permissions;
  emailVerified: boolean;
  phoneNumber: string;
  userProfileStatus: UserProfileStatusEnum;
  clientRegistrationState?: ClientRegistrationState;
  _deleted?: Timestamp;
}

export enum InitialCreditScoreStatusEnum {
  ALREADY_HAVE = 'ALREADY_HAVE', // Client has got hard inquiries, so she uploaded related files for manual check
  GET_MYSELF = 'GET_MYSELF', // Client hasn't got them yet, she is going to get them herself
  PAY = 'PAY', // Client hasn't got them yet, she is going to pay us to get them for her
  UNDEFINED = 'UNDEFINED', // default
}

export enum GenderEnum {
  MALE = 'male',
  FEMALE = 'female',
}

export interface UserProfile extends FirebaseDocument {
  uid: string;
  firstName: string;
  lastName: string;
  birthDate: Date | Timestamp;
  gender: GenderEnum;
  address1: string;
  address2?: string;
  state: string;
  city: string;
  zipCode: string;
  idNumber: string;
  idUrl: string;
  idThumbnailUrl: string;
  ssn?: string; // ssn related fields are removed from the role Mentor
  ssnUrl?: string;
  ssnThumbnailUrl: string;
  phoneNumber: string;
  phoneVerified: boolean;
  phoneNumberManualConfirmationRequired?: boolean; // true - client/mentor requested manual verification of the phone
  // step-4
  initialCreditScoreStatus: InitialCreditScoreStatusEnum;
  initialCreditScoreUrls: string[];
  // fields for manager
  idConfirmed: boolean;
  ssnConfirmed?: boolean;
  creditReportConfirmed: boolean;
  phoneNumberConfirmed?: boolean; // is used only if phoneNumberManualConfirmationRequired is set to TRUE
  _deleted?: Timestamp;
}

// userViewClients and userViewMentors collections
export interface UserView {
  createdAt: Timestamp;
  updatedAt: Timestamp;
  id: string; // equals to uid
  email: string;
  displayName: string;
  role: UserRoleEnum;
  phoneNumber: string;
  userProfileStatus: UserProfileStatusEnum;
  clientRegistrationState?: ClientRegistrationState;
  searchIndex: SearchIndexMap;
  _deleted?: Timestamp; // substitute to deleting the record;

  actcProcessStates?: ACTCProcessStatesByRole; // related to UserViewMentor
}

export const UserViewCollectionsDictionary: Partial<
  Record<UserRoleEnum, string>
> = {
  [UserRoleEnum.CLIENT]: 'userViewClients',
  [UserRoleEnum.MENTOR]: 'userViewMentors',
};

export enum MState {
  mentor__initial = 'mentor__initial',
  manager__waiting_for_client = 'manager__waiting_for_client',
  end__client_not_attached = 'end__client_not_attached',
  mentor__client_attached = 'mentor__client_attached',
  manager__bank_cancelled = 'manager__bank_cancelled',
  end__client_detached = 'end__client_detached',
  manager__waiting_for_more_data_from_manager = 'manager__waiting_for_more_data_from_manager',
  mentor__client_assigned_in_bank_requested_update = 'mentor__client_assigned_in_bank_requested_update',

  // deprecated states
  manager__client_assigned_in_bank = 'manager__client_assigned_in_bank', // deprecated
  end__client_assigned_in_bank_verified = 'end__client_assigned_in_bank_verified', // deprecated

  // new states
  mentor__client_assigned_in_bank = 'mentor__client_assigned_in_bank',
  manager__mentor_attached_receipt = 'manager__mentor_attached_receipt',
  mentor__receipt_update_requested = 'mentor__receipt_update_requested',
  client__boosting = 'client__boosting',
  end__boosting = 'end__boosting',
  end__boosting_mentor_detached_client = 'end__boosting_mentor_detached_client',
}

export enum VerifyStatusEnum {
  NEW = 'NEW',
  SUBMITTED = 'SUBMITTED',
  VERIFIED = 'VERIFIED',
  CANCELLED = 'CANCELLED',
}

export type MentorId = string;
export interface Mentor {
  id: MentorId;
  uid: string;
  displayName: string;
  clientsCount: number;
  clientIds: string[];
  createdAt: Timestamp;
  updatedAt?: Timestamp;
}

export interface MentorCard {
  id: string;
  mentorId: MentorId;
  cardNumber: string;
  cardBudget: number;
  cardBank: string;
  clientsCount: number;
  clientIds: string[];
  cardOpenedAt: Timestamp;
  // clientIds and clientsCount should be in sync
  verifyStatus: VerifyStatusEnum;
  managerComment?: string;
  createdAt?: Date | Timestamp;
  updatedAt?: Date | Timestamp;
}

export interface AttachClientToCardProcess {
  id: string;
  mentorId: MentorId;
  clientId?: string;
  mentorCardId: string;
  state: MState;
  grantAccessToClientID?: boolean;
  grantAccessToClientSSN?: boolean;
  createdAt: Timestamp;
  updatedAt?: Timestamp;
  // de-normalization fields
  cardNumber?: string;
  clientDisplayName?: string;
  mentorDisplayName?: string;
  latestManagerComment?: string;
  latestMentorComment?: string;
  // deprecated :: endStateAt?: Timestamp; // set when some 'end__' state is set
  stateTimestamps?: Partial<Record<MState, Timestamp>>; // store timestamp for each changed state
}

/**
 * stores number of ACTCProcesses where actcProcess.state starts with related prop
 * e.g. started with manager - manager__waiting_for_client or manager__mentor_attached_receipt
 */

export enum ACTCProcessStateByRoleEnum {
  manager = 'manager',
  mentor = 'mentor',
  end = 'end',
  client = 'client',
  undefined = 'undefined',
}
export type ACTCProcessStatesByRole = Partial<
  Record<ACTCProcessStateByRoleEnum, number>
>;

export interface MonthlyIncomeRegistry {
  id: string;
  cardLevel: number;
  monthlyRate: number;
  period: Period;
  createdAt: Timestamp;
  updatedAt?: Timestamp;
}

// const expected: Partial<MentorProcessPeriodIncome> = {
//   id: 'actcProcessId-2020-10',
//   // periodIncome: 5,
//   actcProcessId: 'actcProcessId',
//   period: '2020-10',
//   // cardLevel: 1,
//   mentorCardId: 'mentorCardId',
//   mentorId: 'mentorId',
// }

export type MentorProcessPeriodIncomeId = string;
export interface PartialMentorProcessPeriodIncome {
  id: MentorProcessPeriodIncomeId; // = `${actcProcessId}-${period}`
  actcProcessId: string;
  period: Period;
  mentorCardId: string;
  mentorId: string;
}

export interface MentorProcessPeriodIncome
  extends PartialMentorProcessPeriodIncome {
  periodIncome: MonthlyRate;
  cardLevel: CardLevel;
  createdAt: Timestamp;
  updatedAt?: Timestamp;
}

export type MentorPeriodIncomeId = string;
export interface MentorPeriodIncome {
  id: MentorPeriodIncomeId; // = `${mentorId}-${period}`
  mentorId: MentorId;
  period: Period;
  periodIncome: number;
  createdAt: Timestamp;
  updatedAt?: Timestamp;
}

export enum WithdrawalRequestStatusEnum {
  SUBMITTED = 'SUBMITTED',
  PAID = 'PAID',
  REJECTED = 'REJECTED',
}

export type MentorWithdrawalRequestId = string;
export interface MentorWithdrawalRequest {
  id: MentorWithdrawalRequestId;
  mentorId: MentorId;
  period: Period;
  amount: number;
  requestStatus: WithdrawalRequestStatusEnum;
  mentorWithdrawalId?: MentorWithdrawalId;
  createdAt: Timestamp;
  updatedAt?: Timestamp;
}

export type MentorWithdrawalId = string;
export interface MentorWithdrawal {
  id: MentorWithdrawalId; // id is the same as in related MentorWithdrawalRequest
  mentorId: MentorId;
  period: Period;
  amount: number;
  createdAt: Timestamp;
  updatedAt?: Timestamp;
}

export type MentorBalanceId = string;
export interface MentorBalance {
  id: MentorBalanceId; // <mentorId>-<period>
  mentorId: MentorId;
  period: Period;
  periodIncome: number;
  periodWithdrawal: number;
  periodBalance: number; // = periodIncome - periodWithdrawal
  totalIncome: number; // sum of all previous periodIncome + current
  totalWithdrawal: number; // sum of all previous periodWithdrawal + current
  totalBalance: number; // = sum of all previous periodBalance + current
  createdAt: Timestamp;
  updatedAt?: Timestamp;
}

export enum EmailTemplateNameEnum {
  // cancelMentorCard = 'cancelMentorCard',
  // confirmMentorCard = 'confirmMentorCard',
  // newMentorWithdrawalRequest = 'newMentorWithdrawalRequest',
  // paidWithdrawalRequest = 'paidWithdrawalRequest',
  // rejectedWithdrawalRequest = 'rejectedWithdrawalRequest',
  goodbyeToMentor = 'goodbyeToMentor',
  // goodbyeToClient = 'goodbyeToClient',
}

export interface GoodbyeToMentorEmailMeta {
  mentorName: string;
}

export interface EmailTemplate {
  name: EmailTemplateNameEnum;
  data: GoodbyeToMentorEmailMeta;
}

export interface SendEmail {
  message: {
    subject: string;
    html: string;
    text?: string;
  };
  template?:
    | EmailTemplate
    | {
        name: string;
        data?: { [key: string]: any };
      };
  to: string;
  toUids?: string[];
  cc: string[];
  ccUids?: string[];
  bcc?: string[];
  bccUids?: string[];
  from?: string;
  replyTo?: string;
}

export interface MentorDirectDepositForm {
  id: string;
  uid: string;
  name: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  checkingAccountNumber: string;
  // [DEPRECATED] marketAccountNumber: string;
  bankName: string;
  bankRoutingNumber: string;
  verifyStatus: VerifyStatusEnum;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export enum ClientStatus {
  WAITING = 'WAITING',
  CHOSEN = 'CHOSEN',
  ACTIVE = 'ACTIVE',
}

export type ClientId = string;
export interface Client {
  id: ClientId;
  uid: string;
  displayName: string;
  email: string;
  phoneNumber: string;
  creditScore: number;
  status: ClientStatus;
  mentorsCount: number; // TODO deprecate usage of ...Count field
  mentorIds: MentorId[];
  mentorCardsCount: number;
  mentorCardIds: string[];
  createdAt: Timestamp;
  updatedAt?: Timestamp;
  searchIndex?: SearchIndexMap;
}

export enum PaypalStatus {
  APPROVAL_PENDING = 'APPROVAL_PENDING',
  APPROVED = 'APPROVED',
  ACTIVE = 'ACTIVE',
  SUSPENDED = 'SUSPENDED',
  CANCELLED = 'CANCELLED',
  EXPIRED = 'EXPIRED',
}
export enum PaypalSubscriptionState {
  no_subscription = 'no_subscription',
  init_pending = 'init_pending',
  active = 'active',
  suspended = 'suspended',
  init_cancelled = 'init_cancelled',
  cancelled = 'cancelled',
  expired = 'expired',
  init_error = 'init_error',
}

interface PaypalWebhookLogRequestLink {
  href: string;
  method: string;
  rel: string;
}

interface PaypalWebhookLogRequestResourceShippingAmount {
  currency_code: string;
  value: string;
}

interface PaypalWebhookLogRequestResourceSubscriber {
  email_address: string;
  name: {
    given_name: string;
    surname: string;
  };
  payer_id: string;
  shipping_address: {
    address: {
      address_line_1: string;
      address_line_2: string;
      admin_area_1: string;
      admin_area_2: string;
      country_code: string;
      postal_code: string;
    };
    name: {
      full_name: string;
    };
  };
}

type PaypalWebhookLogRequestResourceBillingInfo = Record<string, any>;
interface PaypalWebhookLogRequestResource {
  billing_info?: PaypalWebhookLogRequestResourceBillingInfo;
  create_time: string;
  id: string;
  links: PaypalWebhookLogRequestLink[];
  plan_id: string;
  plan_overridden: boolean;
  quantity: string;
  shipping_amount?: PaypalWebhookLogRequestResourceShippingAmount;
  start_time: string;
  status: PaypalStatus;
  status_update_time?: string;
  subscriber?: PaypalWebhookLogRequestResourceSubscriber;
}

interface PaypalWebhookLogRequest {
  create_time: string;
  event_type: string;
  event_version: string;
  id: string;
  links: PaypalWebhookLogRequestLink[];
  resource: PaypalWebhookLogRequestResource;
  resource_type: string;
  resource_version: string;
  summary: string;
}

export interface PaypalWebhookLog {
  id: string;
  createdAt: Timestamp;
  request: PaypalWebhookLogRequest;
  version: number;
  processed: boolean;
  processedAt?: Timestamp;
}

export type PaypalSubscriptionId = string;
export type PaypalPayerID = string;
export type PaypalPlanId = string;

export enum PaypalProductType {
  subscription = 'subscription',
  boosting = 'boosting',
  otherServices = 'otherServices',
}

export const PaypalProductTypeShort: Record<PaypalProductType, string> = {
  [PaypalProductType.subscription]: 's',
  [PaypalProductType.boosting]: 'b',
  [PaypalProductType.otherServices]: 'o',
};

export enum PaypalSubscriptionPlanType {
  planBasicDiscount = 'planBasicDiscount', // deprecated
  planBasic = 'planBasic',
  planStandard = 'planStandard',
  planPremium = 'planPremium',
  planBasicWithFreePeriod = 'planBasicWithFreePeriod',
}

export enum PaypalBoostingPlanType {
  boostingPayments1 = 'boostingPayments1',
  boostingPayments2 = 'boostingPayments2',
  boostingPayments3 = 'boostingPayments3',
  boostingPayments4 = 'boostingPayments4',
  boostingPayments5 = 'boostingPayments5',
  boostingPayments6 = 'boostingPayments6',
}

export enum PaypalOtherServicesPlanType {
  consultingPersonal = 'consultingPersonal',
  consultingBusiness = 'consultingBusiness',
}

export type PaypalPlan =
  | PaypalSubscriptionPlanType
  | PaypalBoostingPlanType
  | PaypalOtherServicesPlanType;

export const PaypalPlanShort: Record<PaypalPlan, string> = {
  [PaypalSubscriptionPlanType.planBasic]: 'b',
  [PaypalSubscriptionPlanType.planPremium]: 'p',
  [PaypalSubscriptionPlanType.planStandard]: 's',
  [PaypalSubscriptionPlanType.planBasicDiscount]: 'd',
  [PaypalSubscriptionPlanType.planBasicWithFreePeriod]: 'f',
  [PaypalBoostingPlanType.boostingPayments1]: 'b1',
  [PaypalBoostingPlanType.boostingPayments2]: 'b2',
  [PaypalBoostingPlanType.boostingPayments3]: 'b3',
  [PaypalBoostingPlanType.boostingPayments4]: 'b4',
  [PaypalBoostingPlanType.boostingPayments5]: 'b5',
  [PaypalBoostingPlanType.boostingPayments6]: 'b6',
  [PaypalOtherServicesPlanType.consultingBusiness]: 'cb',
  [PaypalOtherServicesPlanType.consultingPersonal]: 'cp',
};

export interface PaypalClient {
  id: string; // id === uid

  createdAt: Timestamp;
  updatedAt?: Timestamp;
  subscriptionIds: Record<PaypalSubscriptionId, boolean>;
  // store all subscription ids as keys in the map

  payerIds: Record<PaypalPayerID, boolean>;
  // store all payer ids as keys in the map,
  // theoretically client can use different paypal accounts
  // for different subscriptions

  // v2: only one plan can be active within a product
  activeSubscriptionPlan: PaypalSubscriptionPlanType | null;
  activeBoostingPlan: PaypalBoostingPlanType | null;
  activeOtherServicePlan: PaypalOtherServicesPlanType | null;
  showSubscriptionPlanBasicDiscount: boolean; // deprecated
}

export interface PaypalClientSubscription {
  id: PaypalSubscriptionId;
  createdAt: Timestamp;
  updatedAt: Timestamp;
  cancelledAt?: Timestamp;
  activatedAt?: Timestamp;
  expiredAt?: Timestamp;
  state: PaypalSubscriptionState;
  archived: boolean; // when true, the subscription is in archive
  payerID: PaypalPayerID | null;
  orderID: string | null;
  initURL: string | null;
  // e.g. https://www.paypal.com/webapps/billing/subscriptions?ba_token=BA-...

  paypalStatus: PaypalStatus;
  // the one which came through webhook

  planId: PaypalPlanId;
  uid: string;
  paypalWebhookLogIds: Record<string, boolean>;

  // v2
  paypalProductType: PaypalProductType;
  paypalPlanType: PaypalPlan;
}

export interface PaypalClientSubscriptionView {
  id: string; // uid-PaypalProductTypeShort-PaypalPlanShort
  paypalClientSubscriptionId: string; // id of original record
  paypalProductType: PaypalProductType;
  paypalPlanType: PaypalPlan;
  state: PaypalSubscriptionState; // this one for debugging purpose only
  uid: string;
  userCreatedAt: Timestamp;
  createdAt: Timestamp;
  updatedAt: Timestamp;
  displayName: string;
  email: string;
  phoneNumber: string;
  searchIndex: SearchIndexMap;
  _deleted?: Timestamp; // substitute to deleting the record;
}

// aggregated collection; shows users with paypal state === PaypalSubscriptionState.init_pending
// export interface PaypalClSubsViewPending
//   extends PaypalClientSubscriptionView {}

// aggregated collection; shows users with paypal state === PaypalSubscriptionState.active
// export interface PaypalClSubsViewActive
//   extends PaypalClientSubscriptionView {}

// aggregated collection; shows users with paypal state === PaypalSubscriptionState.cancelled
// export interface PaypalClSubsViewCancelled
//   extends PaypalClientSubscriptionView {}

// aggregated collection; shows users with paypal state === PaypalSubscriptionState.suspended
// export interface PaypalClSubsViewSuspended
//   extends PaypalClientSubscriptionView {}

// aggregated collection; shows users with paypal state === PaypalSubscriptionState.expired
// export interface PaypalClSubsViewExpired
//   extends PaypalClientSubscriptionView {}

// a dictionary which maps Collection name with PaypalSubscriptionState
// it helps to get correct Collection name by PaypalSubscriptionState
export const PaypalClSubsViewCollectionsDictionary: Partial<
  Record<PaypalSubscriptionState, string>
> = {
  [PaypalSubscriptionState.init_pending]: 'paypalClSubsViewPending',
  [PaypalSubscriptionState.active]: 'paypalClSubsViewActive',
  [PaypalSubscriptionState.cancelled]: 'paypalClSubsViewCancelled',
  [PaypalSubscriptionState.suspended]: 'paypalClSubsViewSuspended',
  [PaypalSubscriptionState.expired]: 'paypalClSubsViewExpired',
};
