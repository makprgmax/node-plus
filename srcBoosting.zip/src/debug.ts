// app.get('/users', async (request: any, response: any) => {
//   const snaps: QuerySnapshot<DocumentData> = await db.collection('users').get();
//   const users: Record<string, any>[] = [];
//   snaps.forEach((snap) => users.push(snap.data()));
//
//   response.status(200).json({ users });
//   response.status(200).json({ users });
// });
// app.get('/update-display-name', async (request: any, response: any) => {
//   const users = await updateDisplayNameInUsers('users');
//   const mentors = await updateDisplayNameInUsers('mentors');
//   const clients = await updateDisplayNameInUsers('clients');
//   response.status(200).json({ clients, mentors, users });
// });

// app.get('/generate-created-at', async (request: any, response: any) => {
//   const result = await generateCreatedAt();
//   response.status(200).json({ result });
// });

// app.get(
//   '/update-mentor-process-period-income',
//   async (request: any, response: any) => {
//     try {
//       const result = await updateMentorProcessPeriodIncome();
//       response.status(200).json({ result });
//     } catch (e) {
//       response.status(200).json({ error: e.message });
//     }
//   }
// );

// app.get('/update-mentor-period-income', async (request: any, response: any) => {
//   try {
//     const result = await updateMentorPeriodIncome();
//     response.status(200).json({ result });
//   } catch (e) {
//     response.status(200).json({ error: e.message });
//   }
// });

// app.get('/update-mentor-balance', async (request: any, response: any) => {
//   try {
//     const result = await updateMentorBalance();
//     response.status(200).json({ result });
//   } catch (e) {
//     response.status(200).json({ error: e.message });
//   }
// });

// app.get(
//   '/daily-update-mentor-process-period-income',
//   async (request: any, response: any) => {
//     try {
//       const result = await dailyUpdateMentorProcessPeriodIncome();
//       response.status(200).json({ result });
//     } catch (e) {
//       response.status(200).json({ error: e.message });
//     }
//   }
// );

// app.get(
//   '/daily-update-mentor-period-income',
//   async (request: any, response: any) => {
//     try {
//       const result = await dailyUpdateMentorPeriodIncome();
//       response.status(200).json({ result });
//     } catch (e) {
//       response.status(200).json({ error: e.message });
//     }
//   }
// );

// app.get('/daily-update-mentor-balance', async (request: any, response: any) => {
//   try {
//     const result = await dailyUpdateMentorBalance();
//     response.status(200).json({ result });
//   } catch (e) {
//     response.status(200).json({ error: e.message });
//   }
// });

// app.get('/monthly-update', async (request: any, response: any) => {
//   try {
//     const result = await monthlyCopyMentorBalanceFromPreviousMonth();
//     return response.status(200).json({ result });
//   } catch (e) {
//     return response.status(200).json({ error: e.message });
//   }
// });
