import { APIResult, PaypalWebhookLog } from '../interfaces';
import { parsePaypalWebhookLog } from './paypal-webhook-log-parser';
import * as functions from 'firebase-functions';

const collectionName = 'paypalWebhookLog';

export const updatePaypalClientSubscription = functions.firestore
  .document(`${collectionName}/{docId}`)
  .onCreate(async (snapshot, context) => {
    const webhookLogId = context.params.docId as string;
    const webhookLog: PaypalWebhookLog = {
      ...(snapshot.data() as PaypalWebhookLog),
      id: webhookLogId,
    };

    const apiLog: APIResult = {};
    await parsePaypalWebhookLog(webhookLog, apiLog);
  });
