import {
  APIResult,
  PaypalClientSubscription,
  PaypalStatus,
  PaypalWebhookLog,
} from '../interfaces';
import * as admin from 'firebase-admin';
import { db } from '../init';
import { EventContext } from 'firebase-functions';
import { firestore } from 'firebase-admin/lib/firestore';
import { paypalStatusToStateDictionary } from './utils';
import Timestamp = admin.firestore.Timestamp;
import WriteBatch = admin.firestore.WriteBatch;
import QuerySnapshot = firestore.QuerySnapshot;
import WriteResult = admin.firestore.WriteResult;

interface MarkWebhookLogAsParsedParams {
  batch: WriteBatch;
  webhookLog: PaypalWebhookLog;
}
const markWebhookLogAsProcessed = (
  params: MarkWebhookLogAsParsedParams
): void => {
  const { batch, webhookLog } = params;
  const webhookLogRef = db.doc(`paypalWebhookLog/${webhookLog.id}`);
  const updated: Partial<PaypalWebhookLog> = {
    processed: true,
    processedAt: Timestamp.now(),
  };
  batch.update(webhookLogRef, updated);
};

export async function parsePaypalWebhookLog(
  paypalWebhookLog: PaypalWebhookLog,
  result: APIResult
): Promise<WriteResult[]> {
  const batch: WriteBatch = db.batch();
  const { resource, resource_type } = paypalWebhookLog.request;
  if (resource_type === 'subscription') {
    const subscriptionID = resource.id;
    const paypalStatus: PaypalStatus = resource.status;
    const relatedSubscriptionRef = db.doc(
      `paypalClientSubscriptions/${subscriptionID}`
    );
    const relatedSubscriptionSnapshot = await relatedSubscriptionRef.get();
    // if relatedSubscription exists then update it
    if (relatedSubscriptionSnapshot.exists) {
      // const relatedSubscription = {
      //   id: relatedSubscriptionSnapshot.id,
      //   ...relatedSubscriptionSnapshot.data(),
      // };
      // console.log(`relatedSubscription exists, id = ${subscriptionID}`);
      // console.log({ relatedSubscription });

      const updatedData: Partial<PaypalClientSubscription> = {
        archived: false,
        planId: resource.plan_id,
        paypalStatus,
        state: paypalStatusToStateDictionary[paypalStatus],
        updatedAt: Timestamp.now(),
      };
      if (
        paypalStatus === PaypalStatus.APPROVED ||
        paypalStatus === PaypalStatus.ACTIVE
      ) {
        updatedData.activatedAt = Timestamp.now();
        updatedData.payerID = resource.subscriber?.payer_id;
      } else if (paypalStatus === PaypalStatus.CANCELLED) {
        updatedData.cancelledAt = Timestamp.now();
      } else if (paypalStatus === PaypalStatus.EXPIRED) {
        updatedData.expiredAt = Timestamp.now();
      } else if (paypalStatus === PaypalStatus.APPROVAL_PENDING) {
        updatedData.initURL = (
          resource.links.find((link) => link.rel === 'approve') || { href: '' }
        ).href;
      }
      result[paypalWebhookLog.id] = {
        updatedData,
      };
      batch.update(relatedSubscriptionRef, updatedData);
    } else {
      // if relatedSubscription does not exist then create it
      // console.log(`relatedSubscription does NOT exist, id = ${subscriptionID}`);
      // TODO notify developer by email
      // create related Subscription but unfortunately without uid
      const createdData: Partial<PaypalClientSubscription> = {
        id: subscriptionID,
        state: paypalStatusToStateDictionary[paypalStatus],
        paypalStatus,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now(),
        planId: resource.plan_id,
        archived: false,
        uid: 'undefined',
      };
      if (
        paypalStatus === PaypalStatus.APPROVED ||
        paypalStatus === PaypalStatus.ACTIVE
      ) {
        createdData.activatedAt = Timestamp.now();
        createdData.payerID = resource.subscriber?.payer_id;
      } else if (paypalStatus === PaypalStatus.CANCELLED) {
        createdData.cancelledAt = Timestamp.now();
      } else if (paypalStatus === PaypalStatus.EXPIRED) {
        createdData.expiredAt = Timestamp.now();
      } else if (paypalStatus === PaypalStatus.APPROVAL_PENDING) {
        createdData.initURL = (
          resource.links.find((link) => link.rel === 'approve') || { href: '' }
        ).href;
      }
      result[paypalWebhookLog.id] = {
        createdData,
      };
      batch.set(relatedSubscriptionRef, createdData);
    }
  }
  markWebhookLogAsProcessed({
    batch,
    webhookLog: paypalWebhookLog,
  });
  return batch.commit();
}

export async function paypalWebhookLogParser(
  context?: EventContext
): Promise<APIResult> {
  const result: APIResult = {};
  const paypalWebhookLogsSnapshot: QuerySnapshot<PaypalWebhookLog> = await db
    .collection('paypalWebhookLog')
    .where('processed', '==', false)
    .orderBy('createdAt', 'asc')
    .limit(20)
    .get();
  if (paypalWebhookLogsSnapshot.empty) {
    result['paypalWebhookLogs'] = 'empty';
    return Promise.resolve(result);
  }
  for (let i = 0, len = paypalWebhookLogsSnapshot.docs.length; i < len; i++) {
    const snapshot = paypalWebhookLogsSnapshot.docs[i];
    const paypalWebhookLog: PaypalWebhookLog = {
      ...snapshot.data(),
      id: snapshot.id,
    };
    await parsePaypalWebhookLog(paypalWebhookLog, result);
  }
  return Promise.resolve(result);
}
