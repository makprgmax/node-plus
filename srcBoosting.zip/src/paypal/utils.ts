import { PaypalStatus, PaypalSubscriptionState } from '../interfaces';

export const paypalStatusToStateDictionary: Record<
  PaypalStatus,
  PaypalSubscriptionState
> = {
  [PaypalStatus.APPROVAL_PENDING]: PaypalSubscriptionState.init_pending,
  [PaypalStatus.ACTIVE]: PaypalSubscriptionState.active,
  [PaypalStatus.APPROVED]: PaypalSubscriptionState.active,
  [PaypalStatus.CANCELLED]: PaypalSubscriptionState.cancelled,
  [PaypalStatus.SUSPENDED]: PaypalSubscriptionState.suspended,
  [PaypalStatus.EXPIRED]: PaypalSubscriptionState.expired,
};
