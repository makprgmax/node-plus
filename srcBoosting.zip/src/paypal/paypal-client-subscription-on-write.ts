import {
  APIResult,
  ClientRegistrationState,
  PaypalClient,
  PaypalClientSubscription,
  PaypalProductType,
  PaypalStatus,
  User,
  UserProfileStatusEnum,
} from '../interfaces';
import * as functions from 'firebase-functions';
import { db } from '../init';
import * as admin from 'firebase-admin';
import WriteBatch = admin.firestore.WriteBatch;
import DocumentReference = admin.firestore.DocumentReference;

const collectionName = 'paypalClientSubscriptions';

const paypalStatusToClientRegistrationStateDictionary: Record<
  PaypalStatus,
  ClientRegistrationState
> = {
  [PaypalStatus.ACTIVE]: ClientRegistrationState.payment_active,
  [PaypalStatus.APPROVAL_PENDING]: ClientRegistrationState.payment_initialized,
  [PaypalStatus.APPROVED]: ClientRegistrationState.payment_active,
  [PaypalStatus.CANCELLED]: ClientRegistrationState.waiting_for_payment,
  [PaypalStatus.SUSPENDED]: ClientRegistrationState.waiting_for_payment,
  [PaypalStatus.EXPIRED]: ClientRegistrationState.waiting_for_payment,
};

async function _updateUserClientRegistrationState(
  subscription: PaypalClientSubscription,
  result: APIResult
): Promise<APIResult> {
  const userRef = db.doc(`users/${subscription.uid}`);
  const userSnapshot = await userRef.get();

  // CHECK User exists
  if (!userSnapshot.exists) {
    result.error = `Early exit. User with uid ${subscription.uid} not found`;
    return Promise.resolve(result);
  }
  // READ User
  const user: User = userSnapshot.data();

  // Check for early exit
  if (
    user.userProfileStatus === UserProfileStatusEnum.VERIFIED ||
    !user.clientRegistrationState
  ) {
    result.message = `Early exit. User is VERIFIED or User.clientRegistrationState is missing`;
    return Promise.resolve(result);
  }
  if (
    user.clientRegistrationState ===
    ClientRegistrationState.registration_completed
  ) {
    result.message = `Early exit. User.clientRegistrationState is equal to 'registration_completed'.`;
    return Promise.resolve(result);
  }

  // DETECT NEW clientRegistrationState
  const paypalStatus = subscription.paypalStatus;
  const newClientRegistrationState =
    paypalStatusToClientRegistrationStateDictionary[paypalStatus];

  // UPDATE User with new clientRegistrationState
  const batch: WriteBatch = db.batch();
  batch.update(userRef, {
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    clientRegistrationState: newClientRegistrationState,
  });
  await batch.commit();
  result.message = `User.clientRegistrationState was updated to '${newClientRegistrationState}'`;
  return Promise.resolve(result);
}

async function _updatePaypalClientSubscription({
  subscription,
  paypalClientRef,
  result,
}: {
  subscription: PaypalClientSubscription;
  paypalClientRef: DocumentReference<PaypalClient>;
  result: APIResult;
}): Promise<APIResult> {
  // paypalStatus === 'ACTIVE'
  if (subscription.paypalStatus === PaypalStatus.ACTIVE) {
    // UPDATE paypalClient with activeSubscriptionPlan === subscription.paypalPlanType
    const batch: WriteBatch = db.batch();
    batch.update(paypalClientRef, {
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      activeSubscriptionPlan: subscription.paypalPlanType,
    });
    await batch.commit();
    result.message = `PaypalClient.activeSubscriptionPlan was updated to '${subscription.paypalPlanType}'`;
  } else if (
    // paypalStatus === 'CANCELLED' || 'EXPIRED'
    [PaypalStatus.CANCELLED, PaypalStatus.EXPIRED].includes(
      subscription.paypalStatus
    )
  ) {
    // UPDATE paypalClient with activeSubscriptionPlan === null
    const batch: WriteBatch = db.batch();
    batch.update(paypalClientRef, {
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      activeSubscriptionPlan: null,
    });
    await batch.commit();
    result.message = `PaypalClient.activeSubscriptionPlan was updated to '${subscription.paypalPlanType}'`;
  }

  return Promise.resolve(result);
}

async function _updatePaypalClient(
  subscription: PaypalClientSubscription,
  result: APIResult
): Promise<APIResult> {
  const paypalClientRef = db.doc(`paypalClients/${subscription.uid}`);
  const paypalClientSnapshot = await paypalClientRef.get();

  // CHECK paypalClient exists
  if (!paypalClientSnapshot.exists) {
    result.error = `Early exit. PaypalClient with uid ${subscription.uid} not found`;
    return Promise.resolve(result);
  }

  // paypalProductType === 'subscription'
  if (subscription.paypalProductType === PaypalProductType.subscription) {
    return _updatePaypalClientSubscription({
      subscription,
      paypalClientRef,
      result,
    });
  }
  // TODO paypalProductType === 'boosting'
  // TODO paypalProductType === 'otherServices'
  return Promise.resolve(result);
}

export const updateUserClientRegistrationState = functions.firestore
  .document(`${collectionName}/{docId}`)
  .onWrite(async (snapshot, context) => {
    const paypalClientSubscriptionId = context.params.docId as string;
    const paypalClientSubscription: PaypalClientSubscription = {
      ...(snapshot.after.data() as PaypalClientSubscription),
      id: paypalClientSubscriptionId,
    };
    snapshot.before.data();

    const apiLog: APIResult = {};
    await _updateUserClientRegistrationState(paypalClientSubscription, apiLog);
    await _updatePaypalClient(paypalClientSubscription, apiLog);
    console.log(apiLog);
  });
