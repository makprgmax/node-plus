import { Request, Response } from 'express';
import { db } from '../init';
import * as admin from 'firebase-admin';

// const functions = require('firebase-functions');
// const paypal = require('paypal-rest-sdk');

// const MODE = 'sandbox';

// paypal.configure({
//   mode: MODE, // sandbox or live
//   client_id: functions.config().paypal.client_id, // run: firebase functions:config:set paypal.client_id="yourPaypalClientID"
//   client_secret: functions.config().paypal.client_secret, // run: firebase functions:config:set paypal.client_secret="yourPaypalClientSecret"
// });

export async function paypalWebhook(request: Request, response: Response) {
  await db.collection('paypalWebhookLog').add({
    version: 2,
    request: request.body,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
    processed: false,
  });
  response.sendStatus(200);
}
