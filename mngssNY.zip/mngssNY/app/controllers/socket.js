const Message = require('../models/message')
const User = require('../models/user')
const OnlineUsers = require('../models/onlineUsers')
const { http } = require('../../server')

const io = require('socket.io')
const socketio = io(http)

socketio.on('connection', (socket) => {
  console.log(`New User Logged In with ID ${socket.id}`)

  // Collect message and insert into database
  socket.on('chatMessage', async (data) => {
    // recieves message from client-end along with sender's and reciever's details
    // let data =  {
    //    from: "senderid",
    //    to: "receiverid",
    //    message: "Hi",
    //  }

    const senderUser = await User.findById(data.from)
    if (!senderUser) {
      socket.emit('message', { msg: 'Sender User doest not exist' })
    }

    const receeiverUser = await User.findById(data.to)
    if (!receeiverUser) {
      socket.emit('message', { msg: 'Receiver User doest not exist' })
    }

    const newMessage = new Message({
      from: data.from,
      to: data.to,
      message: data.message
    })
    await newMessage.save()

    if (newMessage) {
      socket.emit('message', newMessage)
    }

    const onlineUser = await OnlineUsers.findOne({ userId: data.to })
    if (onlineUser) {
      socket.to(data.to).emit('message', newMessage)
    }
  })

  socket.on('userDetails', async (data) => {
    // checks if a new user has logged in and recieves the established chat details

    // data must be in the object like from user id and to user id

    const onlineUser = new OnlineUsers({
      userId: data.fromUser
    })
    await onlineUser.save()

    const messages = await Message.find({
      from: { $in: [data.fromUser, data.toUser] },
      to: { $in: [data.fromUser, data.toUser] }
    })
      .projection({ _id: 0 })
      .toArray()

    socket.emit('output', messages) // emits the entire chat history to client
  })

  socket.on('disconnect', async (userId) => {
    const offline = await OnlineUsers.findById(userId)
    if (offline) {
      console.log(`User ${userId}went offline...`)
    }
    await offline.remove()
  })
})

module.exports = socketio
