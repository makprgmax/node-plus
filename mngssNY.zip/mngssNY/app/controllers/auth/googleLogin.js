const passport = require('passport')

// Use the GoogleStrategy within Passport.
//   Strategies in passport require a `verify` function, which accept
//   credentials (in this case, a token, tokenSecret, and Google profile), and
//   invoke a callback with a user object.

/**
 * Login function called by route
 * @param {Object} req - request object
 * @param {Object} res - response object
 */

const googleLogin = (req, res, next) => passport.authenticate(`google-role-${req.params.role}`, {
  scope: ['profile', 'email'],
  session: false
})(req, res, next)

module.exports = { googleLogin }
