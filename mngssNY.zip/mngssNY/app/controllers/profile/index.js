const { changePassword } = require('./changePassword')
const { getProfile } = require('./getProfile')
const { updateProfile } = require('./updateProfile')

module.exports = {
  changePassword,
  getProfile,
  updateProfile
}
