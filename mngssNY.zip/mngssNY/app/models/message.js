const moongose = require('mongoose')
const Schema = moongose.Schema

const messageSchema = new Schema({
  type: {
    type: String,
    default: 'chat'
  },
  from: {
    type: moongose.Schema.ObjectId,
    ref: 'user'
  },
  to: {
    type: moongose.Schema.ObjectId,
    ref: 'user'
  },
  message: {
    type: String
  },
  attachment: {
    type: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
})

const Chat = moongose.model('message', messageSchema)

module.exports = Chat
